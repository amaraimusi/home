﻿Public Class Form1

    ''' <summary>
    ''' 共通プロパティ
    ''' </summary>
    ''' <remarks></remarks>
    Private PrpCom As PropertyCommon

    ''' <summary>
    ''' ＨＴＭＬ読み込み
    ''' </summary>
    ''' <remarks></remarks>
    Private HtmLoad As HtmlLoader

    ''' <summary>
    ''' 文字列制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StrCon As StringControl

    Public Sub New()

        ' この呼び出しは、Windows フォーム デザイナで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後で初期化を追加します。

        '■メンバオブジェクトの生成
        prpCom = PropertyCommon.getInstance '共通プロパティを生成
        HtmLoad = New HtmlLoader            'ＨＴＭＬ読込の生成
        StrCon = New StringControl          '文字列制御の生成


    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ViewData() ' プロパティ情報を画面に表示する
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        GetData()               ' 画面情報からプロパティ情報を取得する
        PrpCom.saveProDtSet()   'プロパティ情報をＸＭＬファイルに保存する
    End Sub

    ''' <summary>
    ''' 全ＨＴＭＬ文取得押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnGetHtmStrAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnGetHtmStrAll.Click
        Try
            prgPrint("現在ＨＴＭＬ情報をダウンロード中です・・・")
            RTxtHtmlStr.Text = HtmLoad.getHtmlStrForYahoo(TxtUrl.Text) 'ＨＴＭＬ情報をロードして表示する
            prgPrint("ダウンロード完了")
        Catch ex As Exception
            RTxtHtmlStr.Text = "読込に失敗しました。ＵＲＬが正しくない可能性があります。"
            prgPrint("ダウンロード失敗")
        End Try
    End Sub

    ''' <summary>
    ''' 全ＨＴＭＬ文取得押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnGetHtmStrPart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnGetHtmStrPart.Click

        Try
            prgPrint("現在ＨＴＭＬ情報をダウンロード中です・・・")
            Dim s0 As String = HtmLoad.getHtmlStrForYahoo(TxtUrl.Text) 'ＨＴＭＬ情報をロードして表示する
            RTxtHtmlStr.Text = StrCon.getMarkupStr(s0, TxtMarkStr1.Text, TxtMarkStr2.Text)

            prgPrint("ダウンロード完了")
        Catch ex As Exception
            RTxtHtmlStr.Text = "読込に失敗しました。ＵＲＬが正しくない可能性があります。"
            prgPrint("ダウンロード失敗")
        End Try
    End Sub

    ''' <summary>
    ''' プロパティ情報を画面に表示する
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ViewData()
        LblToday.Text = Date.Now
        LblAfterExcDate.Text = PrpCom.ExcDate
        TxtUrl.Text = PrpCom.UrlStr
        TxtMarkStr1.Text = PrpCom.MarkStr1
        TxtMarkStr2.Text = PrpCom.MarkStr2
    End Sub

    ''' <summary>
    ''' 画面情報からプロパティ情報を取得する
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetData()
        PrpCom.ExcDate = Date.Now
        PrpCom.UrlStr = TxtUrl.Text
        PrpCom.MarkStr1 = TxtMarkStr1.Text
        PrpCom.MarkStr2 = TxtMarkStr2.Text
    End Sub



    ''' <summary>
    ''' 進捗状況表示
    ''' </summary>
    ''' <param name="msg"></param>
    ''' <remarks></remarks>
    Private Sub prgPrint(ByRef msg As String)
        LblPrg.Text = msg
        Application.DoEvents()
    End Sub

End Class
