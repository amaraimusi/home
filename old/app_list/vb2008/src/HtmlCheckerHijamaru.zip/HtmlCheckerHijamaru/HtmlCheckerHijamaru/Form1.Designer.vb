﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TxtMarkStr1 = New System.Windows.Forms.TextBox
        Me.TxtUrl = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.TxtMarkStr2 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.BtnGetHtmStrAll = New System.Windows.Forms.Button
        Me.RTxtHtmlStr = New System.Windows.Forms.RichTextBox
        Me.LblAfterExcDate = New System.Windows.Forms.Label
        Me.LblToday = New System.Windows.Forms.Label
        Me.LblPrg = New System.Windows.Forms.Label
        Me.BtnGetHtmStrPart = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TxtMarkStr1
        '
        Me.TxtMarkStr1.Location = New System.Drawing.Point(76, 27)
        Me.TxtMarkStr1.Name = "TxtMarkStr1"
        Me.TxtMarkStr1.Size = New System.Drawing.Size(294, 19)
        Me.TxtMarkStr1.TabIndex = 0
        '
        'TxtUrl
        '
        Me.TxtUrl.Location = New System.Drawing.Point(76, 6)
        Me.TxtUrl.Name = "TxtUrl"
        Me.TxtUrl.Size = New System.Drawing.Size(691, 19)
        Me.TxtUrl.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "印文字１"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "印文字２"
        '
        'TxtMarkStr2
        '
        Me.TxtMarkStr2.Location = New System.Drawing.Point(76, 49)
        Me.TxtMarkStr2.Name = "TxtMarkStr2"
        Me.TxtMarkStr2.Size = New System.Drawing.Size(294, 19)
        Me.TxtMarkStr2.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 12)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "ＵＲＬ"
        '
        'BtnGetHtmStrAll
        '
        Me.BtnGetHtmStrAll.Location = New System.Drawing.Point(12, 74)
        Me.BtnGetHtmStrAll.Name = "BtnGetHtmStrAll"
        Me.BtnGetHtmStrAll.Size = New System.Drawing.Size(56, 20)
        Me.BtnGetHtmStrAll.TabIndex = 6
        Me.BtnGetHtmStrAll.Text = "全取得"
        Me.BtnGetHtmStrAll.UseVisualStyleBackColor = True
        '
        'RTxtHtmlStr
        '
        Me.RTxtHtmlStr.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RTxtHtmlStr.Location = New System.Drawing.Point(12, 105)
        Me.RTxtHtmlStr.Name = "RTxtHtmlStr"
        Me.RTxtHtmlStr.Size = New System.Drawing.Size(768, 456)
        Me.RTxtHtmlStr.TabIndex = 7
        Me.RTxtHtmlStr.Text = ""
        '
        'LblAfterExcDate
        '
        Me.LblAfterExcDate.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LblAfterExcDate.AutoSize = True
        Me.LblAfterExcDate.Location = New System.Drawing.Point(640, 74)
        Me.LblAfterExcDate.Name = "LblAfterExcDate"
        Me.LblAfterExcDate.Size = New System.Drawing.Size(38, 12)
        Me.LblAfterExcDate.TabIndex = 8
        Me.LblAfterExcDate.Text = "Label4"
        '
        'LblToday
        '
        Me.LblToday.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LblToday.AutoSize = True
        Me.LblToday.Location = New System.Drawing.Point(640, 56)
        Me.LblToday.Name = "LblToday"
        Me.LblToday.Size = New System.Drawing.Size(38, 12)
        Me.LblToday.TabIndex = 9
        Me.LblToday.Text = "Label4"
        '
        'LblPrg
        '
        Me.LblPrg.AutoSize = True
        Me.LblPrg.Location = New System.Drawing.Point(147, 78)
        Me.LblPrg.Name = "LblPrg"
        Me.LblPrg.Size = New System.Drawing.Size(29, 12)
        Me.LblPrg.TabIndex = 10
        Me.LblPrg.Text = "待機"
        '
        'BtnGetHtmStrPart
        '
        Me.BtnGetHtmStrPart.Location = New System.Drawing.Point(76, 74)
        Me.BtnGetHtmStrPart.Name = "BtnGetHtmStrPart"
        Me.BtnGetHtmStrPart.Size = New System.Drawing.Size(65, 20)
        Me.BtnGetHtmStrPart.TabIndex = 11
        Me.BtnGetHtmStrPart.Text = "部分取得"
        Me.BtnGetHtmStrPart.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(397, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(162, 72)
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(790, 570)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.BtnGetHtmStrPart)
        Me.Controls.Add(Me.LblPrg)
        Me.Controls.Add(Me.LblToday)
        Me.Controls.Add(Me.LblAfterExcDate)
        Me.Controls.Add(Me.RTxtHtmlStr)
        Me.Controls.Add(Me.BtnGetHtmStrAll)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtMarkStr2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtUrl)
        Me.Controls.Add(Me.TxtMarkStr1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "HTML文調査-比謝丸"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtMarkStr1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtUrl As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtMarkStr2 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BtnGetHtmStrAll As System.Windows.Forms.Button
    Friend WithEvents RTxtHtmlStr As System.Windows.Forms.RichTextBox
    Friend WithEvents LblAfterExcDate As System.Windows.Forms.Label
    Friend WithEvents LblToday As System.Windows.Forms.Label
    Friend WithEvents LblPrg As System.Windows.Forms.Label
    Friend WithEvents BtnGetHtmStrPart As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox

End Class
