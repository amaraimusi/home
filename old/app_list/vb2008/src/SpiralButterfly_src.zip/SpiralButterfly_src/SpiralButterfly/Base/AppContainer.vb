﻿''' <summary>
''' アプリケーションコンテナ
''' </summary>
''' <remarks>
''' ☆概要
''' 　アプリケーションレベルでのスコープ。
''' 　アプリケーションレベルでオブジェクトを保持する。
''' 　グローバル変数のような扱い。
''' 　シングルトンパターンを利用している。
''' ☆履歴
''' 2006/06/27　新規作成
''' 2007/10/16　Ｄａｏをメンバに追加。アクセサメソッドもついでに追加
''' 2008/01/18  DIContainerからAppContainerにクラス名を変更。daoの変更
''' 2008/06/04  螺旋蝶用に改造
''' </remarks>
Public Class AppContainer


#Region "システム"

    ''' <summary>
    ''' 自分自身のインスタンス
    ''' </summary>
    ''' <remarks>シングルトンパターンを適用</remarks>
    Private Shared mySelf As AppContainer

    ''' <summary>
    ''' 進捗コントロール
    ''' </summary>
    ''' <remarks>メンバオブジェクトのインスタンス生成状況を進捗表示するのに使う</remarks>
    Private prg As ProgressBar



    Private Sub New()


    End Sub

    ''' <summary>
    ''' 当クラスのインスタンスを返す。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function getInstance() As AppContainer

        If mySelf Is Nothing Then
            mySelf = New AppContainer()
            LogPrint("アプリケーションコンテナを生成")
        End If
        Return mySelf
    End Function

    ''' <summary>
    ''' このオブジェクトを破棄する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub close()
        mySelf = Nothing
    End Sub

    Protected Overrides Sub Finalize()
        closing()
        MyBase.Finalize()
        Debug.Print("アプリケーションコンテナを破棄")
    End Sub

#End Region


#Region "メンバオブジェクト"

    ''' <summary>
    ''' 共通プロパティ
    ''' </summary>
    ''' <remarks></remarks>
    Private prpCom As PropertyCommon

    ''' <summary>
    ''' メインサイズ
    ''' </summary>
    ''' <remarks></remarks>
    Private MainSize As Size

    ''' <summary>
    ''' 画面外範囲
    ''' </summary>
    ''' <remarks></remarks>
    Private OutSize As Size

    ''' <summary>
    ''' JET DAOオブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dao As IDao

    ''' <summary>
    ''' DXグラフィック制御
    ''' </summary>
    ''' <remarks></remarks>
    Private dxg As DxGraphicControl

    ''' <summary>
    ''' 効果音制御
    ''' </summary>
    ''' <remarks></remarks>
    Private efSnd As EffectSoundControl

    ''' <summary>
    ''' Dx入力制御
    ''' </summary>
    ''' <remarks></remarks>
    Private dxInp As CDirectInputEx1

    ''' <summary>
    ''' プレイヤー入力情報
    ''' </summary>
    ''' <remarks></remarks>
    Private pid As PlayerInputData

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private stgCon As StageControl

    ''' <summary>
    ''' クリーチャーライブラリ
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtLib As CrtLibraly

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    ''' <summary>
    ''' 主人公パラメータ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private HPrmCon As HeroParameterControl

    ''' <summary>
    ''' ゲームマスター
    ''' </summary>
    ''' <remarks></remarks>
    Private gm As GameMaster

    ''' <summary>
    ''' メインフォーム
    ''' </summary>
    ''' <remarks></remarks>
    Private fmMain As Form

#End Region

#Region "アクセサメソッド"

    ''' <summary>
    ''' daoのゲッター
    ''' </summary>
    ''' <returns>DBフラグの値により返すDAOは変わる</returns>
    ''' <remarks></remarks>
    Public Function GetDao() As IDao
        Return dao
    End Function
    Public Sub SetDao(ByRef prm_dao As IDao)
        dao = prm_dao
    End Sub

    Public Function GetPrpCom() As PropertyCommon
        Return prpCom
    End Function
    Public Sub SetPrpCom(ByRef prm_prpCom As PropertyCommon)
        prpCom = prm_prpCom
    End Sub

    Public Function GetMainSize() As Size
        Return MainSize
    End Function
    Public Sub SetMainSize(ByRef prm_mainSize As Size)
        MainSize = prm_mainSize
    End Sub

    Public Function GetOutSize() As Size
        Return OutSize
    End Function
    Public Sub SetOutSize(ByRef prm_outSize As Size)
        OutSize = prm_outSize
    End Sub

    Public Function GetDxg() As DxGraphicControl
        Return dxg
    End Function
    Public Sub SetDxg(ByRef prm_dxg As DxGraphicControl)
        dxg = prm_dxg
    End Sub

    Public Sub SetEfSnd(ByRef prm_efSnd As EffectSoundControl)
        efSnd = prm_efSnd
    End Sub
    Public Function GetEfSnd() As EffectSoundControl
        Return efSnd
    End Function

    Public Sub SetDxInp(ByRef prm_dxInp As CDirectInputEx1)
        dxInp = prm_dxInp
    End Sub
    Public Function GetDxInp() As CDirectInputEx1
        Return dxInp
    End Function

    Public Function GetPlayerInputData() As PlayerInputData
        Return pid
    End Function

    Public Sub SetStageControl(ByRef prm_stgCon As StageControl)
        stgCon = prm_stgCon
    End Sub
    Public Function GetStageControl() As StageControl
        Return stgCon
    End Function

    Public Sub SetCrtLibral(ByRef prm_CrtLib As CrtLibraly)
        CrtLib = prm_CrtLib
    End Sub
    Public Function GetCrtLibraly() As CrtLibraly
        Return CrtLib
    End Function

    Public Sub SetCrtControl(ByRef prm_CrtCon As CrtControl)
        CrtCon = prm_CrtCon
    End Sub
    Public Function GetCrtControl() As CrtControl
        Return CrtCon
    End Function

    Public Sub SetHPrmControl(ByRef prm_HPrmCon As HeroParameterControl)
        HPrmCon = prm_HPrmCon
    End Sub
    Public Function GetHPrmControl() As HeroParameterControl
        Return HPrmCon
    End Function

    Public Function GetGameMaster()
        Return gm
    End Function
    Public Sub SetGameMaster(ByVal prm_gameMaster As GameMaster)
        gm = prm_gameMaster
    End Sub

    Public Function GetFormMain() As Form
        Return fmMain
    End Function
    Public Sub SetFormMain(ByRef prm_FormMain As Form)
        fmMain = prm_FormMain
    End Sub
#End Region

    ''' <summary>
    ''' プレイヤー入力情報の更新
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdatePlayerInputData()
        pid = dxInp.getPlayerInputData(0)
    End Sub

    Public Sub Closing()
        dxg = Nothing
    End Sub

End Class

