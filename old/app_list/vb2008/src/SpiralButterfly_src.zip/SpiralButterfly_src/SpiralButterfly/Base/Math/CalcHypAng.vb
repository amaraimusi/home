﻿
''' <summary>
''' 通常座標から距離角度座標を算出する。
''' </summary>
''' <remarks></remarks>
Public Class CalcHypAng


    Private CST_ANG90 As Single '90度のラジアン角度
    Private CST_ANG180 As Single '180度のラジアン角度
    Private CST_ANG270 As Single '270度のラジアン角度
    Private CST_ANG360 As Single '270度のラジアン角度

    Public Sub New()
        CST_ANG90 = Math.PI * 0.5F
        CST_ANG180 = Math.PI
        CST_ANG270 = Math.PI * 1.5F
        CST_ANG360 = Math.PI * 2.0F
    End Sub

    ''' <summary>
    ''' 通常座標から距離角度座標を算出する。
    ''' </summary>
    ''' <param name="x"></param>
    ''' <param name="y"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Calc(ByVal x As Single, ByVal y As Single) As PointHypAng

        Dim ang As Single = 0.0F
        If x <> 0.0F And y <> 0.0F Then
            Dim ang1 As Single = Math.Atan(y / x)
            If x > 0.0F Then
                If y > 0 Then
                    ang = ang1
                Else
                    ang = CST_ANG360 + ang1
                End If
            Else
                If y > 0 Then
                    ang = CST_ANG180 + ang1
                Else
                    ang = ang1 + CST_ANG180
                End If
            End If
        ElseIf x <> 0 And y = 0 Then '目標方向角度が０度か180度の場合
            If x > 0 Then
                ang = 0
            Else
                ang = CST_ANG180
            End If
        ElseIf x = 0 And y <> 0 Then '目標方向角度が90度か270度の場合
            If y > 0 Then
                ang = CST_ANG90
            Else
                ang = CST_ANG270
            End If
        Else 'この条件は２つのクリーチャーが同一地点にいる場合。

            ang = 0.0F
        End If

        Dim hyp As Single = (x ^ 2.0F + y ^ 2.0F) ^ 0.5F

        Dim pha As New PointHypAng
        pha.Ang = ang
        pha.Hyp = hyp
        pha.x = x
        pha.y = y

        Return pha
    End Function



End Class
