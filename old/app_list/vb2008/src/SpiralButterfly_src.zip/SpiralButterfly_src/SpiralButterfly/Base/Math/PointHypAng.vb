﻿''' <summary>
''' 座標を角度と距離で表すためのデータ。
''' </summary>
''' <remarks></remarks>
Public Class PointHypAng
    Public Ang As Single '指定地点の方角
    Public Hyp As Single '指定地点までの距離
    Public x As Single '通常の座標。指定地点の座標X
    Public y As Single '通常の座標。指定地点の座標Y
End Class
