﻿''' <summary>
''' DAO
''' </summary>
''' <remarks>
''' ☆概要
''' DB関連のよくつかう機能を定義する。
''' ☆履歴
''' 20078/1/18　新規作成
''' </remarks>
Public Interface IDao

    ''' <summary>
    ''' DBを開く
    ''' </summary>
    ''' <remarks></remarks>
    Sub Open()

    ''' <summary>
    ''' DBを閉じる
    ''' </summary>
    ''' <remarks></remarks>
    Sub Close()

    ''' <summary>
    ''' SQLを発行してDataSetを取得する
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function getDataSet(ByRef sql As String) As DataSet

    ''' <summary>
    ''' 更新系のSQLを実行する
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <remarks>Update文、Insert、DeleteのSQLを実行する</remarks>
    Sub ExcuteSQL(ByRef sql As String)

    ''' <summary>
    ''' データセットを更新する
    ''' </summary>
    ''' <param name="dtSet"></param>
    ''' <remarks></remarks>
    Sub UpdateDataSet(ByRef strDbTable As String, ByRef dtSet As DataSet)

    ''' <summary>
    ''' トランザクション開始
    ''' </summary>
    ''' <remarks></remarks>
    Sub TransactStart()

    ''' <summary>
    ''' コミット
    ''' </summary>
    ''' <remarks></remarks>
    Sub Commit()

    ''' <summary>
    ''' ロールバック
    ''' </summary>
    ''' <remarks></remarks>
    Sub RollBack()

End Interface

