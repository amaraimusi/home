﻿Imports Microsoft.DirectX.DirectSound
''' <summary>
''' 効果音制御
''' </summary>
''' <remarks></remarks>
Public Class EffectSoundControl

    Private ds As DxSound

    ''' <summary>
    ''' セカンダリバッファライブラリ
    ''' </summary>
    ''' <remarks></remarks>
    Private LibSBfs() As SecondaryBuffer

    Private Const CST_FLNM As String = "FileName"
    Private Const CST_ID As String = "ID"
    Private DIR_PATH As String = IO.Directory.GetCurrentDirectory & "\sys\wav\"
    ''' <summary>
    ''' 実行セカンダリバッファリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private actBfs() As SecondaryBuffer
    ''' <summary>
    ''' 実行再生数
    ''' </summary>
    ''' <remarks></remarks>
    Private PlayCount As Integer
    ''' <summary>
    ''' 最大実行再生数
    ''' </summary>
    ''' <remarks></remarks>
    Private Const MAX_PLAY_CNT As Integer = 8

    ''' <summary>
    ''' 実行セカンダリバッファリストを追加する
    ''' </summary>
    ''' <param name="id"></param>
    ''' <remarks></remarks>
    Public Sub PlayAdd(ByVal id As Integer)
        If Not LibSBfs(id) Is Nothing Then
            If PlayCount < MAX_PLAY_CNT Then
                actBfs(PlayCount) = LibSBfs(id)
                PlayCount += 1
            End If
        End If
    End Sub

    ''' <summary>
    ''' 実行セカンダリバッファリストをすべて再生する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Play()
        For i As Integer = 0 To PlayCount - 1
            ds.Play(actBfs(i))
        Next
        PlayCount = 0
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fm"></param>
    ''' <remarks></remarks>
    Public Sub New(ByRef fm As Form)
        ds = New DxSound(fm)

        ReDim actBfs(MAX_PLAY_CNT)
    End Sub

    ''' <summary>
    ''' セカンダリバッファライブラリの読み込み
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Load()
        Dim dao As IDao = AppContainer.getInstance.GetDao

        '■最大要素数を取得する
        Dim maxIndex As Integer = GetMaxIndex(dao)
        ReDim LibSBfs(maxIndex)
        For Each sb As SecondaryBuffer In LibSBfs
            sb = Nothing
        Next

        '■セカンダリバッファライブラリにデータを読み込む
        Dim sql As String = "SELECT * FROM SoundTbl"
        Dim dtSet As DataSet = dao.getDataSet(sql)
        For Each r As DataRow In dtSet.Tables(0).Rows
            Dim id As Integer = CType(r(CST_ID), Integer)
            Dim flNm As String = DIR_PATH & CType(r(CST_FLNM), String)
            Dim sBf As SecondaryBuffer = ds.CreateSecondaryBuffer(flNm)
            LibSBfs(id) = sBf
        Next
    End Sub

    ''' <summary>
    ''' 最大要素数を取得する
    ''' </summary>
    ''' <param name="dao"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetMaxIndex(ByRef dao As IDao) As Integer

        Dim sql As String = "SELECT Max(ID) AS MaxId FROM SoundTbl"
        Dim dtSet As DataSet = dao.getDataSet(sql)
        Return CType(dtSet.Tables(0).Rows(0)(0), Integer)
    End Function

End Class
