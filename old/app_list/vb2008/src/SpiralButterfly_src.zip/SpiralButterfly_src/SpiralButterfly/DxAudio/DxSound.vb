﻿Imports Microsoft.DirectX.DirectSound
''' <summary>
''' DirectSound制御
''' </summary>
''' <remarks>
''' ☆概要
''' 効果音を鳴らす
''' ☆履歴
''' 2008/6/9　新規作成
''' </remarks>
Public Class DxSound

    ''' <summary>
    ''' サウンドデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device

    ''' <summary>
    ''' バッファについての情報設定クラス
    ''' </summary>
    ''' <remarks></remarks>
    Private desc As BufferDescription

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fm"></param>
    ''' <remarks>デバイスの初期化などを行う。</remarks>
    Public Sub New(ByRef fm As Form)
        dev = New Device 'デバイスを生成
        dev.SetCooperativeLevel(fm, CooperativeLevel.Normal) '協調レベルの設定
        desc = New BufferDescription() 'バッファについての情報設定クラス
    End Sub

    ''' <summary>
    ''' セカンダリバッファを生成する
    ''' </summary>
    ''' <param name="wavFlNm"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CreateSecondaryBuffer(ByRef wavFlNm As String) As SecondaryBuffer
        Dim sb As SecondaryBuffer = Nothing
        Try

            sb = New SecondaryBuffer(wavFlNm, desc, dev)
        Catch ex As Exception
            ErrMsg("DxSound", "CreateSecondaryBuffer", "以下のファイルが存在しません。" & vbCrLf & "ファイル名：" & wavFlNm, ex)
        End Try
        Return sb
    End Function

    ''' <summary>
    ''' 再生
    ''' </summary>
    ''' <param name="secBf"></param>
    ''' <remarks></remarks>
    Public Sub Play(ByRef secBf As SecondaryBuffer)
        secBf.Play(0, BufferPlayFlags.Default)
    End Sub
End Class
