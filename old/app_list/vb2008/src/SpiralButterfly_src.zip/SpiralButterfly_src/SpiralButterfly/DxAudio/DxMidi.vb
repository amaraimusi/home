﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.AudioVideoPlayback

''' <summary>
''' DirectX ＭＩＤＩ制御
''' </summary>
''' <remarks>
''' ☆概要
''' MIDIをループ再生する
''' 音楽の切り替えもPlayメソッドにファイル名を指定するだけでよい。
''' ☆履歴
''' 2008/06/09　新規作成
''' </remarks>
Public Class DxMidi

    Public ado As Audio

    ''' <summary>
    ''' 再生する。
    ''' </summary>
    ''' <param name="midiFlNm">再生するＭｉｄｉファイル名</param>
    ''' <remarks></remarks>
    Public Sub Play(ByRef midiFlNm As String)
        If ado Is Nothing Then
            ado = New Audio(midiFlNm)
            AddHandler ado.Ending, AddressOf Audio_Ending
        Else
            ado.Open(midiFlNm)
        End If
        ado.Play()
    End Sub

    ''' <summary>
    ''' 曲終わりイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>ループのための処理</remarks>
    Private Sub Audio_Ending(ByVal sender As Object, ByVal e As System.EventArgs)
        ado.Stop()
        ado.Play()
    End Sub


    Protected Overrides Sub Finalize()
        ado.Stop()
        ado.Dispose()

        MyBase.Finalize()
    End Sub
End Class
