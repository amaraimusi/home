﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput


''' <summary>
''' キーボードの入力状態を取得する
''' </summary>
''' <remarks></remarks>
Public Class DXI_GetKeyboardState
    Private devKeyboard As Device

    ''' <summary>
    ''' キーボードの入力状態情報報を取得する
    ''' </summary>
    ''' <returns>キーボード入力状態情報</returns>
    ''' <remarks></remarks>
    Public Function getKeyboardState() As KeyboardState

        devKeyboard.Acquire()
        Dim kbState As KeyboardState = Nothing
        Dim fm As Form = Form.ActiveForm
        If Not (fm Is Nothing) Then
            Try
                kbState = devKeyboard.GetCurrentKeyboardState()
                ' Poll the device for info.（デバイスの情報を調査する)
                devKeyboard.Poll()
            Catch ex As Exception

            End Try
        End If
        Return kbState
    End Function
End Class
