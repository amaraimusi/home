﻿
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput

''' <summary>
''' キーボードデバイスの初期化
''' </summary>
''' <remarks></remarks>
Public Class DXI_InitKeyboard

    ''' <summary>
    ''' キーボードデバイス情報の初期化と取得
    ''' </summary>
    ''' <param name="fm">対象フォーム</param>
    ''' <returns>キーボードデバイス</returns>
    ''' <remarks></remarks>
    Public Function initDevice(ByRef fm As Form) As Device

        Dim dev As Device = Nothing

        'dev = New Device(SystemGuid.Keyboard)
        Dim devIns As DeviceInstance
        For Each devIns In Manager.GetDevices(DeviceType.Keyboard, EnumDevicesFlags.AttachedOnly)
            ' Create the device.
            dev = New Device(devIns.InstanceGuid)
            Exit For

        Next devIns

        If dev Is Nothing Then Throw New Exception("No keyboard found.")


        ' Set the cooperative level to let DirectInput know how
        ' this device should interact with the system and with other
        ' DirectInput applications.
        Try
            ' Set the cooperative level for the device.(デバイスに強調レベルを設定する。）
            '   ■強調レベルのフラグ説明
            '       ・CooperativeLevelFlags.Background このデバイスは、バックグラウンドで使用可能で、いつでも取得できます。アプリケーション ウィンドウがアクティブでない場合でも取得可能です。 
            '       ・CooperativeLevelFlags.Foreground このデバイスは、アプリケーション ウィンドウがフォアグラウンドにある場合にのみ使えます。アプリケーション ウィンドウがフォーカスを失うと、このデバイスは取得できなくなります。 
            '       ・CooperativeLevelFlags.Exclusive このデバイスは排他アクセスを必要とします。他のアプリケーションはこのデバイスを取得できません。セキュリティ上の理由から、キーボードやマウスなどの特定のデバイスで、このフラグをバックグラウンド フラグと組み合わせて使うことはできません。 
            '       ・CooperativeLevelFlags.NonExclusive このデバイスは、排他アクセスを必要としない他の任意のアプリケーションと共有できます。 
            '       ・CooperativeLevelFlags.NoWindowsKey このフラグは、ウィンドウのキーを無効にします。 

            dev.SetCooperativeLevel(fm, CooperativeLevelFlags.Exclusive Or CooperativeLevelFlags.Foreground)
        Catch dx As InputException
            If TypeOf dx Is UnsupportedException Then
                MessageBox.Show("SetCooperativeLevel() returned ErrorCode.Unsupported." + ControlChars.Lf + "For security reasons, background keyboard" + ControlChars.Lf + "access is not allowed.", "Keyboard")
                Return Nothing
            End If
        End Try

        Return dev
    End Function
End Class
