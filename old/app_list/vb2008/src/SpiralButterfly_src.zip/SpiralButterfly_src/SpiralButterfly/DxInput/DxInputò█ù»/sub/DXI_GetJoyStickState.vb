﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput
Public Class DXI_GetJoyStickState

    ''' <summary>
    ''' ジョイススティックデバイスリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private AryDevJoy As ArrayList

    Public Sub New(ByRef prm_aryDevJoy As ArrayList)
        AryDevJoy = prm_aryDevJoy
    End Sub

    Public Function getJoyStickState(ByVal index As Integer) As JoystickState
        Dim dev As Device

        'ジョイスティックリスト外のインデックスを指定した場合はNothingを返し処理を抜ける。
        If AryDevJoy.Count <= index Then
            Return Nothing
        End If

        dev = AryDevJoy(index)

        Dim state As JoystickState 'ジョイスティックの状態

        Dim fm As Form = Form.ActiveForm
        If Not (Form.ActiveForm Is Nothing) Then
            Try
                dev.Acquire()
                dev.Poll()
                state = dev.CurrentJoystickState
            Catch ex As Exception

            End Try
        End If

        Return state
    End Function

End Class
