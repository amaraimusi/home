﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput

''' <summary>
''' DirectX入力制御
''' </summary>
''' <remarks>
''' ☆概要
''' DirectXを用いた入力制御
''' ☆履歴
''' 2008/07/02 新規作成
''' </remarks>
Public Class DxInputControl

    ''' <summary>
    ''' ジョイスティックデバイスリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private AryDevJoy As ArrayList

    ''' <summary>
    ''' キーボードデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private DevKey As Device


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New(ByRef fm As Form)
        Dim initJoy As New DXI_InitJoyStick
        Dim initKey As New DXI_InitKeyboard
        AryDevJoy = initJoy.InitDevice(fm)
        DevKey = initKey.InitDevice(fm)

    End Sub

    '''' <summary>
    '''' プレイヤー入力情報を取得する
    '''' </summary>
    '''' <param name="index"></param>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Public Function GetPlayerInputData(ByVal index As Integer) As PlayerInputData

    'End Function

    ''' <summary>
    ''' プレイヤーモードの切り替え
    ''' </summary>
    ''' <param name="prm_playerMood">プレイヤーモード</param>
    ''' <remarks>１プレイヤーはキーボードとジョイスティック1で操作するか、キーボードのみかを切り替えることができる</remarks>
    Public Sub setPlayerMood(ByVal prm_playerMood As Integer)
        'If m_playerMood <> prm_playerMood Then

        '    'プレイヤーモードを切り替える
        '    m_playerMood = prm_playerMood

        '    'プレイヤー入力情報リストを再セットする
        '    Dim playerCount As Integer = getPlayerCount()
        '    m_aryPlayerInpDt = New ArrayList
        '    For i As Integer = 0 To playerCount - 1
        '        m_aryPlayerInpDt.Add(New PlayerInputData(CST_BTN_CNT))
        '    Next
        'End If
    End Sub

    ''' <summary>
    ''' プレイヤーモードを返す
    ''' </summary>
    ''' <returns>プレイヤーモード</returns>
    ''' <remarks>プレイヤーモードのセッター</remarks>
    Public Function getPlayerMood() As Integer
        'Return m_playerMood
    End Function

    ''' <summary>
    ''' 最大プレイヤー人数を取得する
    ''' </summary>
    ''' <returns>最大プレイヤー人数</returns>
    ''' <remarks></remarks>
    Public Function getPlayerCount() As Integer
        'Dim playerCount As Integer = 0
        'If m_playerMood = CST_1PLAYER_KEY Then
        '    playerCount = Me.getJoystickCount + 1
        'ElseIf m_playerMood = CST_1PLAYER__JOY_AND_KEY Then
        '    playerCount = Me.getJoystickCount
        '    If playerCount = 0 Then playerCount = 1
        'Else
        '    MsgBox("エラー:CDirectInputEx1:getPlayerCount")
        'End If
        'Return playerCount
    End Function
End Class
