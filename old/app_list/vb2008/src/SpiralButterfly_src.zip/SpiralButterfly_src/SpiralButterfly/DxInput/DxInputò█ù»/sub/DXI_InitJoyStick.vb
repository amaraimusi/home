﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput

Public Class DXI_InitJoyStick
    Private joyStickAxisRange As Integer = 1000
    ''' <summary>
    ''' ジョイスティックデバイスの初期化
    ''' </summary>
    ''' <returns>デバイスのリスト</returns>
    ''' <remarks>接続されているジョイスティックのデバイスを取得し、リストにして返す</remarks>
    Public Function InitDevice(ByRef fm As Form) As ArrayList
        'ジョイスティックリスト
        Dim aryDevJoystick As ArrayList = New ArrayList

        'すべてのジョイスティックデバイスを取得しaryDevJoystickに格納する。
        Dim devIns As DeviceInstance
        For Each devIns In Manager.GetDevices(DeviceClass.GameControl, EnumDevicesFlags.AttachedOnly)
            ' Create the device.
            aryDevJoystick.Add(New Device(devIns.InstanceGuid))
        Next devIns

        '検出されたジョイスティックが0件である場合、処理をぬける。
        If aryDevJoystick.Count = 0 Then
            Return aryDevJoystick
        End If

        Dim dev As Device
        For Each dev In aryDevJoystick

            ' Set the cooperative level for the device.(デバイスに強調レベルを設定する。）
            '   ■強調レベルのフラグ説明
            '       ・CooperativeLevelFlags.Background このデバイスは、バックグラウンドで使用可能で、いつでも取得できます。アプリケーション ウィンドウがアクティブでない場合でも取得可能です。 
            '       ・CooperativeLevelFlags.Foreground このデバイスは、アプリケーション ウィンドウがフォアグラウンドにある場合にのみ使えます。アプリケーション ウィンドウがフォーカスを失うと、このデバイスは取得できなくなります。 
            '       ・CooperativeLevelFlags.Exclusive このデバイスは排他アクセスを必要とします。他のアプリケーションはこのデバイスを取得できません。セキュリティ上の理由から、キーボードやマウスなどの特定のデバイスで、このフラグをバックグラウンド フラグと組み合わせて使うことはできません。 
            '       ・CooperativeLevelFlags.NonExclusive このデバイスは、排他アクセスを必要としない他の任意のアプリケーションと共有できます。 
            '       ・CooperativeLevelFlags.NoWindowsKey このフラグは、ウィンドウのキーを無効にします。 
            dev.SetCooperativeLevel(fm, CooperativeLevelFlags.Exclusive Or CooperativeLevelFlags.Foreground)

            ' Enumerate all the objects on the device.(デバイスのオブジェクト郡をすべて列挙する）
            Dim devObjIns As DeviceObjectInstance
            For Each devObjIns In dev.Objects
                ' For axes that are returned, set the DIPROP_RANGE property for the
                ' enumerated axis in order to scale min/max values.（軸の稼動範囲値をセットする）
                If 0 <> (devObjIns.ObjectId And CInt(DeviceObjectTypeFlags.Axis)) Then
                    ' Set the range for the axis.
                    dev.Properties.SetRange(ParameterHow.ById, devObjIns.ObjectId, New InputRange(joyStickAxisRange * -1, joyStickAxisRange))
                End If

            Next devObjIns

            'ジョイスティックを絶対軸モードに設定します。
            dev.Properties.AxisModeAbsolute = True

            dev.Unacquire()
        Next

        Return aryDevJoystick
    End Function
End Class
