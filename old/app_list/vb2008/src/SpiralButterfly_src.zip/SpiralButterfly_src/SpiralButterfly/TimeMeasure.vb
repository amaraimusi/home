﻿''' <summary>
''' 時間測定
''' </summary>
''' <remarks>処理にかかった時間を取得する</remarks>
Public Class TimeMeasure

    Private Const START_MEASURE As Integer = 0
    Private Const END_MEASURE As Integer = 1


    Private m_StateFlg As Integer
    Private m_StartTick As Long
    Private aryRecord As ArrayList
    Private m_msg As String

    ''' <summary>
    ''' 時間測定
    ''' </summary>
    ''' <param name="msg"></param>
    ''' <remarks></remarks>
    Public Sub Measure(ByRef msg As String)
        If m_StateFlg = START_MEASURE Then
            m_StartTick = Now.Ticks
            m_msg = msg
            m_StateFlg = END_MEASURE
        Else
            Dim recTick As Long = m_StartTick - Now.Ticks
            Dim msg2 As String = m_msg & ":" & recTick.ToString
            aryRecord.Add(msg2)
            m_StateFlg = START_MEASURE
        End If
    End Sub
    Public Sub Measure()
        Measure("")
    End Sub

    ''' <summary>
    ''' 記録リストを取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordList() As ArrayList
        Dim rtn As ArrayList = aryRecord.Clone
        aryRecord = New ArrayList
        Return rtn

    End Function

    Public Sub New()
        aryRecord = New ArrayList
    End Sub
End Class
