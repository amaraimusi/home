﻿Imports Microsoft.DirectX.Direct3D
''' <summary>
''' 3D描画を行う
''' </summary>
''' <remarks></remarks>
Public Class DXG_Draw3D
    ''' <summary>
    ''' グラフィックデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device = Nothing ' Our rendering device


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="prm_dev"></param>
    ''' <remarks></remarks>
    Public Sub New(ByRef prm_dev As Device)
        dev = prm_dev

    End Sub

    Public Sub Draw(ByRef d3 As DXG_3DModel)


        Dim ms As Mesh = d3.GetMesh
        Dim mt() As Material = d3.GetMaterial
        Dim tex() As Texture = d3.GetTexture


        For i As Integer = 0 To mt.Length - 1
            With dev
                .Material = mt(i)
                .SetTexture(0, tex(i))
            End With
            ms.DrawSubset(i)
        Next
    End Sub
End Class
