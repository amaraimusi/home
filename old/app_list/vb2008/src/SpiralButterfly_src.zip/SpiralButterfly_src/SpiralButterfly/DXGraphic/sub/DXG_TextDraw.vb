﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

''' <summary>
''' DirectXグラフィックを利用して文字列描画を行う
''' </summary>
''' <remarks>
''' ☆概要
''' DirectXグラフィックを利用して文字列描画を行う
''' ☆履歴
''' 2008/05/29　新規作成
''' </remarks>
Public Class DXG_TextDraw

    ''' <summary>
    ''' グラフィックデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device

    ''' <summary>
    ''' Direct3D 用フォント
    ''' </summary>
    ''' <remarks></remarks>
    Dim m_font As Microsoft.DirectX.Direct3D.Font

    ''' <summary>
    ''' 文字の高さ
    ''' </summary>
    ''' <remarks></remarks>
    Private m_fontHeight As Integer
    ''' <summary>
    ''' 文字幅
    ''' </summary>
    ''' <remarks></remarks>
    Private m_fontWidth As Integer
    ''' <summary>
    ''' イタリック体
    ''' </summary>
    ''' <remarks></remarks>
    Private m_Italic As Boolean


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="prm_dev"></param>
    ''' <remarks></remarks>
    Public Sub New(ByRef prm_dev As Device)
        dev = prm_dev 'グラフィックデバイスをメンバにセット

        '■ フォントの作成
        m_fontHeight = 16   '文字の高さの初期値をセット
        m_fontWidth = 16    '文字幅の初期値をセット
        m_Italic = False    'イタリック体の初期値をセット
        FontSetting()       'フォントの設定と生成
    End Sub


    ''' <summary>
    ''' フォントの設定と生成
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub FontSetting()
        ' フォントデータの構造体を作成
        Dim fontDescription As FontDescription = New FontDescription()

        ' 構造体に必要なデータをセット
        fontDescription.Height = m_fontHeight
        fontDescription.Width = m_fontWidth
        fontDescription.IsItalic = m_Italic
        'fontDescription.FaceName = "ＭＳ ゴシック"

        ' フォントを作成
        m_font = New Microsoft.DirectX.Direct3D.Font(dev, fontDescription)

    End Sub

    ''' <summary>
    ''' 文字を表示する
    ''' </summary>
    ''' <param name="msg">出力する文字</param>
    ''' <param name="pt">出力する座標</param>
    ''' <param name="colors">文字の色</param>
    ''' <remarks>
    ''' </remarks>
    Public Sub DrawText(ByRef msg As String, _
                         ByRef pt As Point, _
                         ByRef colors As Color)

        m_font.DrawText(Nothing, msg, pt, colors)
        'this.font.DrawText(null, "複数行も" + Environment.NewLine + "可能",
    End Sub

    ''' <summary>
    ''' 文字を表示する
    ''' </summary>
    ''' <param name="msg">出力する文字</param>
    ''' <param name="rec">短冊</param>
    ''' <param name="colors">文字の色</param>
    ''' <remarks>
    ''' 短冊中の左上に文字を表示する
    ''' </remarks>
    Public Sub DrawText(ByRef msg As String, _
                         ByRef rec As Rectangle, _
                         ByRef colors As Color)

        m_font.DrawText(Nothing, msg, rec, DrawTextFormat.Left Or DrawTextFormat.Top, colors)
        'this.font.DrawText(null, "複数行も" + Environment.NewLine + "可能",
    End Sub

    ''' <summary>
    ''' 右詰で文字を表示する
    ''' </summary>
    ''' <param name="msg"></param>
    ''' <param name="rec"></param>
    ''' <param name="colors"></param>
    ''' <remarks></remarks>
    Public Sub DrawTextRight(ByRef msg As String, _
                         ByRef rec As Rectangle, _
                         ByRef colors As Color)

        m_font.DrawText(Nothing, msg, rec, DrawTextFormat.Right Or DrawTextFormat.Top, colors)
        'this.font.DrawText(null, "複数行も" + Environment.NewLine + "可能",
    End Sub

    ''' <summary>
    ''' 文字の高さのプロパティ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property FontHeight()
        Get
            Return m_fontHeight
        End Get
        Set(ByVal value)
            m_fontHeight = value

        End Set
    End Property

    ''' <summary>
    ''' 文字幅のプロパティ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property FontWidth()
        Get
            Return m_fontWidth
        End Get
        Set(ByVal value)
            m_fontWidth = value
        End Set
    End Property

    ''' <summary>
    ''' イタリック体のプロパティ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Itaric()
        Get
            Return m_Italic
        End Get
        Set(ByVal value)
            m_Italic = value
        End Set
    End Property
End Class
