﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

''' <summary>
''' DirectX Graphicsの初期化を行う
''' </summary>
''' <remarks>
''' ☆概要
''' DirectX Graphicsの初期化を行う
''' フルスクリーンとウィンドウモードの設定が可能
''' ☆履歴
''' 2008/05/28 新規作成
''' </remarks>
Public Class DXG_Init

    ''' <summary>
    ''' グラフィックデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device = Nothing ' Our rendering device

    ''' <summary>
    ''' DirectXグラフィックの初期化
    ''' </summary>
    ''' <param name="fm">対象フォーム</param>
    ''' <param name="ScreenMode">スクリーンのモード。Trueならウィンドウモード、Falseならフルスクリーンモード</param>
    ''' <remarks></remarks>
    Public Sub InitializeGraphic(ByRef fm As Form, ByVal ScreenMode As Boolean)
        Try
            'グラフィックデバイスのパラメータを生成
            Dim presentParams As PresentParameters = New PresentParameters

            'Trueならウィンドウモード、Falseならフルスクリーンモード
            presentParams.Windowed = ScreenMode

            'Discardにすると、バックバッファの内容を更新せずに表示する
            presentParams.SwapEffect = SwapEffect.Discard

            'グラフィックデバイスを生成する
            dev = CreateDirect3DDevice(presentParams, fm)

            'ライトアップする。３D表示のため
            Init2()
        Catch ex As Exception
            ErrMsg("DXG_Init", "InitializeGraphic", "DirectXグラフィックの初期化に失敗しました。", ex)
        End Try

    End Sub

    Private Sub Init2()
        ' レンダリング時のオプションを指定
        dev.RenderState.ZBufferEnable = True

        ' カメラの設定
        dev.Transform.View = Matrix.LookAtLH(New Vector3(5, 5, -10), New Vector3(0, 0, 0), New Vector3(0.0F, 1.0F, 0.0F))

        ' 投影変換の設定
        dev.Transform.Projection = Matrix.PerspectiveFovLH(CSng(Math.PI / 4), 1.0F, 1.0F, 100.0F)

        ' 照明の設定
        dev.Lights(0).Type = LightType.Directional
        dev.Lights(0).Direction = New Vector3(1, -1, 1)
        dev.Lights(0).Diffuse = Color.FromArgb(255, 255, 255)
        'direct3DDevice_.Lights(0).Commit()
        dev.Lights(0).Enabled = True
    End Sub

    ''' <summary>
    ''' グラフィックデバイスを作成する。
    ''' </summary>
    ''' <param name="presentParameters"></param>
    ''' <param name="fm"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateDirect3DDevice(ByRef presentParameters As PresentParameters, ByRef fm As Form) As Device

        ' Deviceクラスのインスタンスをできるかぎり高性能になるように生成
        Dim result As Device
        ' グラフィックカードのハードウェアアクセラレーションと、ハードウェア頂点処理を行えるDeviceクラスを生成する
        Try
            result = New Device(0, DeviceType.Hardware, fm, CreateFlags.HardwareVertexProcessing, presentParameters)
            Debug.WriteLine("Created HAL & HVP mode.")
        Catch
            '上が失敗したら、ソフトウェア頂点処理のDeviceクラスを生成する
            Try
                result = New Device(0, DeviceType.Hardware, fm, CreateFlags.SoftwareVertexProcessing, presentParameters)
                Debug.WriteLine("Created HAL mode.")
            Catch
                ' それでもダメならリファレンスモードでDeviceクラスを生成する
                Try
                    result = New Device(0, DeviceType.Reference, fm, CreateFlags.SoftwareVertexProcessing, presentParameters)

                Catch ex As Exception
                    result = Nothing
                    ErrMsg("DXG_Init", "CreateDirect3DDevice", "このグラフィックカードはDirect3Dを利用できません。", ex)
                End Try
            End Try
        End Try
        Return result
    End Function

    ''' <summary>
    ''' グラフィックデバイスのGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetDevice() As Device
        Return dev
    End Function

End Class
