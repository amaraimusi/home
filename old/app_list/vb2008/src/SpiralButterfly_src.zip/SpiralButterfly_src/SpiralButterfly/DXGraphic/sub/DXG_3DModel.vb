﻿Imports Microsoft.DirectX.Direct3D
''' <summary>
''' 3Dモデルのデータ
''' </summary>
''' <remarks>
''' ☆概要
''' １つの３Dモデルデータ。メッシュ、マテリアル配列、テクスチャー配列からなる。
''' ☆履歴
''' 2008/5/30　新規作成
''' </remarks>
Public Class DXG_3DModel

    ''' <summary>
    ''' メッシュ。
    ''' </summary>
    ''' <remarks></remarks>
    Private ms As Mesh

    ''' <summary>
    ''' マテリアル配列
    ''' </summary>
    ''' <remarks></remarks>
    Private mt() As Material

    ''' <summary>
    ''' テクスチャー配列
    ''' </summary>
    ''' <remarks></remarks>
    Private tex() As Texture


    ''' <summary>
    ''' メッシュのSetter
    ''' </summary>
    ''' <param name="prm_mesh"></param>
    ''' <remarks></remarks>
    Public Sub SetMesh(ByRef prm_mesh As Mesh)
        ms = prm_mesh
    End Sub
    ''' <summary>
    ''' メッシュのGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetMesh() As Mesh
        Return ms
    End Function

    ''' <summary>
    ''' マテリアル配列のSetter
    ''' </summary>
    ''' <param name="prm_Material"></param>
    ''' <remarks></remarks>
    Public Sub SetMaterial(ByRef prm_Material() As Material)
        mt = prm_Material
    End Sub
    ''' <summary>
    ''' マテリアル配列のGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetMaterial() As Material()
        Return mt
    End Function

    ''' <summary>
    ''' テクスチャー配列のSetter
    ''' </summary>
    ''' <param name="prm_Texture"></param>
    ''' <remarks></remarks>
    Public Sub SetTexture(ByRef prm_Texture() As Texture)
        tex = prm_Texture
    End Sub
    ''' <summary>
    ''' テクスチャー配列のGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetTexture() As Texture()
        Return tex
    End Function


    Protected Overrides Sub Finalize()
        ms.Dispose()

        mt = Nothing
        tex = Nothing

        MyBase.Finalize()
    End Sub
End Class
