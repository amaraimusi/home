﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
''' <summary>
''' Xファイルからメッシュを作成する
''' </summary>
''' <remarks>
''' ☆概要
''' ☆履歴
''' Xファイルからメッシュを作成。またメッシュからXファイルを生成。
''' </remarks>
Public Class DXG_Creat3DModel

    ''' <summary>
    ''' グラフィックデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="prm_dev">グラフィックデバイス</param>
    ''' <remarks>メンバに引数をセットする</remarks>
    Public Sub New(ByRef prm_dev As Device)
        dev = prm_dev
    End Sub


    ''' <summary>
    ''' ３Dモデル情報を生成する
    ''' </summary>
    ''' <param name="xFlNm">Xファイル名</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' メッシュ、マテリアル配列、テクスチャー配列を作成する
    ''' </remarks>
    Public Function Creat3DModel(ByRef xFlNm As String) As DXG_3DModel

        Dim ms As Mesh                              'メッシュ
        Dim exMt As ExtendedMaterial() = Nothing    '拡張マテリアル配列
        Dim mt As Material() = Nothing              'マテリアル配列
        Dim tex As Texture() = Nothing              'テクスチャー配列

        'メッシュを作成する
        ms = Mesh.FromFile(xFlNm, MeshFlags.Managed, dev, exMt)

        '配列の要素数を決定
        ReDim mt(exMt.Length)
        ReDim tex(exMt.Length)

        '■マテリアル配列とテクスチャー配列を読み込む
        For i As Integer = 0 To exMt.Length - 1
            mt(i) = exMt(i).Material3D
            Dim texFlNm As String = exMt(i).TextureFilename
            If Not texFlNm Is Nothing Then
                tex(i) = TextureLoader.FromFile(dev, texFlNm)
            Else
                tex(i) = Nothing
            End If
        Next

        '■３Dモデル情報にセットする
        Dim d3 As New DXG_3DModel
        d3.SetMesh(ms)
        d3.SetMaterial(mt)
        d3.SetTexture(tex)

        Return d3

    End Function

End Class
