﻿
Imports Microsoft.DirectX.Direct3D
Imports Microsoft.DirectX

Public Class DXG_DrawLine

    ''' <summary>
    ''' ライン構造体
    ''' </summary>
    ''' <remarks></remarks>
    Private Structure LineData
        Dim x1 As Single
        Dim y1 As Single
        Dim z1 As Single
        Dim x2 As Single
        Dim y2 As Single
        Dim z2 As Single
        Dim arbg As Integer '線の色
    End Structure

    ''' <summary>
    ''' ライン情報
    ''' </summary>
    ''' <remarks></remarks>
    Private aryLine As ArrayList

    ''' <summary>
    ''' グラフィックデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device = Nothing ' Our rendering device

    ''' <summary>
    ''' 頂点バッファ
    ''' </summary>
    ''' <remarks>頂点情報を格納したメモリ領域</remarks>
    Private vb As VertexBuffer


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="prm_dev"></param>
    ''' <remarks></remarks>
    Public Sub New(ByRef prm_dev As Device)
        dev = prm_dev
        aryLine = New ArrayList
    End Sub

    ''' <summary>
    ''' 線情報追加
    ''' </summary>
    ''' <param name="x1"></param>
    ''' <param name="y1"></param>
    ''' <param name="x2"></param>
    ''' <param name="y2"></param>
    ''' <remarks></remarks>
    Public Sub LineAdd(ByVal x1 As Single, ByVal y1 As Single, ByVal x2 As Single, ByVal y2 As Single)
        LineAdd(x1, y1, x2, y2, Color.Red.ToArgb)

    End Sub
    ''' <summary>
    ''' 線情報追加
    ''' </summary>
    ''' <param name="x1"></param>
    ''' <param name="y1"></param>
    ''' <param name="x2"></param>
    ''' <param name="y2"></param>
    ''' <param name="ColorArgb"></param>
    ''' <remarks></remarks>
    Public Sub LineAdd(ByVal x1 As Single, ByVal y1 As Single, ByVal x2 As Single, ByVal y2 As Single, ByVal ColorArgb As Integer)
        LineAdd(x1, y1, 0.0F, x2, y2, 0.0F, Color.Red.ToArgb)
    End Sub
    ''' <summary>
    ''' 線情報を追加
    ''' </summary>
    ''' <param name="x1"></param>
    ''' <param name="y1"></param>
    ''' <param name="z1"></param>
    ''' <param name="x2"></param>
    ''' <param name="y2"></param>
    ''' <param name="z2"></param>
    ''' <param name="ColorArgb"></param>
    ''' <remarks></remarks>
    Public Sub LineAdd(ByVal x1 As Single, ByVal y1 As Single, ByVal z1 As Single, _
                       ByVal x2 As Single, ByVal y2 As Single, ByVal z2 As Single, _
                        ByVal ColorArgb As Integer)
        Dim lineDt As New LineData
        lineDt.x1 = x1
        lineDt.y1 = y1
        lineDt.z1 = z1
        lineDt.x2 = x2
        lineDt.y2 = y2
        lineDt.z2 = z2
        lineDt.arbg = ColorArgb
        aryLine.Add(lineDt)

    End Sub

    Public Sub Draw()

        Dim lineCnt As Integer = aryLine.Count '線情報数を取得する

        If lineCnt = 0 Then Exit Sub

        '線情報分×２の頂点を作成
        Me.vb = New VertexBuffer(GetType(CustomVertex.PositionColored), _
                lineCnt * 2, dev, 0, CustomVertex.PositionColored.Format, Pool.Managed)

        ' 頂点バッファをロックして、位置、色情報を書き込む
        Dim data As GraphicsStream = vb.Lock(0, 0, LockFlags.None)
        For Each lineDt As LineData In aryLine
            With lineDt
                data.Write(New CustomVertex.PositionColored(.x1, .y1, .z1, .arbg))
                data.Write(New CustomVertex.PositionColored(.x2, .y2, .z2, .arbg))
            End With
        Next
        aryLine = New ArrayList '線情報を初期化
        vb.Unlock() '頂点情報のロックを解除


        'ラインを描画
        dev.SetStreamSource(0, vb, 0)
        dev.VertexFormat = CustomVertex.PositionColored.Format
        dev.DrawPrimitives(PrimitiveType.LineList, 0, lineCnt)
    End Sub

End Class
