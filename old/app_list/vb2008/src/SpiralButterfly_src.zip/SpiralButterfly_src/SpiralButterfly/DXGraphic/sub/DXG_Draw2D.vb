﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
''' <summary>
''' DirectXグラフィックを利用して２D描画を行う。
''' </summary>
''' <remarks>
''' ☆概要
''' DirectXグラフィックを利用して２D描画を行う。
''' Z座標は０で設定されている
''' ☆履歴
''' 2008/05/29
''' </remarks>
Public Class DXG_Draw2D


    ''' <summary>
    ''' グラフィックデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device = Nothing ' Our rendering device
    ''' <summary>
    ''' 頂点バッファ
    ''' </summary>
    ''' <remarks>頂点情報を格納したメモリ領域</remarks>
    Private vb As VertexBuffer


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="prm_dev"></param>
    ''' <remarks></remarks>
    Public Sub New(ByRef prm_dev As Device)
        dev = prm_dev

        initVb() '頂点フォーマットの初期化
    End Sub



    ''' <summary>
    ''' 頂点フォーマットの初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub initVb()
        '空の４つの頂点を準備
        vb = New VertexBuffer(GetType(CustomVertex.TransformedTextured), 4, dev, 0, CustomVertex.TransformedColoredTextured.Format, Pool.Default)

        '▼頂点情報の固定情報。頂点情報を変更するときにはロックをかける。
        Dim Verts As CustomVertex.TransformedTextured() = vb.Lock(0, 0)
        Verts(0).Z = 0.0F
        Verts(0).Rhw = 1
        Verts(0).Tu = 0.0F
        Verts(0).Tv = 0.0F

        Verts(1).Z = 0.0F
        Verts(1).Rhw = 1
        Verts(1).Tu = 1.0F
        Verts(1).Tv = 0.0F

        Verts(2).Z = 0.0F
        Verts(2).Rhw = 1
        Verts(2).Tu = 0.0F
        Verts(2).Tv = 1.0F

        Verts(3).Z = 0.0F
        Verts(3).Rhw = 1
        Verts(3).Tu = 1.0F
        Verts(3).Tv = 1.0F

        vb.Unlock() '頂点情報の変更が終わったのでロックを解除する)
    End Sub

    ''' <summary>
    ''' 描画
    ''' </summary>
    ''' <param name="tex">テクスチャー</param>
    ''' <param name="fPx">描画座標（描画オブジェクトの左上隅の座標）X</param>
    ''' <param name="fPy">描画座標（描画オブジェクトの左上隅の座標）Y</param>
    ''' <param name="width">描画オブジェクトの横幅</param>
    ''' <param name="height">描画オブジェクトの縦幅</param>
    ''' <remarks></remarks>
    Public Sub Draw(ByRef tex As Texture, ByRef fPx As Single, ByRef fPy As Single, ByVal width As Integer, ByVal height As Integer)

        'Dim tex As Texture = Me.getTexture(texId)   'テクスチャーを取得

        '頂点情報配列を取得。頂点情報を変更するときにはロックをかける。
        Dim Verts As CustomVertex.TransformedTextured() = vb.Lock(0, 0)

        '▼頂点情報配列に、描画位置をセット
        Dim fPx2 As Single = fPx + width
        Dim fPy2 As Single = fPy + height
        Verts(0).X = fPx
        Verts(0).Y = fPy
        Verts(1).X = fPx2
        Verts(1).Y = fPy
        Verts(2).X = fPx
        Verts(2).Y = fPy2
        Verts(3).X = fPx2
        Verts(3).Y = fPy2
        vb.Unlock() '頂点情報の変更が終わったのでロックを解除する

        'デバイスに描画情報をセットして描画を行う
        Draw2(tex)
    End Sub

    ''' <summary>
    ''' デバイスに描画情報をセットして描画を行う
    ''' </summary>
    ''' <param name="tex"></param>
    ''' <remarks></remarks>
    Private Sub Draw2(ByRef tex As Texture)
 

        '▼ アルファブレンドの設定 
        dev.RenderState.AlphaBlendEnable = True
        dev.RenderState.SourceBlend = Blend.SourceAlpha
        dev.RenderState.DestinationBlend = Blend.InvSourceAlpha
        '▼デバイスへ描画情報をセットし描画開始
        dev.SetTexture(0, tex)
        'テクスチャーをセット
        dev.SetStreamSource(0, vb, 0)                         '頂点情報をセット
        dev.VertexFormat = CustomVertex.TransformedTextured.Format  '頂点情報構造体をセット
        dev.DrawPrimitives(PrimitiveType.TriangleStrip, 0, 2)       '描画する
    End Sub

    Private Const ANG90 As Single = Math.PI / 2
    Private Const ANG180 As Single = Math.PI
    Private Const ANG270 As Single = Math.PI * 1.5
    ''' <summary>
    ''' ２D描画（回転、拡大縮小可能）
    ''' </summary>
    ''' <param name="tex">テクスチャー</param>
    ''' <param name="p0">中心座標</param>
    ''' <param name="rAng">回転角度（ラジアン）</param>
    ''' <param name="hyp">斜辺　hypotenuse　長方形の中心からある１つの頂点までの距離</param>
    ''' <param name="hypAng">斜辺角度　hypの角度</param>
    ''' <remarks></remarks>
    Public Sub Draw(ByRef tex As Texture, ByRef p0 As PointF, ByVal rAng As Single, ByVal hyp As Single, ByVal hypAng As Single)




        '頂点情報配列を取得。頂点情報を変更するときにはロックをかける。
        Dim Verts As CustomVertex.TransformedTextured() = vb.Lock(0, 0)

      
        Dim a1(3) As Single
        rAng = rAng + ANG90
        a1(0) = hypAng + rAng
        a1(1) = (ANG90 - hypAng) + ANG90 + rAng
        a1(2) = (ANG90 - hypAng) + ANG270 + rAng
        a1(3) = hypAng + ANG180 + rAng
        '▼頂点情報配列に、描画位置をセット
        For i = 0 To 3
            Verts(i).X = p0.X - hyp * Math.Cos(a1(i))
            Verts(i).Y = p0.Y - hyp * Math.Sin(a1(i))
        Next

        vb.Unlock() '頂点情報の変更が終わったのでロックを解除する

        'デバイスに描画情報をセットして描画を行う
        Draw2(tex)
    End Sub

    ''' <summary>
    ''' ２D描画　簡易版（回転、拡大縮小可能）
    ''' </summary>
    ''' <param name="tex">テクスチャー</param>
    ''' <param name="p0">中心座標</param>
    ''' <param name="size_">画像サイズ</param>
    ''' <param name="ang">回転角度</param>
    ''' <remarks>処理にオーバーヘッドが生じるため、多少時間がかかる</remarks>
    Public Sub Draw(ByRef tex As Texture, ByRef p0 As Point, ByRef size_ As Size, ByVal ang As Integer)

        Dim hypAng As Single = Math.Atan(size_.Height / size_.Width) '斜辺角度を算出
        Dim hyp As Single = size_.Width / Math.Cos(hypAng) '斜辺を算出
        Dim rAng As Single = ang * Math.PI / 180 'ラジアン回転角度を求める
        Dim fP0 As PointF = New PointF(CSng(p0.X), CSng(p0.Y)) '浮動小数点中心座標を求める。
        Draw(tex, fP0, rAng, hyp, hypAng) '描画を行う

    End Sub
End Class
