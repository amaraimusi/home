﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports System.Drawing


Public Class DxGraphicControl

    ''' <summary>
    ''' Directグラフィックの初期化オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dxgIni As DXG_Init

    ''' <summary>
    ''' 文字描画オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dxgTxtDraw As DXG_TextDraw

    ''' <summary>
    ''' 2D描画オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dxgD2D As DXG_Draw2D

    ''' <summary>
    ''' 3Dモデル生成オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dxgCrt3D As DXG_Creat3DModel

    ''' <summary>
    ''' ３D描画オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dxgD3D As DXG_Draw3D

    ''' <summary>
    ''' 線描画オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dxgDLine As DXG_DrawLine


    ''' <summary>
    ''' スクリーンモード
    ''' </summary>
    ''' <remarks>
    ''' Trueであればウィンドウモード
    ''' Falseであればフルスクリーンモード
    ''' </remarks>
    Private m_ScreenMode As Boolean = True


    ''' <summary>
    ''' グラフィックデバイス
    ''' </summary>
    ''' <remarks></remarks>
    Private dev As Device = Nothing ' Our rendering device

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fm"></param>
    ''' <remarks></remarks>
    Public Sub New(ByRef fm As Form)

        '■Directグラフィックの初期化とグラフィックデバイスの生成
        dxgIni = New DXG_Init

        dxgIni.InitializeGraphic(fm, m_ScreenMode)
        dev = dxgIni.GetDevice

        dxgTxtDraw = New DXG_TextDraw(dev)  '文字描画オブジェクトの生成
        dxgD2D = New DXG_Draw2D(dev)        '2D描画オブジェクトの生成
        dxgCrt3D = New DXG_Creat3DModel(dev) '３Dモデル生成オジェクトを生成
        dxgD3D = New DXG_Draw3D(dev)        '３D描画オブジェクトを生成
        dxgDLine = New DXG_DrawLine(dev)    '線情報オブジェクトを生成

    End Sub

    ''' <summary>
    ''' 描画処理開始
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DrawStart()
        '画面を綺麗さっぱり指定色で塗りつぶす(初期化)
        dev.Clear(ClearFlags.Target, Color.Blue, 1.0F, 0)

        'シーンを開始
        dev.BeginScene()
    End Sub

    ''' <summary>
    ''' 描画処理終了
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub drawEnd()

        'シーン終了
        dev.EndScene()

        'バックバッファを表示。つまり実際に画面に表示する
        dev.Present()
    End Sub


    ''' <summary>
    ''' スクリーンモードのプロパティ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ScreenMode()
        Get
            Return m_ScreenMode
        End Get
        Set(ByVal value)
            value = m_ScreenMode
        End Set
    End Property

    ''' <summary>
    ''' 文字を表示する
    ''' </summary>
    ''' <param name="msg">出力する文字</param>
    ''' <param name="pt">出力する座標</param>
    ''' <param name="colors">文字の色</param>
    ''' <remarks>
    ''' 次のように文字を指定することにより複数行も可能。
    ''' 「"複数行も" + Environment.NewLine + "可能"」
    ''' </remarks>
    Public Sub DrawText(ByRef msg As String, _
                         ByRef pt As Point, _
                         ByRef colors As Color)

        dxgTxtDraw.DrawText(msg, pt, colors)
    End Sub

    ''' <summary>
    ''' 文字を表示する
    ''' </summary>
    ''' <param name="msg">出力する文字</param>
    ''' <param name="rec">短冊</param>
    ''' <param name="colors">文字の色</param>
    ''' <remarks>
    ''' 短冊中の左上に文字を表示する
    ''' </remarks>
    Public Sub DrawText(ByRef msg As String, _
                         ByRef rec As Rectangle, _
                         ByRef colors As Color)

        dxgTxtDraw.DrawText(msg, rec, colors)
        'this.font.DrawText(null, "複数行も" + Environment.NewLine + "可能",
    End Sub

    ''' <summary>
    ''' 右詰で文字を表示する
    ''' </summary>
    ''' <param name="msg">出力する文字</param>
    ''' <param name="rec">短冊</param>
    ''' <param name="colors">文字の色</param>
    ''' <remarks>
    ''' 短冊中の左上に文字を表示する
    ''' </remarks>
    Public Sub DrawTextRight(ByRef msg As String, _
                         ByRef rec As Rectangle, _
                         ByRef colors As Color)

        dxgTxtDraw.DrawTextRight(msg, rec, colors)
        'this.font.DrawText(null, "複数行も" + Environment.NewLine + "可能",
    End Sub

    ''' <summary>
    ''' フォントスタイルを設定する
    ''' </summary>
    ''' <param name="fontHeight">文字の高さ</param>
    ''' <param name="fontWidth">文字幅</param>
    ''' <param name="itaric">イタリック体</param>
    ''' <remarks></remarks>
    Public Sub FontSetting(ByVal fontHeight As Integer, ByVal fontWidth As Integer, ByVal itaric As Boolean)
        dxgTxtDraw.FontHeight = fontHeight
        dxgTxtDraw.FontWidth = fontWidth
        dxgTxtDraw.Itaric = itaric
        dxgTxtDraw.FontSetting()            'フォントを変更
    End Sub

    ''' <summary>
    ''' テクスチャーを生成する
    ''' </summary>
    ''' <param name="texFlNm">テクスチャーファイル名</param>
    ''' <returns>テクスチャー</returns>
    ''' <remarks></remarks>
    Public Function CreateTextureFromFile(ByRef texFlNm As String)
        Dim tex As Texture = TextureLoader.FromFile(dev, texFlNm)
        Return tex
    End Function

    ''' <summary>
    ''' 2D描画を行う
    ''' </summary>
    ''' <param name="tex">テクスチャー</param>
    ''' <param name="fPx">位置X</param>
    ''' <param name="fPy">位置Y</param>
    ''' <param name="width">幅</param>
    ''' <param name="height">高さ</param>
    ''' <remarks></remarks>
    Public Sub Draw2D(ByRef tex As Texture, ByRef fPx As Single, ByRef fPy As Single, ByVal width As Integer, ByVal height As Integer)
        dxgD2D.Draw(tex, fPx, fPy, width, height)
    End Sub

    ''' <summary>
    ''' ２D描画（回転、拡大縮小可能）
    ''' </summary>
    ''' <param name="tex">テクスチャー</param>
    ''' <param name="p0">中心座標</param>
    ''' <param name="rAng">回転角度（ラジアン）</param>
    ''' <param name="hyp">斜辺　hypotenuse　長方形の中心からある１つの頂点までの距離</param>
    ''' <param name="hypAng">斜辺角度　hypの角度</param>
    ''' <remarks></remarks>
    Public Sub Draw2D(ByRef tex As Texture, ByRef p0 As PointF, ByRef rAng As Single, ByVal hyp As Single, ByVal hypAng As Single)
        dxgD2D.Draw(tex, p0, rAng, hyp, hypAng)
    End Sub

    ''' <summary>
    ''' ２D描画　簡易版（回転、拡大縮小可能）
    ''' </summary>
    ''' <param name="tex">テクスチャー</param>
    ''' <param name="p0">中心座標</param>
    ''' <param name="size_">画像サイズ</param>
    ''' <param name="ang">回転角度</param>
    ''' <remarks>処理にオーバーヘッドが生じるため、多少時間がかかる</remarks>
    Public Sub Draw2D(ByRef tex As Texture, ByRef p0 As Point, ByRef size_ As Size, ByVal ang As Integer)
        dxgD2D.Draw(tex, p0, size_, ang)
    End Sub

    ''' <summary>
    ''' ３Dモデル情報を生成する
    ''' </summary>
    ''' <param name="xFlNm">Xファイル名</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' メッシュ、マテリアル配列、テクスチャー配列を作成する
    ''' </remarks>
    Public Function Creat3DModel(ByRef xFlNm As String) As DXG_3DModel
        Return dxgCrt3D.Creat3DModel(xFlNm)
    End Function

    ''' <summary>
    ''' ３D描画
    ''' </summary>
    ''' <param name="d3"></param>
    ''' <remarks></remarks>
    Public Sub Draw3D(ByRef d3 As DXG_3DModel)
        dxgD3D.Draw(d3)
    End Sub

    ''' <summary>
    ''' 線情報追加
    ''' </summary>
    ''' <param name="x1"></param>
    ''' <param name="y1"></param>
    ''' <param name="x2"></param>
    ''' <param name="y2"></param>
    ''' <remarks></remarks>
    Public Sub LineAdd(ByVal x1 As Single, ByVal y1 As Single, ByVal x2 As Single, ByVal y2 As Single)
        dxgDLine.LineAdd(x1, y1, x2, y2, Color.Red.ToArgb)

    End Sub
    ''' <summary>
    ''' 線情報追加
    ''' </summary>
    ''' <param name="x1"></param>
    ''' <param name="y1"></param>
    ''' <param name="x2"></param>
    ''' <param name="y2"></param>
    ''' <param name="ColorArgb"></param>
    ''' <remarks></remarks>
    Public Sub LineAdd(ByVal x1 As Single, ByVal y1 As Single, ByVal x2 As Single, ByVal y2 As Single, ByVal ColorArgb As Integer)
        dxgDLine.LineAdd(x1, y1, 0.0F, x2, y2, 0.0F, Color.Red.ToArgb)
    End Sub
    ''' <summary>
    ''' 線情報を追加
    ''' </summary>
    ''' <param name="x1"></param>
    ''' <param name="y1"></param>
    ''' <param name="z1"></param>
    ''' <param name="x2"></param>
    ''' <param name="y2"></param>
    ''' <param name="z2"></param>
    ''' <param name="ColorArgb"></param>
    ''' <remarks></remarks>
    Public Sub LineAdd(ByVal x1 As Single, ByVal y1 As Single, ByVal z1 As Single, _
                       ByVal x2 As Single, ByVal y2 As Single, ByVal z2 As Single, _
                        ByVal ColorArgb As Integer)

        dxgDLine.LineAdd(x1, y1, z1, x2, y2, z2, ColorArgb)
    End Sub
    ''' <summary>
    ''' ライン描画
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DrawLine()
        dxgDLine.Draw()
    End Sub

    Protected Overrides Sub Finalize()
        dev.Dispose()

        MyBase.Finalize()
    End Sub
End Class
