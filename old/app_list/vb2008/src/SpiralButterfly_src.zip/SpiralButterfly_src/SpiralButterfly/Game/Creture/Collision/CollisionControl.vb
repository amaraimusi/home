﻿''' <summary>
''' 衝突制御
''' </summary>
''' <remarks></remarks>
Public Class CollisionControl

    ''' <summary>
    ''' クリーチャー情報
    ''' </summary>
    ''' <remarks></remarks>
    Private aryCrt As ArrayList

    ''' <summary>
    ''' 衝突処理配列
    ''' </summary>
    ''' <remarks></remarks>
    Private colls(,) As ICollision

    ''' <summary>
    '''  '衝突部位絶対座標算出オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private ccap As CalcCollAbsPoint

    ''' <summary>
    ''' 衝突共通処理
    ''' </summary>
    ''' <remarks></remarks>
    Private com As CollisionCommon

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="prm_aryCrt">クリーチャー情報</param>
    ''' <remarks></remarks>
    Public Sub New(ByRef prm_aryCrt As ArrayList)

        aryCrt = prm_aryCrt
        ccap = New CalcCollAbsPoint(aryCrt) '衝突部位絶対座標算出オブジェクトを生成

        '■衝突処理配列の初期化
        Dim collsCnt As Integer = CrtGrpConst.OBJ + 1
        ReDim colls(collsCnt, collsCnt)
        For x As Integer = 0 To collsCnt - 1
            For y As Integer = 0 To collsCnt - 1
                colls(x, y) = Nothing
            Next
        Next


        com = New CollisionCommon
        Dim hb_zk As collHBeamZako = New collHBeamZako(com)

        colls(CrtGrpConst.HBEAM, CrtGrpConst.ZAKO) = hb_zk
        colls(CrtGrpConst.ZAKO, CrtGrpConst.HBEAM) = hb_zk


    End Sub

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="prm_StgCon"></param>
    ''' <param name="prm_CrtCon"></param>
    ''' <param name="prm_HPrmCon"></param>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_StgCon As StageControl, _
                    ByRef prm_CrtCon As CrtControl, _
                    ByRef prm_HPrmCon As HeroParameterControl)
        com.Init(prm_StgCon, prm_CrtCon, prm_HPrmCon)
    End Sub

    ''' <summary>
    ''' 当たり判定
    ''' </summary>
    ''' <remarks>
    ''' クリーチャー同士の衝突による判定。
    ''' </remarks>
    Public Sub Collision()
        ccap.Calc() ' 衝突部位絶対座標を算出する

        Collision2(CrtGrpConst.HBEAM, CrtGrpConst.ZAKO) '主人公光線とザコの衝突処理
    End Sub


    Private Sub Collision2(ByVal grpId1 As Integer, ByVal grpId2 As Integer)
        '■クリーチャーリストから指定のクリーチャーグループを取得する
        Dim crts1() As Creture = CType(aryCrt(grpId1), Creture())
        Dim crts2() As Creture = CType(aryCrt(grpId2), Creture())

        For i1 As Integer = 0 To crts1.Length - 1 'クリーチャーグループ１の件数分、以下の衝突処理を繰り返す。
            If crts1(i1).PreFlg = True Then '登場フラグがTureの場合のみ以下の衝突処理を行う。
                Dim ang1 As Single = crts1(i1).Ang 'クリーチャー１の向き角度を取得
                For i2 As Integer = 0 To crts2.Length - 1 'クリーチャーグループ２の件数分、以下の衝突処理を繰り返す。
                    If crts2(i2).PreFlg = True Then '登場フラグがTureの場合のみ以下の衝突処理を行う。
                        Dim ang2 As Single = crts2(i2).Ang 'クリーチャー２の向き角度を取得
                        Dim aryColl1 As ArrayList = crts1(i1).GetAryColl 'クリーチャー１の衝突部位数を取得する
                        Dim aryColl2 As ArrayList = crts2(i2).GetAryColl 'クリーチャー２の衝突部位数を取得する
                        If aryColl1.Count <> 0 And aryColl2.Count <> 0 Then
                            '■クリーチャー１衝突部位とクリーチャー２衝突部位の全組合せ分、以下の衝突判定を行う。
                            For Each c1 As CrtCollisionEntity In aryColl1
                                For Each c2 As CrtCollisionEntity In aryColl2
                                    Dim distX As Single = c1.AbsPx - c2.AbsPx '距離Xを取得
                                    Dim distY As Single = c1.AbsPy - c2.AbsPy '距離Yを取得
                                    Dim distHyp As Single = (distX ^ 2 + distY ^ 2) ^ 0.5 '距離を取得
                                    If distHyp <= c1.CollRadius + c2.CollRadius Then '当たり判定を行う。この条件に該当する場合、衝突しているとみなす。
                                        colls(grpId1, grpId2).Collision(crts1(i1), c1, crts2(i2), c2) '衝突処理
                                    End If

                                Next
                            Next
                        End If

                    End If
                Next
            End If
        Next

    End Sub


End Class
