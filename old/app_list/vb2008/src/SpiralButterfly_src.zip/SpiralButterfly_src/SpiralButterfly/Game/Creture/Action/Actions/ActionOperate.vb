﻿''' <summary>
''' 入力によるアクション
''' </summary>
''' <remarks></remarks>
Public Class ActionOperate
    Implements IAction

    Private mainSize As Size

    ''' <summary>
    ''' アクション共通ロジック
    ''' </summary>
    ''' <remarks></remarks>
    Dim acl As ActionCommon

    Public Sub New(ByRef prm_acl As ActionCommon)
        acl = prm_acl
        mainSize = acl.GetMainSize
    End Sub


    Public Sub Action(ByRef crt As Creture) Implements IAction.Action
        '■書類の取得
        Dim doc As ActDocOperate = CType(crt.GetActDoc, ActDocOperate)
        If doc Is Nothing Then
            doc = New ActDocOperate
            doc.hypMove = crt.Speed * CSng(Math.Cos(Math.PI / 4))
            crt.SetActDoc(doc)
            crt.Ang = Math.PI / 2 * 3
        End If

        Move(crt, doc) '移動制御
        FireNormalBeam(crt) ' 通常光線発射
    End Sub

    ''' <summary>
    ''' 通常光線発射
    ''' </summary>
    ''' <param name="crt"></param>
    ''' <remarks></remarks>
    Private Sub FireNormalBeam(ByRef crt As Creture)
        '光線発射ボタンが押されている間、指定の間隔で

        Dim pid As PlayerInputData = acl.GetPlayerData
        If pid.Btn(1) <> 0 Then
            acl.Fire(crt, 1) '光線発射その１
            acl.Fire(crt, 0) '光線発射その２
        End If

    End Sub

    ''' <summary>
    ''' 主人公の移動
    ''' </summary>
    ''' <param name="crt"></param>
    ''' <param name="doc"></param>
    ''' <remarks></remarks>
    Private Sub Move(ByRef crt As Creture, ByRef doc As ActDocOperate)
        '■移動制御
        Dim hyp As Single = doc.hypMove '斜め移動距離
        Dim pid As PlayerInputData = acl.GetPlayerData
        Dim axis() As Integer = pid.GetAxis


        If axis(PlayerInputData.AXIS_TOP) And axis(PlayerInputData.AXIS_RIGHT) Then
            SetPos(crt, hyp, -hyp)
        ElseIf axis(PlayerInputData.AXIS_RIGHT) And axis(PlayerInputData.AXIS_BOTTOM) Then
            SetPos(crt, hyp, hyp)
        ElseIf axis(PlayerInputData.AXIS_BOTTOM) And axis(PlayerInputData.AXIS_LEFT) Then
            SetPos(crt, -hyp, hyp)
        ElseIf axis(PlayerInputData.AXIS_LEFT) And axis(PlayerInputData.AXIS_TOP) Then
            SetPos(crt, -hyp, -hyp)
        ElseIf axis(PlayerInputData.AXIS_TOP) Then
            SetPos(crt, 0.0F, -crt.Speed)
        ElseIf axis(PlayerInputData.AXIS_RIGHT) Then
            SetPos(crt, crt.Speed, 0.0F)
        ElseIf axis(PlayerInputData.AXIS_BOTTOM) Then
            SetPos(crt, 0.0F, crt.Speed)
        ElseIf axis(PlayerInputData.AXIS_LEFT) Then
            SetPos(crt, -crt.Speed, 0.0F)
        End If
    End Sub

    ''' <summary>
    ''' 位置をセットする
    ''' </summary>
    ''' <param name="crt"></param>
    ''' <param name="m_x"></param>
    ''' <param name="m_y"></param>
    ''' <remarks>画面の外へでないよう制御されている</remarks>
    Private Sub SetPos(ByRef crt As Creture, ByVal m_x As Single, ByVal m_y As Single)
        With crt
            Dim bx As Single = .p0.X + m_x
            Dim by As Single = .p0.Y + m_y
            '■画面外には移動できないようにする
            If bx >= 0 And bx < mainSize.Width Then
                If by >= 0 And by < mainSize.Height Then
                    .p0.X = bx
                    .p0.Y = by
                End If

            End If
        End With
    End Sub

End Class
