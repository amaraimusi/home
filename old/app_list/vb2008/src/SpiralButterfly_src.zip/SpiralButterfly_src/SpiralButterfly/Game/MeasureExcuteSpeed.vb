﻿''' <summary>
''' 計算速度測定
''' </summary>
''' <remarks>
''' 測定開始から測定終了までの時間を記録する
''' </remarks>
Module MeasureExcuteSpeed

    Private m_recordTick As Long
    Private m_FirstTime As Long

    ''' <summary>
    ''' 測定開始
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub MES_Start()
        m_FirstTime = Now.Ticks
    End Sub

    ''' <summary>
    ''' 測定終了
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub MES_End()
        m_recordTick = Now.Ticks - m_FirstTime
    End Sub
    ''' <summary>
    ''' 測定結果を取得
    ''' </summary>
    ''' <returns>記録時間</returns>
    ''' <remarks></remarks>
    Public Function MES_GetRecordTick() As Long
        Return m_recordTick
    End Function
End Module
