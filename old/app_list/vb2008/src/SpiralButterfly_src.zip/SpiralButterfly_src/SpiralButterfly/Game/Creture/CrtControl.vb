﻿''' <summary>
''' クリーチャー制御
''' </summary>
''' <remarks>
''' ゲーム進行中に登場するクリーチャーを制御する
''' 登場中のクリーチャーを管理する
''' クリーチャーを登場させる
''' 当たり判定を行う。
''' </remarks>
Public Class CrtControl

#Region "メンバオブジェクト"
    ''' <summary>
    ''' クリーチャーリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private aryCrt As ArrayList

    ''' <summary>
    ''' アクション制御
    ''' </summary>
    ''' <remarks></remarks>
    Private AC As ActionControl

    ''' <summary>
    ''' クリーチャーエントリー
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtEntry As CretureEntry

    ''' <summary>
    ''' クリーチャーの描画を行う
    ''' </summary>
    ''' <remarks></remarks>
    Private DrawCrt As DrawCretures

    ''' <summary>
    ''' クリーチャー画面外消滅
    ''' </summary>
    ''' <remarks></remarks>
    Private OLost As CrtOutLost

    ''' <summary>
    ''' 衝突制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CollCon As CollisionControl

    ''' <summary>
    ''' フレーム描画
    ''' </summary>
    ''' <remarks></remarks>
    Private DFrame As FrameDraw

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' 主人公パラメータ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private HPrmCon As HeroParameterControl

#End Region


#Region "キー定数"
    Private Const CNT_HERO As Integer = 4 '味方の最大数
    Private Const CNT_HBEAM As Integer = 30 '味方光線の最大数
    Private Const CNT_HSP As Integer = 15 '味方特殊の最大数
    Private Const CNT_ZAKO As Integer = 20 'ザコの最大数
    Private Const CNT_BOSS As Integer = 3 'ボスの最大数
    Private Const CNT_RIVAL As Integer = 2 'ライバルの最大数
    Private Const CNT_EBEAM As Integer = 40 '敵光線の最大数
    Private Const CNT_ESP As Integer = 20 '敵特殊の最大数
    Private Const CNT_ITEM As Integer = 30 'アイテムの最大数
    Private Const CNT_OBJ As Integer = 30 '物の最大数

#End Region

    ''' <summary>
    ''' クリーチャーライブラリ
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtLib As CrtLibraly

    Public Sub New(ByRef prm_crtLib As CrtLibraly)
        '■メンバにセット
        CrtLib = prm_crtLib

        '■クリーチャーリストを生成する
        Dim cnt(CNT_OBJ + 1) As Integer
        cnt(CrtGrpConst.HERO) = CNT_HERO
        cnt(CrtGrpConst.HBEAM) = CNT_HBEAM
        cnt(CrtGrpConst.HSP) = CNT_HSP
        cnt(CrtGrpConst.ZAKO) = CNT_ZAKO
        cnt(CrtGrpConst.BOSS) = CNT_BOSS
        cnt(CrtGrpConst.RIVAL) = CNT_RIVAL
        cnt(CrtGrpConst.EBEAM) = CNT_EBEAM
        cnt(CrtGrpConst.ESP) = CNT_ESP
        cnt(CrtGrpConst.ITEM) = CNT_ITEM
        cnt(CrtGrpConst.OBJ) = CNT_OBJ

    
        aryCrt = New ArrayList
        For i As Integer = 0 To CrtGrpConst.OBJ
            Dim crts(cnt(i)) As Creture
            For k As Integer = 0 To crts.Length - 1
                crts(k) = New Creture
            Next
            aryCrt.Add(crts)
        Next


    End Sub

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_StgCon As StageControl, _
                    ByRef prm_HPrmCon As HeroParameterControl)
        '■引数オブジェクトをメンバオブジェクトにセット
        StgCon = prm_StgCon
        HPrmCon = prm_HPrmCon

        '■アクション制御を生成
        AC = New ActionControl
        AC.Init(prm_StgCon, Me, prm_HPrmCon)

        'クリーチャーエントリーオブジェクトを生成する
        CrtEntry = New CretureEntry(CrtLib, aryCrt)

        '■クリーチャー描画オブジェクトを生成
        DrawCrt = New DrawCretures(aryCrt)

        '■クリーチャー画面外消滅オブジェクトを生成
        OLost = New CrtOutLost(aryCrt)

        '■衝突制御オブジェクトを生成
        CollCon = New CollisionControl(aryCrt)
        CollCon.Init(prm_StgCon, Me, prm_HPrmCon)

        '■フレーム描画オブジェクトを生成
        DFrame = New FrameDraw(aryCrt)

    End Sub



    ''' <summary>
    ''' 全クリーチャーを取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAryCrt() As ArrayList

        Return aryCrt
    End Function

    ''' <summary>
    ''' クリーチャーを出現させる。
    ''' </summary>
    ''' <param name="crtId"></param>
    ''' <param name="p0"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Entry(ByVal crtId As Integer, ByRef p0 As PointF) As Creture
        Return CrtEntry.Entry(crtId, p0)
    End Function

    ''' <summary>
    ''' 当たり判定（衝突処理）
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Collision()
        CollCon.Collision() '衝突処理
    End Sub

    ''' <summary>
    ''' 全クリーチャーのアクション
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Action()
        For Each crts As Creture() In aryCrt
            For Each crt As Creture In crts
                With crt
                    If .PreFlg = True Then
                        AC.Action(crt) 'アクションを行う
                    End If
                End With
            Next
        Next
    End Sub

    ''' <summary>
    ''' クリーチャー画面外消滅処理
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub OutLost()
        OLost.OutLost()
    End Sub

    ''' <summary>
    ''' クリーチャーの描画を行う
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Draw()
        DrawCrt.Draw()
    End Sub

    ''' <summary>
    ''' クリーチャーのフレーム描画を行う
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DrawFrame()
        DFrame.Draw()
    End Sub

End Class
