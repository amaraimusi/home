﻿Public Class GameMaster

    ''' <summary>
    ''' クリーチャーライブラリ
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtLib As CrtLibraly

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CC As CrtControl

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private SC As StageControl

    ''' <summary>
    ''' 主人公パラメータ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private HPrmCon As HeroParameterControl

    ''' <summary>
    ''' 描画オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private DXG As DxGraphicControl

    ''' <summary>
    ''' 効果音制御
    ''' </summary>
    ''' <remarks></remarks>
    Private EfSndCon As EffectSoundControl

    ''' <summary>
    ''' アプリケーションコンテナ
    ''' </summary>
    ''' <remarks></remarks>
    Private app As AppContainer


    ''' <summary>
    ''' 時間測定
    ''' </summary>
    ''' <remarks></remarks>
    Private TM As New TimeMeasure

    Public Sub New(ByRef prm_StgCon As StageControl, ByRef prm_CrtLib As CrtLibraly, _
                   ByRef prm_CrtCon As CrtControl, ByRef prm_HPrmCon As HeroParameterControl)
        '■メンバにセット
        SC = prm_StgCon
        CrtLib = prm_CrtLib
        CC = prm_CrtCon
        HPrmCon = prm_HPrmCon

        app = AppContainer.getInstance
        DXG = app.GetDxg '描画オブジェクトを取得する
        EfSndCon = app.GetEfSnd
    End Sub

    Private m_iniFlg As Boolean = False

    ''' <summary>
    ''' ゲームスレッド
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function TreadRun() As Boolean
        If m_iniFlg = False Then
            m_iniFlg = True
            SC.ActiveStageId = 0
            CC.Entry(0, New PointF(100.0F, 100.0F)) '■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□
        End If

        '■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□
        Dim eCrtId As Integer = -1
        Try
            TM.Measure("動的ザコ出現処理時間")
            SC.AppearZako() '動的出現ザコ
            TM.Measure()
        Catch ex As Exception
            ErrMsg("GameMaster", "TreadRun", "動的ザコ出現でエラー", ex)
        End Try

        Try

            TM.Measure("アクション時間")
            CC.Action() '全クリーチャーのアクション
            TM.Measure()
        Catch ex As Exception
            ErrMsg("GameMaster", "TreadRun", "クリーチャー制御のアクション実行でエラー", ex)
        End Try

        Try

            TM.Measure("衝突処理時間")
            CC.Collision() '全クリーチャーの衝突処理
            TM.Measure()
        Catch ex As Exception
            ErrMsg("GameMaster", "TreadRun", "衝突処理実行でエラー", ex)
        End Try

        Try

            TM.Measure("画面外消滅時間")
            CC.OutLost() 'クリーチャー画面外消滅
            TM.Measure()
        Catch ex As Exception
            ErrMsg("GameMaster", "TreadRun", "クリーチャー制御の画面外消滅処理でエラー", ex)
        End Try

        Try

            HPrmCon.Update()
        Catch ex As Exception
            ErrMsg("GameMaster", "TreadRun", "主人公パラメータ更新処理でエラー", ex)
        End Try

        '■効果音を鳴らす
        EfSndCon.Play()

        Randomize() 'ランダム初期化
    End Function

    Private Sub PrintTimeRecord()
        Dim aryTmRec As ArrayList = TM.GetRecordList
        Dim iniX As Integer = 50
        Dim iniY As Integer = 100
        Dim y As Integer = 0
        Dim i As Integer = 0
        Dim kankaku As Integer = 15
        For Each msg As String In aryTmRec
            y = kankaku * i + iniY
            i += 1
            Dim pt As New Point(iniX, y)

            DXG.DrawText(msg, pt, Color.GreenYellow)

        Next
    End Sub

    Public Sub Draw()

        DXG.DrawStart()

        TM.Measure("クリーチャー描画時間")
        CC.Draw() '全クリーチャーを描画
        HPrmCon.Draw() '主人公パラメータを描画

        TM.Measure()
        PrintTimeRecord()

        DXG.drawEnd()
        PrintTimeRecord()
    End Sub



    ''' <summary>
    ''' フレーム描画
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DrawFrame()

        TM.Measure("クリーチャーフレーム描画時間")


        CC.DrawFrame() '全クリーチャーを描画


        TM.Measure()
        PrintTimeRecord()
    End Sub

    ''' <summary>
    ''' ステージ制御のGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetStageControl() As StageControl
        Return SC
    End Function
    ''' <summary>
    ''' クリーチャーライブラリのGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetCrtLib() As CrtLibraly
        Return CrtLib
    End Function
    ''' <summary>
    ''' クリーチャー制御のGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetCrtControl() As CrtControl
        Return CC
    End Function
End Class
