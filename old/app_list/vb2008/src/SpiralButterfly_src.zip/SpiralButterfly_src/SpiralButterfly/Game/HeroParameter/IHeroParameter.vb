﻿''' <summary>
''' 主人公パラメータのインターフェース
''' </summary>
''' <remarks></remarks>
Public Interface IHeroParameter
    ''' <summary>
    ''' 情報を更新する
    ''' </summary>
    ''' <remarks></remarks>
    Sub Update()
    ''' <summary>
    ''' パラメータを描画する
    ''' </summary>
    ''' <remarks></remarks>
    Sub Draw(ByRef pt As PointF)

End Interface
