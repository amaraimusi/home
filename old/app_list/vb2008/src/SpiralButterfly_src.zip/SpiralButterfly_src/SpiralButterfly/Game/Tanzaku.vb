﻿Imports Microsoft.DirectX.Direct3D

''' <summary>
''' 短冊状のテクスチャーの情報
''' </summary>
''' <remarks>情報の保持とテクスチャー描画も行う</remarks>
Public Class Tanzaku
    ''' <summary>
    ''' テクスチャー
    ''' </summary>
    ''' <remarks></remarks>
    Private Tex As Texture

    ''' <summary>
    ''' 位置サイズ情報
    ''' </summary>
    ''' <remarks></remarks>
    Public Rect As RectangleF

    ''' <summary>
    ''' DirectXグラフィック制御
    ''' </summary>
    ''' <remarks></remarks>
    Private Dxg As DxGraphicControl

    ''' <summary>
    ''' テクスチャーと位置情報を作成する
    ''' </summary>
    ''' <param name="texFlNm"></param>
    ''' <param name="prm_rect"></param>
    ''' <remarks></remarks>
    Public Sub New(ByRef texFlNm As String, ByRef prm_rect As RectangleF)
        Dxg = AppContainer.getInstance.GetDxg
        Tex = Dxg.CreateTextureFromFile(texFlNm)
        Rect = prm_rect
    End Sub

    ''' <summary>
    ''' 描画する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Draw()
        With Rect
            Dxg.Draw2D(Tex, .X, .Y, .Width, .Height)
        End With

    End Sub
End Class
