﻿Public Interface IAction
    Sub Action(ByRef crt As Creture)

End Interface
