﻿''' <summary>
''' クリーチャーライブラリ衝突情報を制御する
''' </summary>
''' <remarks></remarks>
Public Class CL_CollEntControl

#Region "定数"
    Public Shared CST_CRTID As String = "CrtId" ' クリーチャーＩＤ
    Public Shared CST_COLLID As String = "CollId" ' 衝突部位ＩＤ
    Public Shared CST_NAME As String = "Name" ' 衝突部位名
    Public Shared CST_RELPX As String = "RelPx" ' 衝突相対座標
    Public Shared CST_RELPY As String = "RelPy" ' 衝突相対座標
    Public Shared CST_AP As String = "AP" ' 攻撃力
    Public Shared CST_DP As String = "DP" ' 防御力
    Public Shared CST_COLLRADIUS As String = "CollRadius" ' 衝突範囲半径
#End Region

    ''' <summary>
    ''' クリーチャーエンティティ配列にCrt衝突情報をセットする。
    ''' </summary>
    ''' <param name="clEnt"></param>
    ''' <param name="dao"></param>
    ''' <remarks></remarks>
    Public Sub SetData(ByRef clEnt As CrtLibEntity(), ByRef dao As IDao)
        Dim calcPha As New CalcHypAng '距離角度座標計算
        Try
            '■DBよりCrt衝突データセットを取得する
            Dim sql As String = "SELECT * FROM CrtCollTbl"
            Dim dtSet As DataSet = dao.getDataSet(sql)

            For Each r As DataRow In dtSet.Tables(0).Rows
                With clEnt(CType(r(CST_CRTID), Integer))

                    '■Crt衝突エンティティにデータセットの値をセットする。
                    Dim ent As New CrtLibCollsionEntity
                    With ent
                        .CrtId = CType(r(CST_CRTID), Integer) 'クリーチャーＩＤ
                        .CollId = CType(r(CST_COLLID), Integer) '衝突部位ＩＤ
                        .Name = CType(r(CST_NAME) & "", String) '衝突部位名
                        .AP = CType(r(CST_AP), Integer) '攻撃力
                        .DP = CType(r(CST_DP), Integer) '防御力
                        .CollRadius = CType(r(CST_COLLRADIUS), Single) '衝突範囲半径

                        '▼衝突相対距離角度座標を算出してセットする。
                        Dim relPx As Single = CType(r(CST_RELPX), Single) '衝突相対座標
                        Dim relPy As Single = CType(r(CST_RELPY), Single) '衝突相対座標
                        
                        .SetPha(calcPha.Calc(relPx, relPy)) '距離角度座標の算出とセット
                        
                    End With

                    '■衝突リストに追加
                    Dim ary As ArrayList = .GetAryCollision
                    ary.Add(ent)

                End With

            Next
        Catch ex As Exception

            ErrMsg("CL_FireEntControl", "SetData", "情報の取得に失敗しました。", ex)
        End Try

    End Sub
End Class
