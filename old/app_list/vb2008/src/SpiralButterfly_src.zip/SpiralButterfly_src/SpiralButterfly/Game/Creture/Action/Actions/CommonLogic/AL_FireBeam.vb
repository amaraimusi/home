﻿''' <summary>
''' 光線発射
''' </summary>
''' <remarks></remarks>
Public Class AL_FireBeam

    Private CrtCon As CrtControl

    Private EfSndCon As EffectSoundControl

    Private CST_ANG90 As Single

    Public Sub New(ByRef prm_CrtCon As CrtControl)
        CrtCon = prm_CrtCon
        CST_ANG90 = Math.PI / 2
        EfSndCon = AppContainer.getInstance.GetEfSnd
    End Sub


    Public Sub Fire(ByRef crt As Creture, ByVal MuzzleId As Integer)
        Dim aryFire As ArrayList = crt.GetAryFire
        If aryFire.Count > MuzzleId Then
            Dim fireEnt As CrtFireEntity = aryFire(MuzzleId)


            With fireEnt
                If .IntervalCounter = 0 Then '光線発射をする。
                    Dim ang0 As Single = .MuzzleAng + crt.Ang + CST_ANG90
                    Dim p0 As New PointF
                    p0.X = crt.p0.X + .MuzzleHyp * Math.Cos(ang0)
                    p0.Y = crt.p0.Y + .MuzzleHyp * Math.Sin(ang0)


                    .IntervalCounter = .Interval
                    Dim beamCrt As Creture = CrtCon.Entry(.FireCrtId, p0) '光線を登録する
                    beamCrt.Speed = .Speed
                    beamCrt.Ang = crt.Ang
                    beamCrt.AngVector = crt.Ang

                    EfSndCon.PlayAdd(5) '発射音を鳴らす
                Else '発射間隔を空けるため発射は行わない。

                    .IntervalCounter -= 1
                End If
            End With
        End If
    End Sub

End Class
