﻿Public Class ActDocOperate
    Inherits ActionDoc

    ''' <summary>
    ''' 斜め移動距離
    ''' </summary>
    ''' <remarks></remarks>
    Public hypMove As Single
End Class
