﻿''' <summary>
''' 直線移動
''' </summary>
''' <remarks></remarks>
Public Class ActionStraight
    Implements IAction


    Public Sub Action(ByRef crt As Creture) Implements IAction.Action
        With crt
            Dim m_x As Single = .Speed * Math.Cos(.AngVector)
            Dim m_y As Single = .Speed * Math.Sin(.AngVector)
            .p0.X += m_x
            .p0.Y += m_y

        End With
    End Sub
End Class
