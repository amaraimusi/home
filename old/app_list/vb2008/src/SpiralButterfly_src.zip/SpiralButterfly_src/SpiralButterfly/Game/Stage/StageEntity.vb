﻿''' <summary>
''' ステージエンティティ
''' </summary>
''' <remarks></remarks>
Public Class StageEntity
    Public Id As Integer 'ステージＩＤ
    Public Name As String 'ステージ名
    Public Coment As String 'コメント
    Public BgmId As Integer 'ステージ音楽ＩＤ
    Public HaikeiId As Integer '背景画像ＩＤ
    Public Lenght As Integer 'ステージ長さ
    Public BossId As Integer 'ボスＩＤ
    Public MaxZakoAppRate As Integer '最大雑魚出現率
    Public MinZakoAppRate As Integer '最小雑魚出現率
    Public ZakoAppExchangeRate As Integer '雑魚出現変化率
    Private aryAppZako As New ArrayList '自動雑魚出現リスト

    ''' <summary>
    ''' 自動出現雑魚リストのＳｅｔｔｅｒ
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetAryAppZako(ByRef prm_aryAppZako As ArrayList)
        aryAppZako = prm_aryAppZako
    End Sub

    ''' <summary>
    ''' 自動雑魚出現リストのＧｅｔｔｅｒ
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAryAppZako() As ArrayList
        Return aryAppZako
    End Function
End Class
