﻿Imports Microsoft.DirectX.Direct3D
''' <summary>
''' HP主人公パラメータ
''' </summary>
''' <remarks></remarks>
Public Class HPrmTokuten
    Implements IHeroParameter


    ''' <summary>
    ''' DirectXグラフィック制御
    ''' </summary>
    ''' <remarks></remarks>
    Private Dxg As DxGraphicControl

    ''' <summary>
    ''' オブジェクトパーツ構造体
    ''' </summary>
    ''' <remarks></remarks>
    Private Structure Part
        Dim TexFlNm As String
        Dim Tex As Texture
        Dim Sz As SizeF
        Dim RelPt As PointF
    End Structure

#Region "Parts"

    ''' <summary>
    ''' 背景パーツ
    ''' </summary>
    ''' <remarks></remarks>
    Private BackPart As Part

    ''' <summary>
    ''' 得点パーツ
    ''' </summary>
    ''' <remarks></remarks>
    Private TokutenPart As Part
    Private TokutenRect As Rectangle
    Private TokutenColor As Color

    ''' <summary>
    ''' 枠パーツ
    ''' </summary>
    ''' <remarks></remarks>
    Private WakuPart As Part
#End Region

    ''' <summary>
    ''' 得点
    ''' </summary>
    ''' <remarks></remarks>
    Public Tokuten As Integer

    ''' <summary>
    ''' テクスチャーファイルのパス
    ''' </summary>
    ''' <remarks></remarks>
    Private DIR_PATH As String = IO.Directory.GetCurrentDirectory & "\sys\tex\hprm\"

    ''' <summary>
    ''' 共通ロジック
    ''' </summary>
    ''' <remarks></remarks>
    Private com As HPrmCommon


    Public Sub New(ByRef prm_HPrmCommon As HPrmCommon)
        com = prm_HPrmCommon

        '■テクスチャーファイル名
        BackPart.TexFlNm = "tokuten_back.dds"
        WakuPart.TexFlNm = "tokuten_waku.dds"

        '■パーツサイズ,相対位置の設定
        With BackPart
            .Sz.Width = 114.0F
            .Sz.Height = 21.0F
            .RelPt.X = 20.0F
            .RelPt.Y = 4.0F
        End With
        With TokutenPart
            .Sz.Width = 114.0F
            .Sz.Height = 21.0F
            .RelPt.X = 20.0F
            .RelPt.Y = 4.0F
            TokutenRect = New Rectangle(CSng(.RelPt.X), CSng(.RelPt.Y), _
                                        CSng(.Sz.Width), CSng(.Sz.Height))
            TokutenColor = Color.GreenYellow '文字の色を設定する
        End With

        With WakuPart
            .Sz.Width = 155.0F
            .Sz.Height = 29.0F
            .RelPt.X = 0.0F
            .RelPt.Y = 0.0F
        End With

        '■テクスチャーの作成
        Dxg = AppContainer.getInstance.GetDxg
        BackPart.Tex = Dxg.CreateTextureFromFile(DIR_PATH & BackPart.TexFlNm)
        WakuPart.Tex = Dxg.CreateTextureFromFile(DIR_PATH & WakuPart.TexFlNm)


    End Sub

    ''' <summary>
    ''' 情報更新
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Update() Implements IHeroParameter.Update
        Tokuten = com.GetTokuten '得点を取得し更新する
    End Sub

    ''' <summary>
    ''' 描画
    ''' </summary>
    ''' <param name="pt"></param>
    ''' <remarks></remarks>
    Public Sub Draw(ByRef pt As System.Drawing.PointF) Implements IHeroParameter.Draw
        With BackPart
            Dxg.Draw2D(.Tex, pt.X + .RelPt.X, pt.Y + .RelPt.Y, .Sz.Width, .Sz.Height)
        End With

        With TokutenPart
            TokutenRect.X = pt.X + .RelPt.X
            TokutenRect.Y = pt.Y + .RelPt.Y
            Dxg.DrawTextRight(Tokuten.ToString, TokutenRect, TokutenColor)
        End With

        With WakuPart
            Dxg.Draw2D(.Tex, pt.X + .RelPt.X, pt.Y + .RelPt.Y, .Sz.Width, .Sz.Height)
        End With
    End Sub
End Class
