﻿''' <summary>
''' 衝突処理共通ロジック
''' </summary>
''' <remarks></remarks>
Public Class CollisionCommon


    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    ''' <summary>
    ''' 主人公パラメータ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private HPrmCon As HeroParameterControl

    ''' <summary>
    ''' 効果音制御
    ''' </summary>
    ''' <remarks></remarks>
    Private EfSnd As EffectSoundControl

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="prm_stgCon"></param>
    ''' <param name="prm_crtCon"></param>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_stgCon As StageControl, _
                    ByRef prm_crtCon As CrtControl, _
                    ByRef prm_hprmCon As HeroParameterControl)
        StgCon = prm_stgCon
        CrtCon = prm_crtCon
        HPrmCon = prm_hprmCon
        EfSnd = AppContainer.getInstance.GetEfSnd
    End Sub


    ''' <summary>
    ''' 得点を追加
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub TokutenAdd(ByVal tokuten As Integer)
        HPrmCon.TokutenAdd(tokuten)
    End Sub

    ''' <summary>
    ''' 効果音を鳴らす。
    ''' </summary>
    ''' <param name="id"></param>
    ''' <remarks></remarks>
    Public Sub EffectSoundAdd(ByVal id As Integer)
        EfSnd.PlayAdd(id)
    End Sub
End Class
