﻿Public Class collHBeamZako
    Implements ICollision




    ''' <summary>
    ''' 共通ロジック
    ''' </summary>
    ''' <remarks></remarks>
    Private com As CollisionCommon


    Public Sub New(ByRef prm_CollisionCommon As CollisionCommon)
        com = prm_CollisionCommon
    End Sub
  

    ''' <summary>
    ''' 主人公光線とザコの衝突処理
    ''' </summary>
    ''' <param name="crtHBeam"></param>
    ''' <param name="coll1"></param>
    ''' <param name="crtZako"></param>
    ''' <param name="coll2"></param>
    ''' <remarks></remarks>
    Public Sub Collision(ByRef crtHBeam As Creture, ByRef coll1 As CrtCollisionEntity, _
                         ByRef crtZako As Creture, ByRef coll2 As CrtCollisionEntity) Implements ICollision.Collision

        Dim dmg1 As Integer = coll1.AP - coll2.DP
        If dmg1 > 0 Then
            crtZako.Hp -= dmg1
            If crtZako.Hp <= 0 Then
                com.EffectSoundAdd(7) 'ザコＫＯ効果音を鳴らす
                com.TokutenAdd(crtZako.Tokuten)
                crtZako.PreFlg = False
            End If
        End If

        Dim dmg2 As Integer = coll2.AP - coll1.DP
        If dmg2 > 0 Then
            crtHBeam.Hp -= dmg2
            If crtHBeam.Hp <= 0 Then
                crtHBeam.PreFlg = False
            End If
        End If

    End Sub

End Class
