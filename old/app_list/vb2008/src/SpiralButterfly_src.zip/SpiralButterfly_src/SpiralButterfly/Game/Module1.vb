﻿Module Module1
    ''' <summary>
    ''' 共通エラー出力
    ''' </summary>
    ''' <param name="className">エラークラス名</param>
    ''' <param name="MethodName">エラーメソッド</param>
    ''' <param name="msg">メッセージ</param>
    ''' <param name="ex">例外</param>
    ''' <remarks>エラーメッセージを出力する共通処理</remarks>
    Public Sub ErrMsg(ByRef className As String, ByRef MethodName As String, ByRef msg As String, ByRef ex As Exception)

        Dim str As String = className & ":" & MethodName & vbCrLf & _
            msg & vbCrLf & _
            Err.Description & vbCrLf & _
            Err.Source & vbCrLf & _
            ex.StackTrace

        'LogPrint(str)
        Debug.Print(str)
        MsgBox(str)
    End Sub

    ''' <summary>
    ''' 共通ログ出力
    ''' </summary>
    ''' <param name="msg">メッセージ</param>
    ''' <remarks></remarks>
    Public Sub LogPrint(ByRef msg As String)
        Debug.Print(msg)
    End Sub
End Module
