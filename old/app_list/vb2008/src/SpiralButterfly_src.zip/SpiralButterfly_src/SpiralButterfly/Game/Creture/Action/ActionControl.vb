﻿Public Class ActionControl

    ''' <summary>
    ''' アクションリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private aryAction As ArrayList

    ''' <summary>
    ''' アクション数
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared ACTION_CNT As Integer = 2

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    ''' <summary>
    ''' 主人公パラメータ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private HPrmCon As HeroParameterControl

    ''' <summary>
    ''' アクション共通ロジック
    ''' </summary>
    ''' <remarks></remarks>
    Private com As ActionCommon

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_stgCon As StageControl, _
                    ByRef prm_crtCon As CrtControl, _
                    ByRef prm_hprmCon As HeroParameterControl)

        com = New ActionCommon
        StgCon = prm_stgCon
        CrtCon = prm_crtCon
        HPrmCon = prm_hprmCon
        com.Init(StgCon, CrtCon, HPrmCon)

        aryAction = New ArrayList 'アクションリストを生成

        With aryAction
            .Add(New ActionOperate(com)) 'ユーザー操作アクション
            .Add(New ActionKanabun1(com)) 'カナブン１アクション
            .Add(New ActionStraight) 'アクションストレート
        End With
    End Sub

    ''' <summary>
    ''' クリーチャーのアクション
    ''' </summary>
    ''' <param name="crt"></param>
    ''' <remarks></remarks>
    Public Sub Action(ByRef crt As Creture)
        Dim act As IAction = CType(aryAction(crt.ActionId), IAction)
        act.Action(crt)
    End Sub


End Class
