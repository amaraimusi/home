﻿''' <summary>
''' 主人公パラメータ制御
''' </summary>
''' <remarks></remarks>
Public Class HeroParameterControl

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    Private m_tokuten As Integer

    ''' <summary>
    ''' HPパラメータ
    ''' </summary>
    ''' <remarks></remarks>
    Private HpHp As HPrmHP
    ''' <summary>
    ''' 得点パラメータ
    ''' </summary>
    ''' <remarks></remarks>
    Private HpTk As HPrmTokuten

    Private com As HPrmCommon

    Private PtHp As PointF
    Private PtTk As PointF


    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="prm_stgCon"></param>
    ''' <param name="prm_crtCon"></param>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_stgCon As StageControl, ByRef prm_crtCon As CrtControl)
        StgCon = prm_stgCon
        CrtCon = prm_crtCon

        '共通オブジェクトの生成と初期化
        com = New HPrmCommon
        com.Init(StgCon, CrtCon, Me)


        HpHp = New HPrmHP(com) 'ＨＰパラメータを生成
        HpTk = New HPrmTokuten(com) 'ＨＰパラメータを生成

        PtHp = New PointF(200.0F, 540.0F)
        PtTk = New PointF(630.0F, 540.0F)
    End Sub

    ''' <summary>
    ''' 主人公パラメータ情報を更新する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Update()
        HpHp.Update()
        HpTk.Update()
    End Sub

    ''' <summary>
    ''' 主人公パラメータを描画する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Draw()
        HpHp.Draw(PtHp)
        HpTk.Draw(PtTk)
    End Sub

    ''' <summary>
    ''' 得点追加
    ''' </summary>
    ''' <param name="tokuten"></param>
    ''' <remarks></remarks>
    Public Sub TokutenAdd(ByVal tokuten As Integer)
        m_tokuten += tokuten
    End Sub

    ''' <summary>
    ''' 得点を取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetTokuten() As Integer
        Return m_tokuten
    End Function

    Public Sub New()

    End Sub
End Class
