﻿Public Class ActionDoc

    ''' <summary>
    ''' アクションID
    ''' </summary>
    ''' <remarks></remarks>
    Public ActId As Integer

    ''' <summary>
    ''' 親アクションID
    ''' </summary>
    ''' <remarks></remarks>
    Public ParActId As Integer '

    ''' <summary>
    ''' アクションIDの切り替え
    ''' </summary>
    ''' <param name="prm_actId"></param>
    ''' <remarks></remarks>
    Public Sub SetActId(ByVal prm_actId As Integer)
        ParActId = ActId
        ActId = prm_actId
    End Sub

End Class
