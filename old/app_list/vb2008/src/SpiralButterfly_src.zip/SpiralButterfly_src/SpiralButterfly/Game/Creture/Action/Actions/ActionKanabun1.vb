﻿Public Class ActionKanabun1
    Implements IAction

    ''' <summary>
    ''' アクション共通ロジック
    ''' </summary>
    ''' <remarks></remarks>
    Dim acl As ActionCommon

    Public Sub New(ByRef prm_acl As ActionCommon)
        acl = prm_acl
    End Sub


    Public Sub Action(ByRef crt As Creture) Implements IAction.Action
        Dim doc As ActDocKanabun1 = CType(crt.GetActDoc, ActDocKanabun1)
        If doc Is Nothing Then
            doc = New ActDocKanabun1
            crt.SetActDoc(doc)
        End If

        If doc.IniFlg = False Then
            '■主人公の登場IDを取得する
            Dim tarCrtId As Integer = acl.GetEntryIdOfHero
            Dim tarCrt As Creture = acl.GetCrt(CrtGrpConst.HERO, tarCrtId)

            '■目標方向角度を取得して、クリーチャーの進行角度と向き角度にセットする。
            crt.AngVector = acl.GetAimDirectionAngle(crt, tarCrt)
            crt.Ang = crt.AngVector

            doc.IniFlg = True
        Else
            acl.Straight(crt) '直進する
        End If
    End Sub

End Class
