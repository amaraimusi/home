﻿''' <summary>
''' アクション書類情報
''' </summary>
''' <remarks></remarks>
Public Class ActionDocData

    ''' <summary>
    ''' アクション書類配列
    ''' </summary>
    ''' <remarks></remarks>
    Private ADocs() As ActionDoc

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New()
        ReDim ADocs(ActionControl.ACTION_CNT)
        'InitActDocs() 'すべての書類を初期化する。
    End Sub

    ''' <summary>
    ''' すべてのアクション書類を初期化する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InitActDocs()
        ReDim ADocs(ActionControl.ACTION_CNT)
        'For Each actDoc As ActionDoc In ADocs
        '    actDoc = Nothing
        'Next
    End Sub

    ''' <summary>
    ''' アクション書類配列のSetter
    ''' </summary>
    ''' <param name="prm_actDocs"></param>
    ''' <remarks></remarks>
    Public Sub SetActionDocs(ByRef prm_actDocs() As ActionDoc)
        ADocs = prm_actDocs
    End Sub

    ''' <summary>
    ''' アクション書類配列のGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetActionDocs() As ActionDoc()
        Return ADocs
    End Function

    ''' <summary>
    ''' アクション書類のSetter
    ''' </summary>
    ''' <param name="actId"></param>
    ''' <param name="prm_actDoc"></param>
    ''' <remarks></remarks>
    Public Sub SetActionDoc(ByVal actId As Integer, ByRef prm_actDoc As ActionDoc)
        ADocs(actId) = prm_actDoc
    End Sub

    ''' <summary>
    ''' アクション書類のGetter
    ''' </summary>
    ''' <param name="actId"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetActionDoc(ByVal actId As Integer) As ActionDoc
        Return ADocs(actId)
    End Function
End Class
