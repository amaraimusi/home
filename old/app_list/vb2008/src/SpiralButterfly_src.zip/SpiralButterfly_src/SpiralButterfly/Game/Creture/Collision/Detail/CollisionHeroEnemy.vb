﻿''' <summary>
''' 主人公と敵の衝突処理
''' </summary>
''' <remarks></remarks>
Public Class CollisionHeroEnemy
    Implements ICollision

    ''' <summary>
    ''' 共通ロジック
    ''' </summary>
    ''' <remarks></remarks>
    Private com As CollisionCommon


    Public Sub New(ByRef prm_CollisionCommon As CollisionCommon)
        com = prm_CollisionCommon
    End Sub


    ''' <summary>
    ''' 衝突処理
    ''' </summary>
    ''' <param name="crt1"></param>
    ''' <param name="coll1"></param>
    ''' <param name="crt2"></param>
    ''' <param name="coll2"></param>
    ''' <remarks></remarks>
    Public Sub Collision(ByRef crt1 As Creture, ByRef coll1 As CrtCollisionEntity, _
                         ByRef crt2 As Creture, ByRef coll2 As CrtCollisionEntity) Implements ICollision.Collision

        Dim dmg1 As Integer = coll1.AP - coll2.DP
        If dmg1 > 0 Then
            crt2.Hp -= dmg1
            If crt2.Hp <= 0 Then
                crt2.PreFlg = False
            End If
        End If

        Dim dmg2 As Integer = coll2.AP - coll1.DP
        If dmg2 > 0 Then
            crt1.Hp -= dmg2
            If crt1.Hp <= 0 Then
                crt1.PreFlg = False
            End If
        End If

    End Sub

End Class
