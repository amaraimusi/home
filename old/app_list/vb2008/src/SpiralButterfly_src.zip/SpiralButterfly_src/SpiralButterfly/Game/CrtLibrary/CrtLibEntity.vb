﻿Imports Microsoft.DirectX.Direct3D

''' <summary>
''' クリーチャーライブラリエンティティ
''' </summary>
''' <remarks></remarks>
Public Class CrtLibEntity
    Public GrpId As Integer 'グループID
    Public Name As String '名称
    Public Width As Integer '幅
    Public Height As Integer '高さ
    Public Hyp As Single '斜辺
    Public HypAng As Single '斜辺角度
    Public PreFlg As Boolean 'Falseの場合、データなしを示す
    Public Speed As Single '移動速度
    Public ActionId As Integer 'アクションID
    Public Hp As Integer 'HP
    Public Tokuten As Integer '得点

    ''' <summary>
    ''' テクスチャー
    ''' </summary>
    ''' <remarks></remarks>
    Private Tex As Texture
    ''' <summary>
    ''' 衝突情報
    ''' </summary>
    ''' <remarks></remarks>
    Private AryCollision As ArrayList
    ''' <summary>
    ''' 発射情報
    ''' </summary>
    ''' <remarks></remarks>
    Private AryFire As ArrayList

    Public Sub New()
        AryCollision = New ArrayList
        AryFire = New ArrayList
    End Sub

#Region "アクセサメソッド"
    ''' <summary>
    ''' テクスチャーのＳｅｔｔｅｒ
    ''' </summary>
    ''' <param name="prm_tex"></param>
    ''' <remarks></remarks>
    Public Sub SetTexture(ByRef prm_tex As Texture)
        Tex = prm_tex
    End Sub
    ''' <summary>
    ''' テクスチャーのＧｅｔｔｅｒ
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetTexture() As Texture
        Return Tex
    End Function

    ''' <summary>
    ''' AryCollisionのSetter
    ''' </summary>
    ''' <param name="prm_aryCollision"></param>
    ''' <remarks></remarks>
    Public Sub SetAryCollision(ByRef prm_aryCollision As ArrayList)
        AryCollision = prm_aryCollision
    End Sub
    ''' <summary>
    ''' AryCollisionのGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAryCollision() As ArrayList
        Return AryCollision
    End Function

    ''' <summary>
    ''' 発射情報のSetter
    ''' </summary>
    ''' <param name="prm_aryFire"></param>
    ''' <remarks></remarks>
    Public Sub SetAryFire(ByRef prm_aryFire As ArrayList)
        AryFire = prm_aryFire
    End Sub
    ''' <summary>
    ''' 発射情報のGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAryFire() As ArrayList
        Return AryFire
    End Function

#End Region


End Class
