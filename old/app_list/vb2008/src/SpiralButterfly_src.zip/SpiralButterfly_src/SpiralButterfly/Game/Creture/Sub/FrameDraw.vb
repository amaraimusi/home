﻿''' <summary>
''' クリーチャーをフレーム描画する
''' </summary>
''' <remarks></remarks>
Public Class FrameDraw
    ''' <summary>
    ''' クリーチャーリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private aryCrt As ArrayList

    ''' <summary>
    ''' グラフィックオブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private grpc As Graphics

    ''' <summary>
    ''' 衝突部位絶対座標算出
    ''' </summary>
    ''' <remarks></remarks>
    Private ccap As CalcCollAbsPoint

    Private Const ANG90 As Single = Math.PI / 2
    Private Const ANG180 As Single = Math.PI
    Private Const ANG270 As Single = Math.PI * 1.5


    Public Sub New(ByRef prm_aryCrt As ArrayList)
        aryCrt = prm_aryCrt
        Dim fm As Form = AppContainer.getInstance.GetFormMain
        grpc = fm.CreateGraphics
        ccap = New CalcCollAbsPoint(aryCrt)
    End Sub

    ''' <summary>
    ''' 登場しているすべてのクリーチャーを描画する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Draw()
        ccap.calc() ' 衝突部位絶対座標を算出する
        For Each crts As Creture() In aryCrt
            For Each crt As Creture In crts
                With crt
                    If .PreFlg = True Then
                        DrawHontai(crt.p0, crt.Ang, crt.Hyp, crt.HypAng)

                        '■当たり判定を描画する
                        For Each cc As CrtCollisionEntity In .GetAryColl
                            DrawCollision(cc)
                        Next

                    End If
                End With
            Next
        Next
    End Sub

    ''' <summary>
    ''' クリーチャーの衝突範囲を描画する
    ''' </summary>
    ''' <param name="cc"></param>
    ''' <remarks></remarks>
    Public Sub DrawCollision(ByRef cc As CrtCollisionEntity)
        With cc
            Dim r As Single = .CollRadius
            Dim rh As Single = r / 2
            Dim rectF As RectangleF = New RectangleF(.AbsPx - rh, .AbsPy - rh, r, r)
            grpc.DrawEllipse(Pens.Red, rectF)
        End With
        'grpc.DrawEllipse(
    End Sub
    ''' <summary>
    ''' クリーチャー本体のフレームを描画
    ''' </summary>
    ''' <param name="p0"></param>
    ''' <param name="rAng"></param>
    ''' <param name="hyp"></param>
    ''' <param name="hypAng"></param>
    ''' <remarks></remarks>
    Public Sub DrawHontai(ByRef p0 As PointF, ByVal rAng As Single, ByVal hyp As Single, ByVal hypAng As Single)
        Dim a1(3) As Single
        rAng = rAng + ANG90
        a1(0) = hypAng + rAng
        a1(1) = (ANG90 - hypAng) + ANG90 + rAng
        a1(2) = hypAng + ANG180 + rAng
        a1(3) = (ANG90 - hypAng) + ANG270 + rAng
        '▼頂点情報配列に、描画位置をセット
        Dim pf(3) As PointF
        For i = 0 To 3
            pf(i).X = p0.X - hyp * Math.Cos(a1(i))
            pf(i).Y = p0.Y - hyp * Math.Sin(a1(i))
        Next
        grpc.DrawPolygon(Pens.Yellow, pf)

    End Sub
End Class
