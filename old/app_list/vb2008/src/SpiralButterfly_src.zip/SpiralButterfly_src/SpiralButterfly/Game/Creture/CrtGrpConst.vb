﻿''' <summary>
''' グループ番号の定数
''' </summary>
''' <remarks></remarks>
Public Class CrtGrpConst

    Public Shared HERO As Integer = 0 '味方番号
    Public Shared HBEAM As Integer = 1 '味方光線番号
    Public Shared HSP As Integer = 2 '味方特殊番号
    Public Shared ZAKO As Integer = 3 'ザコ番号
    Public Shared BOSS As Integer = 4 'ボス番号
    Public Shared RIVAL As Integer = 5 'ライバル番号
    Public Shared EBEAM As Integer = 6 '敵光線番号
    Public Shared ESP As Integer = 7 '敵特殊番号
    Public Shared ITEM As Integer = 8 'アイテム番号
    Public Shared OBJ As Integer = 9 '物番号


End Class
