﻿''' <summary>
''' クリーチャーを描画する
''' </summary>
''' <remarks></remarks>
Public Class DrawCretures

    ''' <summary>
    ''' クリーチャーリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private aryCrt As ArrayList
    ''' <summary>
    ''' 描画オブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private dxg As DxGraphicControl
    Public Sub New(ByRef prm_aryCrt As ArrayList)
        aryCrt = prm_aryCrt
        dxg = AppContainer.getInstance.GetDxg

    End Sub

    ''' <summary>
    ''' 登場しているすべてのクリーチャーを描画する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Draw()
        For Each crts As Creture() In aryCrt
            For Each crt As Creture In crts
                With crt
                    If .PreFlg = True Then
                        dxg.Draw2D(.GetTexture, .p0, .Ang, .Hyp, .HypAng) '描画を行う
                    End If
                End With
            Next
        Next
    End Sub
End Class
