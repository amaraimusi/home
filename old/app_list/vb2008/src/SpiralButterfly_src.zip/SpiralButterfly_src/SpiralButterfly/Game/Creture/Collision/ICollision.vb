﻿''' <summary>
''' 衝突判定インターフェース
''' </summary>
''' <remarks></remarks>
Public Interface ICollision
    ''' <summary>
    ''' 衝突処理
    ''' </summary>
    ''' <param name="crt1"></param>
    ''' <param name="crt2"></param>
    ''' <remarks></remarks>
    Sub Collision(ByRef crt1 As Creture, ByRef coll1 As CrtCollisionEntity, ByRef crt2 As Creture, ByRef coll2 As CrtCollisionEntity)

End Interface
