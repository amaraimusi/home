﻿''' <summary>
''' クリーチャー発射エンティティ
''' </summary>
''' <remarks></remarks>
Public Class CrtFireEntity
    Public CrtId As Integer 'クリーチャーＩＤ
    Public ＭuzzleId As Integer '発射口ＩＤ
    Public FireCrtId As Integer '発射クリーチャーＩＤ
    'Public MuzzleRx As Single '発射口相対座標Ｘ
    'Public MuzzleRy As Single '発射口相対座標Ｙ
    Public MuzzleHyp As Single '発射口位置斜辺
    Public MuzzleAng As Single '発射口位置角度
    Public Speed As Single '発射物速度
    Public Interval As Integer '発射間隔
    Public IntervalCounter As Integer '発射間隔カウンター

End Class
