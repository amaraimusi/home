﻿Public Class ActionCommon

    ''' <summary>
    ''' アプリケーションコンテナ
    ''' </summary>
    ''' <remarks></remarks>
    Private app As AppContainer

    ''' <summary>
    ''' 登場クリーチャー情報
    ''' </summary>
    ''' <remarks></remarks>
    Private AryCrt As ArrayList

    ''' <summary>
    ''' メインサイズ
    ''' </summary>
    ''' <remarks>画面および、座標系のサイズ</remarks>
    Private mainSize As Size

    ''' <summary>
    ''' 目標方向角度を求める
    ''' </summary>
    ''' <remarks></remarks>
    Private ada As AL_AimDirectionAngle

    ''' <summary>
    ''' 発射攻撃する
    ''' </summary>
    ''' <remarks></remarks>
    Private FireBeam As AL_FireBeam

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    ''' <summary>
    ''' 主人公パラメータ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private HPrmCon As HeroParameterControl

    ''' <summary>
    ''' 効果音制御
    ''' </summary>
    ''' <remarks></remarks>
    Private EfSnd As EffectSoundControl


    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="prm_stgCon"></param>
    ''' <param name="prm_crtCon"></param>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_stgCon As StageControl, _
                    ByRef prm_crtCon As CrtControl, _
                    ByRef prm_hprmCon As HeroParameterControl)

        'メンバオブジェクトにセット
        StgCon = prm_stgCon
        CrtCon = prm_crtCon
        HPrmCon = prm_hprmCon
        EfSnd = AppContainer.getInstance.GetEfSnd

        app = AppContainer.getInstance
        mainSize = app.GetMainSize 'メインサイズを取得する

        '■登場クリーチャー情報を取得する
        AryCrt = CrtCon.GetAryCrt

        ada = New AL_AimDirectionAngle
        FireBeam = New AL_FireBeam(CrtCon)
        EfSnd = app.GetEfSnd
    End Sub



    ''' <summary>
    ''' プレイヤー入力情報を取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetPlayerData() As PlayerInputData
        Return app.GetPlayerInputData
    End Function

    ''' <summary>
    ''' メインサイズのGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetMainSize() As Size
        Return mainSize
    End Function

    ''' <summary>
    ''' 主人公の登場IDを取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetEntryIdOfHero() As Integer
        Return 0
    End Function

    ''' <summary>
    ''' クリーチャーを取得する
    ''' </summary>
    ''' <param name="GrpId"></param>
    ''' <param name="EntryNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetCrt(ByVal GrpId As Integer, ByVal EntryNo As Integer)
        Dim crts() As Creture = CType(AryCrt(GrpId), Creture())
        Return crts(EntryNo)
    End Function

    ''' <summary>
    ''' 目標方向角度を取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAimDirectionAngle(ByRef crt As Creture, ByRef tarCrt As Creture) As Single
        Return ada.GetAng(crt, tarCrt)
    End Function

    ''' <summary>
    ''' 直進する
    ''' </summary>
    ''' <param name="crt"></param>
    ''' <remarks></remarks>
    Public Sub Straight(ByRef crt As Creture)
        With crt
            Dim m_x As Single = .Speed * Math.Cos(.AngVector)
            Dim m_y As Single = .Speed * Math.Sin(.AngVector)
            .p0.X += m_x
            .p0.Y += m_y

        End With
    End Sub


    ''' <summary>
    ''' 発射攻撃
    ''' </summary>
    ''' <param name="crt">光線発射するクリーチャー</param>
    ''' <param name="MuzzleId">発射口ＩＤ</param>
    ''' <remarks></remarks>
    Public Sub Fire(ByRef crt As Creture, ByVal MuzzleId As Integer)
        FireBeam.Fire(crt, MuzzleId)
    End Sub

    ''' <summary>
    ''' 効果音を鳴らす
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub EffectSoundPlay(ByVal sndId As Integer)
        EfSnd.PlayAdd(sndId)
    End Sub

End Class
