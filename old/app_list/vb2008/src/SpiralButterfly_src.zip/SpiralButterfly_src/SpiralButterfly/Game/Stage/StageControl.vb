﻿Public Class StageControl

#Region "キー定数"
    '■基本情報のキー
    Private Const CST_ID As String = "Id" ' ステージＩＤ
    Private Const CST_NAME As String = "Name" ' ステージ名
    Private Const CST_COMENT As String = "Coment" ' コメント
    Private Const CST_BGMID As String = "BgmId" ' ステージ音楽ＩＤ
    Private Const CST_HAIKEIID As String = "HaikeiId" ' 背景画像ＩＤ
    Private Const CST_LENGHT As String = "Lenght" ' ステージ長さ
    Private Const CST_BOSSID As String = "BossId" ' ボスＩＤ
    Private Const CST_MAXZAKOAPPRATE As String = "MaxZakoAppRate" ' 最大雑魚出現率
    Private Const CST_MINZAKOAPPRATE As String = "MinZakoAppRate" ' 最小雑魚出現率
    Private Const CST_ZAKOAPPEXCHANGERATE As String = "ZakoAppExchangeRate" ' 雑魚出現変化率

    '動的出現のキー
    Private Const CST_STAGEID As String = "StageId" ' ステージＩＤ
    Private Const CST_CRTID As String = "CrtId" ' クリーチャーＩＤ
    Private Const CST_APPRATE As String = "AppRate" ' 出現率
    Private Const CST_APPUPFLG As String = "AppUpFlg" ' 出現上フラグ
    Private Const CST_APPRIGHTFLG As String = "AppRightFlg" ' 出現右フラグ
    Private Const CST_APPBOTTOMFLG As String = "AppBottomFlg" ' 出現下フラグ
    Private Const CST_APPLEFTFLG As String = "AppLeftFlg" ' 出現左フラグ
#End Region

    ''' <summary>
    ''' 現在のステージID
    ''' </summary>
    ''' <remarks></remarks>
    Public ActiveStageId As Integer

    ''' <summary>
    ''' ステージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Private stgEnts As StageEntity()

    ''' <summary>
    ''' 動的雑魚出現機能
    ''' </summary>
    ''' <remarks></remarks>
    Private daz As DynamicAppZako

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    ''' <summary>
    ''' ステージ情報の読み込み
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Load()
        Dim dao As IDao = AppContainer.getInstance.GetDao

        '■最大要素数を取得する
        Dim maxIndex As Integer = GetMaxIndex(dao)
        ReDim stgEnts(maxIndex)
        For Each stg As StageEntity In stgEnts
            stg = Nothing
        Next

        LoadBaseData(dao)       '基本ステージ情報をセット
        LoadAppZakoList(dao)    '動的出現雑魚リストを読込む

        '動的雑魚出現機能
        daz = New DynamicAppZako(stgEnts)
    End Sub

    ''' <summary>
    ''' クリーチャー制御のSetter
    ''' </summary>
    ''' <param name="prm_CrtControl"></param>
    ''' <remarks></remarks>
    Public Sub SetCrtControl(ByRef prm_CrtControl As CrtControl)
        CrtCon = prm_CrtControl
        daz.SetControl(CrtCon, Me) '動的ザコ出現機能にもセットする
    End Sub

    ''' <summary>
    ''' 最大要素数を取得する
    ''' </summary>
    ''' <param name="dao"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetMaxIndex(ByRef dao As IDao) As Integer

        Dim sql As String = "SELECT Max(Id) AS MaxId FROM StageTbl"
        Dim dtSet As DataSet = dao.getDataSet(sql)
        Return CType(dtSet.Tables(0).Rows(0)(0), Integer)
    End Function

    ''' <summary>
    ''' 基本ステージ情報をセット
    ''' </summary>
    ''' <param name="dao"></param>
    ''' <remarks></remarks>
    Private Sub LoadBaseData(ByRef dao As IDao)
        '■ステージ情報に自動出現雑魚情報を読み込む
        Dim sql As String = "SELECT * FROM StageTbl"
        Dim dtSet As DataSet = dao.getDataSet(sql)
        For Each r As DataRow In dtSet.Tables(0).Rows
            Dim stg As New StageEntity
            With stg
                .Name = CType(r(CST_NAME), String) 'ステージ名
                .Coment = CType(r(CST_COMENT), String) 'コメント
                .BgmId = CType(r(CST_BGMID), Integer) 'ステージ音楽ＩＤ
                .HaikeiId = CType(r(CST_HAIKEIID), Integer) '背景画像ＩＤ
                .Lenght = CType(r(CST_LENGHT), Integer) 'ステージ長さ
                .BossId = CType(r(CST_BOSSID), Integer) 'ボスＩＤ
                .MaxZakoAppRate = CType(r(CST_MAXZAKOAPPRATE), Integer) '最大雑魚出現率
                .MinZakoAppRate = CType(r(CST_MINZAKOAPPRATE), Integer) '最小雑魚出現率
                .ZakoAppExchangeRate = CType(r(CST_ZAKOAPPEXCHANGERATE), Integer) '雑魚出現変化率
            End With
            stgEnts(CType(r(CST_ID), Integer)) = stg
        Next
    End Sub

    ''' <summary>
    ''' 動的出現雑魚リストを読込む
    ''' </summary>
    ''' <param name="dao"></param>
    ''' <remarks></remarks>
    Private Sub LoadAppZakoList(ByRef dao As IDao)
        '■ステージ情報に自動出現雑魚情報を読み込む
        Dim sql As String = "SELECT * FROM DynamicEnemyTbl"
        Dim dtSet As DataSet = dao.getDataSet(sql) 'データセット取得
        For Each r As DataRow In dtSet.Tables(0).Rows
            Dim stgEnt As StageEntity = stgEnts(CType(r(CST_STAGEID), Integer)) 'ステージエンティティを取得する
            If Not stgEnt Is Nothing Then 'ステージエンティティがNullでない場合、動的出現雑魚情報を取得する

                '■動的出現雑魚エンティティにデータセットの値をセットする。
                Dim dazEnt As New DynamicAppZakoEntity '動的出現雑魚エンティティ
                With dazEnt
                    .StageId = CType(r(CST_STAGEID), Integer) 'ステージＩＤ
                    .CrtId = CType(r(CST_CRTID), Integer) 'クリーチャーＩＤ
                    .AppRate = CType(r(CST_APPRATE), Integer) '出現率

                    '▼出現方面リストの取得
                    Dim aryAppPt As New ArrayList '出現方面リスト
                    If CType(r(CST_APPUPFLG), Boolean) = True Then
                        aryAppPt.Add(DAZ_QuarterConst.UPPER)
                    End If
                    If CType(r(CST_APPRIGHTFLG), Boolean) = True Then
                        aryAppPt.Add(DAZ_QuarterConst.RIGHT)
                    End If
                    If CType(r(CST_APPBOTTOMFLG), Boolean) = True Then
                        aryAppPt.Add(DAZ_QuarterConst.BOTTOM)
                    End If
                    If CType(r(CST_APPLEFTFLG), Boolean) = True Then
                        aryAppPt.Add(DAZ_QuarterConst.LEFT)
                    End If
                    .SetAppPoint(aryAppPt) '出現方面リストをセット
                End With

                '■ステージ情報の動的出現雑魚リストに追加する
                Dim ary As ArrayList = stgEnt.GetAryAppZako
                ary.Add(dazEnt)

            End If
        Next
    End Sub



    ''' <summary>
    ''' ステージエンティティを取得する
    ''' </summary>
    ''' <param name="stgId">ステージＩＤ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetStageEntity(ByVal stgId As Integer) As StageEntity
        Return stgEnts(stgId)
    End Function

    ''' <summary>
    ''' ステージ情報を取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetStageEntitys() As StageEntity()
        Return stgEnts
    End Function

    ''' <summary>
    ''' ザコの出現
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub AppearZako()
        daz.AppearZako(ActiveStageId)
    End Sub
End Class
