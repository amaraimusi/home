﻿''' <summary>
''' 動的出現雑魚エンティティ
''' </summary>
''' <remarks></remarks>
Public Class DynamicAppZakoEntity
    Public StageId As Integer 'ステージＩＤ
    Public CrtId As Integer 'クリーチャーＩＤ
    Public AppRate As Integer '出現率
    'Public AppUpFlg As Boolean '出現上フラグ
    'Public AppRightFlg As Boolean '出現右フラグ
    'Public AppBottomFlg As Boolean '出現下フラグ
    'Public AppLeftFlg As Boolean '出現左フラグ

    ''' <summary>
    ''' 出現方面配列
    ''' </summary>
    ''' <remarks>上下左右のいずれかからザコを出現させる</remarks>
    Private AryAppPoint As ArrayList

    Public Sub SetAppPoint(ByRef prm_appPoint As ArrayList)
        AryAppPoint = prm_appPoint
    End Sub
    Public Function GetAppPoint() As ArrayList
        Return AryAppPoint
    End Function
End Class
