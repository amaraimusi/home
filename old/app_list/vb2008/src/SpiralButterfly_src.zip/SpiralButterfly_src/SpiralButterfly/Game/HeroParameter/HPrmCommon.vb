﻿''' <summary>
''' 主人公パラメータ共通ロジック
''' </summary>
''' <remarks></remarks>
Public Class HPrmCommon

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl


    ''' <summary>
    ''' 主人公パラメータ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private HPrmCon As HeroParameterControl


    ''' <summary>
    ''' 主人公の登場番号
    ''' </summary>
    ''' <remarks></remarks>
    Private HeroEntryId As Integer = 0

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="prm_stgCon"></param>
    ''' <param name="prm_crtCon"></param>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_stgCon As StageControl, _
                    ByRef prm_crtCon As CrtControl, _
                    ByRef prm_hprmCon As HeroParameterControl)
        StgCon = prm_stgCon
        CrtCon = prm_crtCon
        HPrmCon = prm_hprmCon
    End Sub

    ''' <summary>
    ''' クリーチャー情報を取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetHeroCreture() As Creture
        Dim crts() As Creture = CType(CrtCon.GetAryCrt(CrtGrpConst.HERO), Creture())
        Return crts(HeroEntryId)
    End Function

    ''' <summary>
    ''' 現在の得点を取得する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetTokuten() As Integer
        Return HPrmCon.GetTokuten
    End Function
End Class
