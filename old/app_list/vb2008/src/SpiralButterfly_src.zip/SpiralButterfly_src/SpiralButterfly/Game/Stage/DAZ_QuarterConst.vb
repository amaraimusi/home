﻿''' <summary>
''' ザコ出現方面定数
''' </summary>
''' <remarks></remarks>
Public Class DAZ_QuarterConst
    Public Shared UPPER As Integer = 0  '上方面
    Public Shared RIGHT As Integer = 1  '右方面
    Public Shared BOTTOM As Integer = 2 '下方面
    Public Shared LEFT As Integer = 3   '左方面

End Class
