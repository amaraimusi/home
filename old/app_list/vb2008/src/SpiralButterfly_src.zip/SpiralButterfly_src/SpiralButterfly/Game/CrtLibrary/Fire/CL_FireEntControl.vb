﻿''' <summary>
''' クリーチャーライブラリ発射エンティティ制御
''' </summary>
''' <remarks></remarks>
Public Class CL_FireEntControl

#Region "定数"
    Public Shared CST_CRTID As String = "CrtId" ' クリーチャーＩＤ
    Public Shared CST_ＭUZZLEID As String = "ＭuzzleId" ' 発射口ＩＤ
    Public Shared CST_FIRECRTID As String = "FireCrtId" ' 発射クリーチャーＩＤ
    Public Shared CST_MUZZLERX As String = "MuzzleRx" ' 発射口相対座標Ｘ
    Public Shared CST_MUZZLERY As String = "MuzzleRy" ' 発射口相対座標Ｙ
    Public Shared CST_SPEED As String = "Speed" ' 発射物速度
    Public Shared CST_INTERVAL As String = "Interval" ' 発射間隔
#End Region


    ''' <summary>
    ''' クリーチャーライブラリ情報に光線発射情報をセットする。
    ''' </summary>
    ''' <param name="clEnt"></param>
    ''' <param name="dao"></param>
    ''' <remarks></remarks>
    Public Sub SetData(ByRef clEnt As CrtLibEntity(), ByRef dao As IDao)
        Try

            '■DBよりデータセットを取得する
            Dim sql As String = "SELECT * FROM FireTbl ORDER BY CrtId, ＭuzzleId"
            Dim dtSet As DataSet = dao.getDataSet(sql)

            For Each r As DataRow In dtSet.Tables(0).Rows
                With clEnt(CType(r(CST_CRTID), Integer))

                    '■エンティティにデータセットの値をセットする。
                    Dim ent As New CrtLibFireEntity
                    With ent
                        .CrtId = CType(r(CST_CRTID), Integer) 'クリーチャーＩＤ
                        .ＭuzzleId = CType(r(CST_ＭUZZLEID), Integer) '発射口ＩＤ
                        .FireCrtId = CType(r(CST_FIRECRTID), Integer) '発射クリーチャーＩＤ
                        .MuzzleRx = CType(r(CST_MUZZLERX), Single) '発射口相対座標Ｘ
                        .MuzzleRy = CType(r(CST_MUZZLERY), Single) '発射口相対座標Ｙ
                        .Speed = CType(r(CST_SPEED), Single) '発射物速度
                        .Interval = CType(r(CST_INTERVAL), Integer) '発射間隔

                    End With

                    '■衝突リストに追加
                    Dim ary As ArrayList = .GetAryFire
                    ary.Add(ent)

                End With
            Next
        Catch ex As Exception
            ErrMsg("CL_FireEntControl", "SetData", "情報の取得に失敗しました。", ex)
        End Try
    End Sub


End Class
