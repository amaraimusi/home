﻿''' <summary>
''' Crtライブラリ　衝突情報エンティティ
''' </summary>
''' <remarks></remarks>
Public Class CrtLibCollsionEntity
    Public CrtId As Integer 'クリーチャーＩＤ
    Public CollId As Integer '衝突部位ＩＤ
    Public Name As String '衝突部位名
    'Public RelPx As Single '衝突相対座標
    'Public RelPy As Single '衝突相対座標
    Public AP As Integer '攻撃力
    Public DP As Integer '防御力
    Public CollRadius As Single '衝突範囲半径

    ''' <summary>
    ''' 衝突部位の距離角度座標
    ''' </summary>
    ''' <remarks></remarks>
    Private pha As PointHypAng
    Public Sub SetPha(ByRef prm_pha As PointHypAng)
        pha = prm_pha
    End Sub
    Public Function GetPha() As PointHypAng
        Return pha
    End Function
End Class
