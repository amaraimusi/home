﻿''' <summary>
''' 動的ザコ出現位置決定機能
''' </summary>
''' <remarks></remarks>
Public Class DynamicAppZakoEntryPoint

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    ''' <summary>
    ''' 右下地点の座標
    ''' </summary>
    ''' <remarks></remarks>
    Private RBPt As New PointF
    ''' <summary>
    ''' 左上地点の座標
    ''' </summary>
    ''' <remarks></remarks>
    Private LUPt As New PointF


    ''' <summary>
    ''' 出現位置をセット
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub AppPointSet(ByVal stgId As Integer, ByRef crt As Creture)
        Dim stgEnt As StageEntity = StgCon.GetStageEntity(stgId) 'ステージエンティティ取得
        Dim aryAppZako As ArrayList = stgEnt.GetAryAppZako() '動的ザコ出現リストを取得

        'クリーチャーＩＤに緋もづく動的ザコ出現エンティティを取得
        Dim daze As DynamicAppZakoEntity = Nothing
        For Each r As DynamicAppZakoEntity In aryAppZako
            If r.CrtId = crt.CrtId Then
                daze = r
                Exit For
            End If
        Next
        If daze Is Nothing Then
            Exit Sub
        End If

        Dim aryPt As ArrayList = daze.GetAppPoint() '出現方面リストを取得




        Dim cnt As Integer = aryPt.Count
        Dim pt As New PointF
        If cnt = 0 Then
            crt.p0.X = 400
            crt.p0.Y = LUPt.Y
        Else
            Dim quarter As Integer = Int(Rnd() * cnt)
            Select Case CType(aryPt(quarter), Integer)
                Case DAZ_QuarterConst.UPPER
                    crt.p0.X = rnd2(RBPt.X, LUPt.X)
                    crt.p0.Y = LUPt.Y
                Case DAZ_QuarterConst.RIGHT
                    crt.p0.X = RBPt.X
                    crt.p0.Y = rnd2(RBPt.Y, LUPt.Y)
                Case DAZ_QuarterConst.BOTTOM
                    crt.p0.X = rnd2(RBPt.X, LUPt.X)
                    crt.p0.Y = RBPt.Y
                Case DAZ_QuarterConst.LEFT
                    crt.p0.X = LUPt.X
                    crt.p0.Y = rnd2(RBPt.Y, LUPt.Y)

            End Select
        End If



    End Sub

    ''' <summary>
    ''' 最小値以上、最大値未満の値を返す
    ''' </summary>
    ''' <param name="upperbound"></param>
    ''' <param name="lowerbound"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function rnd2(ByRef upperbound As Single, ByRef lowerbound As Single)
        Return (upperbound - lowerbound) * Rnd() + lowerbound

    End Function

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="prm_stageControl"></param>
    ''' <param name="prm_crtControl"></param>
    ''' <remarks></remarks>
    Public Sub Init(ByRef prm_stageControl As StageControl, ByRef prm_crtControl As CrtControl)
        StgCon = prm_stageControl
        CrtCon = prm_crtControl

        Dim app As AppContainer = AppContainer.getInstance
        Dim mainSize As Size = app.GetMainSize              '画面サイズを取得
        Dim outSize As Size = app.GetOutSize    '画面外範囲を取得

        LUPt.X = CSng(-outSize.Width + 50)
        LUPt.Y = CSng(-outSize.Height + 50)
        RBPt.X = CSng(mainSize.Width + outSize.Width - 50)
        RBPt.Y = CSng(mainSize.Height + outSize.Height - 50)

    End Sub

End Class
