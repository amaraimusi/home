﻿''' <summary>
''' 目標方向角度を取得　An aim direction angle
''' </summary>
''' <remarks>目標クリーチャーのいる方角を求める</remarks>
Public Class AL_AimDirectionAngle

    ''' <summary>
    ''' 丸め数値
    ''' </summary>
    ''' <remarks>オーバフロー防止のため</remarks>
    Private Const CST_ROUND As Single = 100

    Private CST_ANG90 As Single '90度のラジアン角度
    Private CST_ANG180 As Single '180度のラジアン角度
    Private CST_ANG270 As Single '270度のラジアン角度
    Private CST_ANG360 As Single '270度のラジアン角度


    Public Sub New()
        CST_ANG90 = Math.PI / 2
        CST_ANG180 = Math.PI
        CST_ANG270 = Math.PI * 1.5
        CST_ANG360 = Math.PI * 2
    End Sub

    ''' <summary>
    ''' 目標方向角度を取得　An aim direction angle
    ''' </summary>
    ''' <param name="crt"></param>
    ''' <param name="tarCrt"></param>
    ''' <returns></returns>
    ''' <remarks>目標クリーチャーのいる方角を求める</remarks>
    Public Function GetAng(ByRef crt As Creture, ByRef tarCrt As Creture) As Single

        Dim lx As Single = tarCrt.p0.X - crt.p0.X
        Dim ly As Single = tarCrt.p0.Y - crt.p0.Y
        Dim ax As Single = Math.Abs(tarCrt.p0.X - crt.p0.X)
        Dim ay As Single = Math.Abs(tarCrt.p0.Y - crt.p0.Y)
        Dim ang As Single = 0

        '■丸め処理（オーバーフロー防止のため）
        'ax = (ax * CST_ROUND) \ CST_ROUND
        'ay = (ay * CST_ROUND) \ CST_ROUND

        '■目標方向角度を算出
        If ax <> 0 And ay <> 0 Then
            Dim ang1 As Single = Math.Atan(ay / ax)
            If lx > 0 Then
                If ly > 0 Then
                    ang = ang1
                Else
                    ang = CST_ANG360 - ang1
                End If
            Else
                If ly > 0 Then
                    ang = CST_ANG180 - ang1
                Else
                    ang = ang1 + CST_ANG180
                End If
            End If
        ElseIf ax <> 0 And ay = 0 Then '目標方向角度が０度か180度の場合
            If lx > 0 Then
                ang = 0
            Else
                ang = CST_ANG180
            End If
        ElseIf ax = 0 And ay <> 0 Then '目標方向角度が90度か270度の場合
            If ly > 0 Then
                ang = CST_ANG90
            Else
                ang = CST_ANG270
            End If
        Else 'この条件は２つのクリーチャーが同一地点にいる場合。
            ang = crt.Ang '方角角度変化はない。
        End If

        Return ang
    End Function

End Class
