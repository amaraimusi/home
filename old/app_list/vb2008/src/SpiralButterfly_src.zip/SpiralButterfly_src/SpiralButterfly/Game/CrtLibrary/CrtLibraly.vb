﻿Imports Microsoft.DirectX.Direct3D

''' <summary>
''' クリーチャーライブラリ
''' </summary>
''' <remarks></remarks>
Public Class CrtLibraly

    ''' <summary>
    ''' クリーチャーライブラリ情報(CrtLib情報)
    ''' </summary>
    ''' <remarks></remarks>
    Private crtLibEntitys() As CrtLibEntity

#Region "キー定数"

    '■Crt基本情報の定数キー
    Private Const CST_CRTID = "CrtId"   'Crt　Idのキー
    Private Const CST_GRPID = "GrpId"   'グループIDのキー
    Private Const CST_NAME = "Name"     '名称のキー
    Private Const CST_WIDTH = "Width"   '幅のキー
    Private Const CST_HEIGHT = "Height"  '高さのキー
    Private Const CST_TEXNAME = "TexName" 'テクスチャーファイル名のキー
    Private Const CST_SPEED = "Speed"  '移動速度のキー
    Private Const CST_ACTIONID = "ActionId"  '移動速度のキー
    Private Const CST_HP = "HP"  'ＨＰのキー
    Private Const CST_TOKUTEN = "Tokuten"  '得点のキー

#End Region

    ''' <summary>
    ''' テクスチャーファイルパス
    ''' </summary>
    ''' <remarks></remarks>
    Private CST_CRTTEX_PATH As String = IO.Directory.GetCurrentDirectory & "\sys\tex\crt\"

    ''' <summary>
    ''' クリーチャーエンティティ配列をDBから読み込む
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Load()
        Dim app As AppContainer = AppContainer.getInstance
        Dim dao As IDao = app.GetDao
        Dim dxg As DxGraphicControl = app.GetDxg
        Dim maxIndex As Integer = GetMaxIndex(dao) 'CrtLib情報の要素数を取得
        Dim clEnt(maxIndex) As CrtLibEntity
        SetBaseData(clEnt, dao, dxg)         ' CrtLib情報にCrt基本情報をセットする。

        '■衝突情報をＤＢから取得し、CrtLib情報にセットする。
        Dim collCon As New CL_CollEntControl
        collCon.SetData(clEnt, dao)

        '■発射情報をＤＢから取得し、CrtLib情報にセットする。
        Dim fireCon As New CL_FireEntControl
        fireCon.SetData(clEnt, dao)

        crtLibEntitys = clEnt 'メンバにセット
    End Sub

    ''' <summary>
    ''' クリーチャーエンティティ配列にCrt基本情報をセットする。
    ''' </summary>
    ''' <param name="clEnts"></param>
    ''' <param name="dao"></param>
    ''' <remarks></remarks>
    Private Sub SetBaseData(ByRef clEnts As CrtLibEntity(), ByRef dao As IDao, ByRef dxg As DxGraphicControl)

        '■DBからクリーチャー基本情報DataSetを取得する
        Dim sql As String = "SELECT * FROM CrtTbl ORDER BY CrtId"
        Dim dtSet As DataSet = dao.getDataSet(sql)

        '■クリーチャー基本情報DataSetからクリーチャーエンティティ配列にセットする。

        For Each r As DataRow In dtSet.Tables(0).Rows
            Dim clEnt As New CrtLibEntity
            With clEnt
                .GrpId = CType(r(CST_GRPID), Integer)
                .Name = CType(r(CST_NAME), String)
                .Width = CType(r(CST_WIDTH), Integer)
                .Height = CType(r(CST_HEIGHT), Integer)
                .HypAng = Math.Atan(.Height / .Width)
                .Hyp = .Width / Math.Cos(.HypAng) / 2
                .PreFlg = True
                .Speed = CType(r(CST_SPEED), Single)
                .ActionId = CType(r(CST_ACTIONID), Integer)
                .Hp = CType(r(CST_HP), Integer)
                .Tokuten = CType(r(CST_TOKUTEN), Integer)

                Dim texFlNm As String = CST_CRTTEX_PATH & CType(r(CST_TEXNAME), String)
                Dim tex As Texture = dxg.CreateTextureFromFile(texFlNm)
                .SetTexture(tex)
            End With
            clEnts(CType(r(CST_CRTID), Integer)) = clEnt
        Next
    End Sub

    ''' <summary>
    ''' 最大要素数を取得する
    ''' </summary>
    ''' <param name="dao"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetMaxIndex(ByRef dao As IDao) As Integer
        Dim sql As String = "SELECT Max(CrtTbl.CrtId) AS MaxCrtId FROM CrtTbl"
        Dim dtSet As DataSet = dao.getDataSet(sql)
        Dim maxIndex As Integer = CType(dtSet.Tables(0).Rows(0)(0), Integer) + 1
        Return maxIndex
    End Function

    ''' <summary>
    ''' クリーチャーライブラリエンティティを取得する
    ''' </summary>
    ''' <param name="crtId"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetCrtLibEntity(ByVal crtId As Integer) As CrtLibEntity
        Return crtLibEntitys(crtId)
    End Function



End Class
