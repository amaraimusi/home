﻿Public Class CrtCollisionEntity
    Public CollId As Integer '衝突ID
    Public Name As String '衝突部位名
    'Public RelPx As Integer '衝突部位位置X
    'Public RelPy As Integer '衝突部位位置Y
    Public AP As Integer '攻撃力
    Public DP As Integer '防御力
    Public CollRadius As Integer '衝突半径
    Public Hyp As Single  '衝突部位斜辺（hypotenuse）
    Public Ang As Single  '衝突部位角度
    Public AbsPx As Single '衝突部絶対座標位置Ｘ
    Public AbsPy As Single '衝突部絶対座標位置Ｙ
End Class
