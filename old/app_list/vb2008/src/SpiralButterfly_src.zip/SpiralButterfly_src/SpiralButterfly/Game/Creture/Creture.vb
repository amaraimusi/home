﻿Imports Microsoft.DirectX.Direct3D

''' <summary>
''' クリーチャークラス
''' </summary>
''' <remarks></remarks>
Public Class Creture

    ''' <summary>
    ''' アクション書類情報
    ''' </summary>
    ''' <remarks></remarks>
    Private actDocDt As ActionDocData

    ''' <summary>
    ''' 衝突情報
    ''' </summary>
    ''' <remarks></remarks>
    Private aryColl As ArrayList

    ''' <summary>
    ''' 発射情報
    ''' </summary>
    ''' <remarks></remarks>
    Private aryFire As ArrayList

    ''' <summary>
    ''' テクスチャー
    ''' </summary>
    ''' <remarks></remarks>
    Private tex As Texture

    '基本パラメータ
    Public CrtId As Integer 'クリーチャーＩＤ
    Public Name As String '名称
    Public Width As Integer '幅
    Public Height As Integer '高さ
    Public Hyp As Single '斜辺
    Public HypAng As Single '斜辺角度
    Public TexName As String 'テクスチャーファイル名
    Public PreFlg As Boolean 'Falseの場合、データなしを示す
    Public MaxHp As Integer '最大ＨＰ
    Public Hp As Integer 'HP
    Public p0 As PointF '中心座標
    Public Ang As Single '向き角度
    Public AngVector As Single '進行方向角度
    Public Speed As Single '速度
    Public ActionId As Integer 'アクションID
    Public Tokuten As Integer '得点

    Public Sub New()
        actDocDt = New ActionDocData
        Init()
    End Sub

    ''' <summary>
    ''' データ初期化
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Init()
        '基本情報の初期化
        CrtId = 0
        Name = ""
        Width = 0
        Height = 0
        TexName = ""
        PreFlg = False
        p0.X = 0
        p0.Y = 0
        Ang = 0
        AngVector = 0
        Hp = 1

        actDocDt.InitActDocs() '書類情報の初期化
        aryColl = New ArrayList '衝突情報の初期化
        aryFire = New ArrayList '発射情報初期化
    End Sub

#Region "アクセサメソッド"
    ''' <summary>
    ''' 衝突情報のＧｅｔｔｅｒ
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAryColl() As ArrayList
        Return aryColl
    End Function

    ''' <summary>
    ''' 発射情報のＧｅｔｔｅｒ
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAryFire() As ArrayList
        Return aryFire
    End Function

    ''' <summary>
    ''' テクスチャーのＳｅｔｔｅｒ
    ''' </summary>
    ''' <param name="prm_tex"></param>
    ''' <remarks></remarks>
    Public Sub SetTexture(ByRef prm_tex As Texture)
        tex = prm_tex
    End Sub

    ''' <summary>
    ''' テクスチャーのＧｅｔｔｅｒ
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetTexture() As Texture
        Return tex
    End Function

    ''' <summary>
    ''' アクション書類のSetter
    ''' </summary>
    ''' <param name="actDoc"></param>
    ''' <remarks></remarks>
    Public Sub SetActDoc(ByRef actDoc As ActionDoc)
        'Dim actDoc As ActionDoc = actDocDt.GetActionDoc(ActionId)
        actDocDt.SetActionDoc(ActionId, actDoc)

    End Sub
    ''' <summary>
    ''' アクション書類のGetter
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetActDoc() As ActionDoc
        Return actDocDt.GetActionDoc(ActionId)
    End Function
#End Region
End Class
