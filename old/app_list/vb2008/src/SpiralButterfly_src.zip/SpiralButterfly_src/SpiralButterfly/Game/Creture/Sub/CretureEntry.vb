﻿''' <summary>
''' クリーチャーを出現させる
''' </summary>
''' <remarks></remarks>
Public Class CretureEntry

    ''' <summary>
    ''' クリーチャーライブラリ
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtLib As CrtLibraly

    ''' <summary>
    ''' クリーチャーリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private aryCrt As ArrayList

    Public Sub New(ByRef prm_crtLib As CrtLibraly, ByRef prm_aryCrt As ArrayList)
        CrtLib = prm_crtLib
        aryCrt = prm_aryCrt
    End Sub

    ''' <summary>
    ''' クリーチャー登場
    ''' </summary>
    ''' <param name="crtId"></param>
    ''' <param name="p0"></param>
    ''' <remarks>ゲーム中に指定のクリーチャーを登場させる</remarks>
    Public Function Entry(ByVal crtId As Integer, ByRef p0 As PointF) As Creture
        'クリーチャーライブラリエンティティを取得する
        Dim clEnt As CrtLibEntity = CrtLib.GetCrtLibEntity(crtId)

        'グループＩＤを取得する
        Dim grpId As Integer = clEnt.GrpId

        '登場クリーチャー情報から空の登場番号を取得する
        Dim entryNo As Integer = GetEntryNo(grpId)

        '空きの登場番号が存在しない場合、中断する
        If entryNo = -1 Then
            Return Nothing
        End If

        'グループＩＤ、登場番号に結びつくクリーチャー情報を取得する
        Dim crt As Creture = aryCrt(grpId)(entryNo)

        'クリーチャー情報を初期化する
        crt.Init()

        'クリーチャーを登場状態にする
        crt.PreFlg = True

        'クリーチャーライブラリエンティティからクリーチャー情報にデータをコピーまたは算出する。
        With crt
            .CrtId = crtId
            .Name = clEnt.Name
            .Width = clEnt.Width
            .Height = clEnt.Height
            .Hyp = clEnt.Hyp
            .HypAng = clEnt.HypAng
            .SetTexture(clEnt.GetTexture)
            .p0.X = p0.X
            .p0.Y = p0.Y
            .ActionId = clEnt.ActionId
            .Speed = clEnt.Speed
            .Hp = clEnt.Hp
            .MaxHp = .Hp
            .Tokuten = clEnt.Tokuten
        End With

        SetCollData(clEnt, crt) ' 衝突情報をクリーチャー情報にセットする
        SetFireData(clEnt, crt) ' 発射情報をクリーチャー情報にセットする
        Return crt
    End Function

    ''' <summary>
    ''' 発射情報をクリーチャー情報にセットする
    ''' </summary>
    ''' <param name="clEnt"></param>
    ''' <param name="crt"></param>
    ''' <remarks></remarks>
    Private Sub SetFireData(ByRef clEnt As CrtLibEntity, ByRef crt As Creture)

        '発射情報をコピーまた算出する
        Dim clAryFire As ArrayList = clEnt.GetAryFire() 'CL発射情報取得
        Dim aryFire As ArrayList = crt.GetAryFire 'Crt発射情報取得
        For Each clFireEnt As CrtLibFireEntity In clAryFire
            Dim cf As New CrtFireEntity
            With cf
                .CrtId = clFireEnt.CrtId 'クリーチャーＩＤ
                .ＭuzzleId = clFireEnt.ＭuzzleId '発射口ＩＤ
                .FireCrtId = clFireEnt.FireCrtId '発射クリーチャーＩＤ
                '.MuzzleRx = clFireEnt.MuzzleRx '発射口相対座標Ｘ
                '.MuzzleRy = clFireEnt.MuzzleRy '発射口相対座標Ｙ
                .MuzzleAng = Math.Atan(clFireEnt.MuzzleRy / clFireEnt.MuzzleRx)
                .MuzzleHyp = clFireEnt.MuzzleRx / Math.Cos(.MuzzleAng)
                .Speed = clFireEnt.Speed '発射物速度
                .Interval = clFireEnt.Interval '発射間隔
            End With
            aryFire.Add(cf)
        Next
    End Sub

    ''' <summary>
    ''' 衝突情報をクリーチャー情報にセットする
    ''' </summary>
    ''' <param name="clEnt"></param>
    ''' <param name="crt"></param>
    ''' <remarks></remarks>
    Private Sub SetCollData(ByRef clEnt As CrtLibEntity, ByRef crt As Creture)

        '衝突情報をコピーまた算出する
        Dim clAryColl As ArrayList = clEnt.GetAryCollision() 'CL衝突情報取得
        Dim aryColl As ArrayList = crt.GetAryColl 'Crt衝突情報取得
        For Each ccle As CrtLibCollsionEntity In clAryColl
            Dim cc As New CrtCollisionEntity
            With cc
                .CollId = ccle.CollId
                .AP = ccle.AP
                .DP = ccle.DP
                .CollRadius = ccle.CollRadius


                Dim pha As PointHypAng = ccle.GetPha
                .Ang = pha.Ang
                .Hyp = pha.Hyp
            End With
            aryColl.Add(cc)
        Next
    End Sub

    ''' <summary>
    ''' 登場クリーチャー情報から空の登場番号を取得する
    ''' </summary>
    ''' <param name="grpId">グループＩＤ</param>
    ''' <returns>登場番号</returns>
    ''' <remarks>空きが見つからない場合は登場番号は-1となる。</remarks>
    Private Function GetEntryNo(ByVal grpId As Integer) As Integer
        Dim entryNo As Integer = -1

        'グループＩＤに該当するクリーチャー配列を取得する
        Dim crts() As Creture = CType(aryCrt(grpId), Creture())
        For i As Integer = 0 To crts.Length - 1

            If crts(i).PreFlg = False Then

                entryNo = i
                Exit For
            End If
        Next
        Return entryNo
    End Function


End Class
