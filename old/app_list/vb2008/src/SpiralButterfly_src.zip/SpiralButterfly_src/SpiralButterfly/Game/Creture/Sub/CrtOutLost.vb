﻿''' <summary>
''' クリーチャー画面外消滅
''' </summary>
''' <remarks>
''' クリーチャーが画面外から一定の距離を進んだとき自然消滅する。
''' </remarks>
Public Class CrtOutLost

#Region "メンバ変数"
    Private OUT_X As Integer = 0 '許容外範囲X
    Private OUT_Y As Integer = 0 '許容外範囲Y
    Private mainSize As Size 'メインサイズ

    Private FieldPt1 As PointF '許容範囲
    Private FieldPt2 As PointF '許容範囲

    ''' <summary>
    ''' クリーチャーリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private aryCrt As ArrayList
#End Region

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="prm_aryCrt">クリーチャー情報</param>
    ''' <remarks></remarks>
    Public Sub New(ByRef prm_aryCrt As ArrayList)
        aryCrt = prm_aryCrt 'クリーチャー情報をセット
        Dim app As AppContainer = AppContainer.getInstance
        mainSize = app.GetMainSize              '画面サイズを取得
        Dim outSize As Size = app.GetOutSize    '画面外範囲を取得
        OUT_X = outSize.Width
        OUT_Y = outSize.Height

        '■許容範囲座標を算出する。
        FieldPt1 = New PointF(CSng(-OUT_X), CSng(-OUT_Y))
        FieldPt2 = New PointF(CSng(mainSize.Width + OUT_X), CSng(mainSize.Height + OUT_Y))


    End Sub

    ''' <summary>
    ''' クリーチャー画面外消滅
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub OutLost()
        For Each crts As Creture() In aryCrt
            For Each crt As Creture In crts
                With crt
                    If .PreFlg = True Then

                        If .p0.X < FieldPt1.X Or .p0.X > FieldPt2.X Or _
                            .p0.Y < FieldPt1.Y Or .p0.Y > FieldPt2.Y Then

                            .PreFlg = False
                        End If
                    End If
                End With
            Next
        Next
    End Sub
End Class
