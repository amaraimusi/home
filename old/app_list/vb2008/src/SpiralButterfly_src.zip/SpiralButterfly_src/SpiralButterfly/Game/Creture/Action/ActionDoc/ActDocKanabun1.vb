﻿Public Class ActDocKanabun1
    Inherits ActionDoc

    ''' <summary>
    ''' 初期処理フラグ
    ''' </summary>
    ''' <remarks></remarks>
    Public IniFlg As Boolean
End Class
