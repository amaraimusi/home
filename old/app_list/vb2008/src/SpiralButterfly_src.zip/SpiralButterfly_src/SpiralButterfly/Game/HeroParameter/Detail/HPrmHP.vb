﻿Imports Microsoft.DirectX.Direct3D
''' <summary>
''' HP主人公パラメータ
''' </summary>
''' <remarks></remarks>
Public Class HPrmHP
    Implements IHeroParameter


    ''' <summary>
    ''' DirectXグラフィック制御
    ''' </summary>
    ''' <remarks></remarks>
    Private Dxg As DxGraphicControl

    ''' <summary>
    ''' オブジェクトパーツ構造体
    ''' </summary>
    ''' <remarks></remarks>
    Private Structure Part
        Dim TexFlNm As String
        Dim Tex As Texture
        Dim Sz As SizeF
        Dim RelPt As PointF
    End Structure

    Private HpBack As Part 'ＨＰ背景パーツ
    Private HpBar As Part 'ＨＰバーパーツ
    Private HpWaku As Part 'ＨＰ枠パーツ

    ''' <summary>
    ''' テクスチャーファイルのパス
    ''' </summary>
    ''' <remarks></remarks>
    Private DIR_PATH As String = IO.Directory.GetCurrentDirectory & "\sys\tex\hprm\"

    ''' <summary>
    ''' HPバーの長さ
    ''' </summary>
    ''' <remarks></remarks>
    Private HpBarWidth As Single

    ''' <summary>
    ''' 共通ロジック
    ''' </summary>
    ''' <remarks></remarks>
    Private com As HPrmCommon


    Public Sub New(ByRef prm_HPrmCommon As HPrmCommon)
        com = prm_HPrmCommon

        '■テクスチャーファイル名
        HpBack.TexFlNm = "hp_back.dds"
        HpBar.TexFlNm = "hp_bar.dds"
        HpWaku.TexFlNm = "hp_waku.dds"

        '■パーツサイズ,相対位置の設定
        With HpBack
            .Sz.Width = 245.0F
            .Sz.Height = 21.0F
            .RelPt.X = 57.0F
            .RelPt.Y = 4.0F
        End With
        With HpBar
            .Sz.Width = 245.0F
            .Sz.Height = 21.0F
            .RelPt.X = 57.0F
            .RelPt.Y = 4.0F
        End With
        With HpWaku
            .Sz.Width = 360.0F
            .Sz.Height = 29.0F
            .RelPt.X = 0.0F
            .RelPt.Y = 0.0F
        End With

        '■テクスチャーの作成
        Dxg = AppContainer.getInstance.GetDxg
        HpBack.Tex = Dxg.CreateTextureFromFile(DIR_PATH & HpBack.TexFlNm)
        HpBar.Tex = Dxg.CreateTextureFromFile(DIR_PATH & HpBar.TexFlNm)
        HpWaku.Tex = Dxg.CreateTextureFromFile(DIR_PATH & HpWaku.TexFlNm)


    End Sub

    ''' <summary>
    ''' 情報更新
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Update() Implements IHeroParameter.Update
        Dim heroCrt As Creture = com.GetHeroCreture
        With heroCrt
            heroCrt.Hp = 10
            HpBarWidth = HpBar.Sz.Width * .Hp / .MaxHp
        End With
    End Sub

    ''' <summary>
    ''' 描画
    ''' </summary>
    ''' <param name="pt"></param>
    ''' <remarks></remarks>
    Public Sub Draw(ByRef pt As System.Drawing.PointF) Implements IHeroParameter.Draw
        With HpBack
            Dxg.Draw2D(.Tex, pt.X + .RelPt.X, pt.Y + .RelPt.Y, .Sz.Width, .Sz.Height)
        End With
        With HpBar
            Dxg.Draw2D(.Tex, pt.X + .RelPt.X, pt.Y + .RelPt.Y, HpBarWidth, .Sz.Height)
        End With
        With HpWaku
            Dxg.Draw2D(.Tex, pt.X + .RelPt.X, pt.Y + .RelPt.Y, .Sz.Width, .Sz.Height)
        End With
    End Sub
End Class
