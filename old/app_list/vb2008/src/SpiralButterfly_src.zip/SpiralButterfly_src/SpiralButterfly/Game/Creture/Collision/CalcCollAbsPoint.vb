﻿''' <summary>
''' ' 衝突部位絶対座標を算出する
''' </summary>
''' <remarks></remarks>
Public Class CalcCollAbsPoint

    ''' <summary>
    ''' クリーチャー情報
    ''' </summary>
    ''' <remarks></remarks>
    Private aryCrt As ArrayList

    ''' <summary>
    ''' 90度定数
    ''' </summary>
    ''' <remarks></remarks>
    Private ANG90 As Single = Math.PI * 0.5F
    Private ANG360 As Single = Math.PI * 2.0F

    Public Sub New(ByRef prm_aryCrt As ArrayList)
        aryCrt = prm_aryCrt
    End Sub

    ''' <summary>
    ''' 衝突部位絶対座標を算出する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Calc()
        For Each crts As Creture() In aryCrt
            For Each crt As Creture In crts
                With crt
                    If .PreFlg = True Then
                        Dim faceAng As Single = .Ang '向き角度
                        For Each cc As CrtCollisionEntity In .GetAryColl
                            Dim absAng As Single = faceAng + ANG90 - cc.Ang
                            'Dim absAng As Single = cc.Ang
                            cc.AbsPx = .p0.X + cc.Hyp * Math.Cos(absAng)
                            cc.AbsPy = .p0.Y + cc.Hyp * Math.Sin(absAng)
                        Next
                    End If
                End With
            Next
        Next
    End Sub

End Class
