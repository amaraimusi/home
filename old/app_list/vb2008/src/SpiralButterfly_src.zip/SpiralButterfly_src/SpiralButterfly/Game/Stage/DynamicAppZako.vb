﻿''' <summary>
''' 動的雑魚出現
''' </summary>
''' <remarks></remarks>
Public Class DynamicAppZako

    '※「DAZ」は動的雑魚出現率の事。

    ''' <summary>
    ''' 全ステージ雑魚出現テーブル
    ''' </summary>
    ''' <remarks>
    ''' 全ステージ雑魚出現テーブル arrayList all dynamic app zako table
    ''' </remarks>
    Private aryAllDazTbl As ArrayList

    ''' <summary>
    ''' 雑魚出現テーブル配列のおよその最大。
    ''' </summary>
    ''' <remarks>処理の関係上、この値が雑魚出現テーブルの最大値とはならない。近い数値にはなる。</remarks>
    Private Const CST_TBL_MAXINDEX As Integer = 300

    ''' <summary>
    ''' クリーチャー制御
    ''' </summary>
    ''' <remarks></remarks>
    Private CrtCon As CrtControl

    ''' <summary>
    ''' ステージ制御
    ''' </summary>
    ''' <remarks></remarks>
    Private StgCon As StageControl

    ''' <summary>
    ''' 動的ザコ出現位置決定機能
    ''' </summary>
    ''' <remarks>SetCrtControlでインスタンス生成</remarks>
    Private DazEntryPt As DynamicAppZakoEntryPoint

    ''' <summary>
    ''' ステージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Private m_stgEnts As StageEntity()

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="stgEnts">ステージ情報</param>
    ''' <remarks>全ステージ雑魚出現テーブルをステージ情報から作成する。</remarks>
    Public Sub New(ByRef stgEnts As StageEntity())
        aryAllDazTbl = New ArrayList '全ステージ雑魚出現テーブル arrayList all dynamic app zako table
        Dim i As Integer = 0
        For Each stg As StageEntity In stgEnts

            If stg Is Nothing Then
                aryAllDazTbl.Add(Nothing)
            Else
                Dim dazTbl As Integer() = getDazTbl(stg)
                aryAllDazTbl.Add(dazTbl)

            End If
            i += 1
        Next
        '▼メンバオブジェクトにセット
        m_stgEnts = stgEnts         'ステージ情報をセット
    End Sub

    ''' <summary>
    ''' クリーチャー制御のSetter
    ''' </summary>
    ''' <param name="prm_CrtControl"></param>
    ''' <remarks></remarks>
    Public Sub SetControl(ByRef prm_CrtControl As CrtControl, ByRef prm_StgCon As StageControl)
        'メンバオブジェクトにセット
        CrtCon = prm_CrtControl
        StgCon = prm_StgCon

        '動的ザコ出現位置機能の初期化
        DazEntryPt = New DynamicAppZakoEntryPoint
        DazEntryPt.Init(StgCon, CrtCon)
    End Sub

    ''' <summary>
    ''' 雑魚出現テーブルを取得する
    ''' </summary>
    ''' <param name="stg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getDazTbl(ByRef stg As StageEntity) As Integer()

        '動的出現雑魚リストを取得する
        Dim aryDaz As ArrayList = stg.GetAryAppZako

        '雑魚出現率合計値を取得する
        Dim dazTotal As Integer = 0
        For Each daz As DynamicAppZakoEntity In aryDaz
            dazTotal = dazTotal + daz.AppRate
        Next

        '雑魚出現千分率配列を作成する
        Dim aryDazSen As New ArrayList
        For Each daz As DynamicAppZakoEntity In aryDaz
            Dim sen As Integer = 0
            If daz.AppRate <> 0 Then
                sen = CST_TBL_MAXINDEX * daz.AppRate / dazTotal
                If sen = 0 Then sen = 1
            Else
                sen = 0
            End If
            aryDazSen.Add(sen)
        Next

        '雑魚出現千分率合計値を求める
        Dim dazSenTotal As Integer = 0
        For Each sen As Integer In aryDazSen
            dazSenTotal += sen
        Next

        '雑魚出現テーブルを作成する
        Dim dazTbl(dazSenTotal) As Integer
        For k As Integer = 0 To dazTbl.Length - 1
            dazTbl(k) = -1
        Next
        Dim i As Integer = 0
        Dim startV As Integer = 0
        Dim v2 As Integer = 0
        For Each daz As DynamicAppZakoEntity In aryDaz
            Dim crtId As Integer = daz.CrtId
            v2 += CType(aryDazSen.Item(i), Integer)
            For k As Integer = startV To v2 - 1
                dazTbl(k) = crtId
            Next
            startV = v2
            i += 1
        Next

        Return dazTbl
    End Function

#Region "ザコの出現"
    Private NowAppRate As Integer '現在の出現率
    Private addSubFlg As Integer = True '出現率変化の加減フラグ　addition and subtraction.


    ''' <summary>
    ''' 雑魚の出現
    ''' </summary>
    ''' <param name="stgId">現在のステージID</param>
    ''' <remarks>一定の確率でザコを出現させる</remarks>
    Public Sub AppearZako(ByVal stgId As Integer)
        '■出現率の変化
        Dim stg As StageEntity = m_stgEnts(stgId)
        If addSubFlg = True Then
            NowAppRate += stg.ZakoAppExchangeRate
            If NowAppRate >= stg.MaxZakoAppRate Then
                addSubFlg = False
            End If
        Else
            NowAppRate -= stg.ZakoAppExchangeRate
            If NowAppRate <= stg.MinZakoAppRate Then
                addSubFlg = True
            End If
        End If

        '■出現する確率によってザコを出現させる
        Dim crtId As Integer = -1
        If NowAppRate >= Rnd() * 100 Then

            Dim dazTbl As Integer() = CType(aryAllDazTbl(stgId), Integer())
            Dim r As Integer = Rnd() * dazTbl.Length
            If r >= 0 And r < dazTbl.Length Then
                crtId = dazTbl(r)
            End If

        End If

        If crtId <> -1 Then

            'クリーチャーを登場させる
            Dim crt As Creture = CrtCon.Entry(crtId, New PointF(0.0F, 0.0F))

            'クリーチャーの初期位置を決定する
            DazEntryPt.AppPointSet(stgId, crt)
        End If


    End Sub
#End Region
End Class
