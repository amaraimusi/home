﻿Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Public Class FormMain


#Region " スレッド制御 "
    'スレッドを制御するオブジェクト
    Private m_thrdSpeed As Integer

    'スレッドの一時停止を行う。
    Private m_threadStopFlg As Boolean

    'スレッド開始(loopStartと同じ）
    Public Sub threadStart()

        'スレッド停止フラグを解除する。
        m_threadStopFlg = False
        Try
            'バックグランドワーカーを実行する。
            Do
                If Me.BackgroundWorker1.IsBusy = True Then
                Else
                    Me.BackgroundWorker1.RunWorkerAsync()
                    Exit Do
                End If
                Application.DoEvents()
            Loop
        Catch ex As Exception
            MsgBox(Err.Description & vbCrLf & "バックグランドワーカーの始動に失敗")
        End Try
    End Sub

    'スレッド終了（例外を発生させて終了する）
    Public Sub threadEnd()
        threadStopOneTime()
    End Sub

    'スレッド一時停止
    Public Sub threadStopOneTime()
        m_threadStopFlg = True
    End Sub

    'スレッド一時停止解除
    Public Sub threadReStopOneTime()
        m_threadStopFlg = False
        Try
            Do

                If Me.BackgroundWorker1.IsBusy = True Then
                Else
                    Me.BackgroundWorker1.RunWorkerAsync()
                    Exit Do
                End If
                Application.DoEvents()
            Loop
        Catch ex As Exception
            MsgBox(Err.Description & vbCrLf & "スレッド一時停止解除に失敗した")
        End Try
    End Sub


    Public Function getThrdSpeed() As Integer
        Return m_thrdSpeed
    End Function
    Public Sub setThrdSpeed(ByVal prm_thrdSpeed As Integer)
        m_thrdSpeed = prm_thrdSpeed
    End Sub


    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        System.Threading.Thread.Sleep(m_thrdSpeed)

    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted

        'スレッド停止フラグがFalseの場合、以下の処理を実行する。
        If m_threadStopFlg = False Then

            'メインループ（テンプレートパターンを適用）
            mainLoopHook()
            Try
                '再度バックグランドワーカーを実行する。
                Me.BackgroundWorker1.RunWorkerAsync()
            Catch ex As Exception
                MsgBox(Err.Description & vbCrLf & "バックグランドワーカーの始動に失敗")
            End Try

        End If
    End Sub



#End Region

    ''' <summary>
    ''' アプリケーションコンテナ
    ''' </summary>
    ''' <remarks></remarks>
    Private app As AppContainer

    ''' <summary>
    ''' ゲームマスター
    ''' </summary>
    ''' <remarks></remarks>
    Private gMst As GameMaster

    ''' <summary>
    ''' 前回の時間
    ''' </summary>
    ''' <remarks></remarks>
    Private m_BTicks As Long ' Before Ticks

    Private m_iniFlg2 As Boolean

    Private m_grpc As Graphics

    ''' <summary>
    ''' DirectXグラフィック制御
    ''' </summary>
    ''' <remarks></remarks>
    Private dxG As DxGraphicControl

    Private m_endFlg As Integer = 0


    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If m_endFlg <> 2 Then
            e.Cancel = True
            m_endFlg = 1
        End If
    End Sub

    ''' <summary>
    ''' フォームロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Debug.Print("アプリケーション開始")


        Me.Show()

        '■■■アプリケーションコンテナに各種オブジェクトをセットする。


        app = AppContainer.getInstance()
        app.SetFormMain(Me) 'アプリケーションコンテナにこのフォームをセットする。
        Prg1.Maximum = 11 '進捗数
        Prg1.Step = 1

        '共通プロパティを生成
        Dim prpCom As PropertyCommon = PropertyCommon.getInstance
        app.SetPrpCom(prpCom)
        Prg1.PerformStep() '進捗

        'DAOを生成
        Dim dao As IDao = New DaoForJet(prpCom.MdbFlNm)
        app.SetDao(dao)
        Prg1.PerformStep() '進捗

        'Dxグラフィック制御を生成する
        Dim mainSize As Size = New Size(800, 600)    'メインサイズを指定
        Me.Size = mainSize   'フォームサイズを指定
        app.SetMainSize(mainSize)
        dxG = New DxGraphicControl(Me)
        app.SetDxg(dxG)
        Prg1.PerformStep() '進捗

        '画面外範囲を指定
        Dim outSize As Size = New Size(100, 100)
        app.SetOutSize(outSize)

        '効果音制御を生成する
        Dim efSnd As New EffectSoundControl(Me)
        app.SetEfSnd(efSnd)
        efSnd.Load() '効果音データの読込
        Prg1.PerformStep() '進捗

        'Dx入力制御を生成する
        Dim inp As New CDirectInputEx1(Me)
        app.SetDxInp(inp)
        Prg1.PerformStep()


        'ステージ制御を生成する
        Dim stgCon As New StageControl
        stgCon.Load()
        app.SetStageControl(stgCon)
        Prg1.PerformStep() '進捗

        '主人公パラメータを生成する
        Dim hprmCon As New HeroParameterControl
        app.SetHPrmControl(hprmCon)
        Prg1.PerformStep() '進捗



        'クリーチャーライブラリを生成する。
        Dim crtLib As New CrtLibraly()
        crtLib.Load()
        app.SetCrtLibral(crtLib)
        Prg1.PerformStep() '進捗

        'クリーチャー制御を生成する
        Dim cc As New CrtControl(crtLib)
        app.SetCrtControl(cc)
        Prg1.PerformStep() '進捗

        'ゲームマスターを生成する
        gMst = New GameMaster(stgCon, crtLib, cc, hprmCon)
        app.SetGameMaster(gMst)
        Prg1.PerformStep() '進捗

        '■オブジェクトの初期化、セッティング
        stgCon.SetCrtControl(cc) 'ステージ制御にクリーチャー制御をセット
        cc.Init(stgCon, hprmCon) 'クリーチャー制御初期化処理
        hprmCon.Init(stgCon, cc) '主人公パラメータ初期化処理
        Prg1.PerformStep() '進捗




        Me.setThrdSpeed(30)             'スレッドの感覚を設定
        Prg1.Visible = False

        Me.threadStart() 'スレッド開始

        Debug.Print("フォームロード完了")

        m_grpc = Me.CreateGraphics
    End Sub



    Private tex1 As Texture
    Private d3_1 As DXG_3DModel
    Private ang1 As Integer = 0

    ''' <summary>
    ''' メインループ
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub mainLoopHook()

        MES_Start()
        'Me.Refresh()
        '■ループ時間計測
        Dim strTick As String = GetLoopTimeString()
        If m_iniFlg2 = False Then
            '■サンプルテクスチャーを作成
            Dim FlNm As String = IO.Directory.GetCurrentDirectory & "\sys\tex\" & "mamemusi02.dds"
            tex1 = dxG.CreateTextureFromFile(FlNm)

            '■サンプル３Dモデルを作成
            Dim xFlNm As String = IO.Directory.GetCurrentDirectory & "\sys\x\" & "neko.x"
            d3_1 = dxG.Creat3DModel(xFlNm)
            m_iniFlg2 = True

        End If

        ''■入力の取得
        'Dim inp As CDirectInputEx1 = app.GetDxInp
        'Dim pid As PlayerInputData = inp.getPlayerInputData(0)
        'Dim inputVal = pid.Axis(0)



        'Randomize() '乱数値初期化
        Try

            app.UpdatePlayerInputData()
        Catch ex As Exception
            MsgBox("入力制御でエラー" & vbCrLf & ex.Source)
            app.UpdatePlayerInputData()
        End Try
        '■ゲームマスタによるゲーム進行
        gMst.TreadRun()


        '    dxG.DrawStart()

        ''gMst.Draw() 'ゲームマスタの描画
        '

        '    '測定時間を出力する
        ''dxG.DrawText("測定時間：" & MES_GetRecordTick(), New Point(10, 5), Color.Yellow)

        ''■線描画テスト
        'dxG.LineAdd(100, 100, 200, 300)
        'dxG.LineAdd(150, 300, 400, 400)
        'dxG.DrawLine()

        '    'ループ時間を出力する
        '    dxG.DrawText(strTick, New Point(10, 30), Color.Yellow)

        '    '入力を出力する
        ''dxG.DrawText("入力テスト：" & inputVal.ToString, New Point(10, 65), Color.Red)



        '    '2D描画を行う　　　　　
        '    'dxG.Draw2D(tex1, New Point(300, 100), New Size(40, 80), 90)
        '    ang1 += 1
        '    Dim sx As Single = 100
        '    Dim sy As Single = 80
        '    dxG.Draw2D(tex1, New Point(100, 200), New Size(sx, sy), ang1)

        '    Dim hypAng As Single = Math.Atan(sy / sx)
        '    Dim hyp As Single = sx / Math.Cos(hypAng)
        '    dxG.Draw2D(tex1, New PointF(100, 300), ang1 * Math.PI / 180, hyp, hypAng)
        '    'dxG.Draw2D(tex1, New PointF(100, 200), 0, 100, 0.2 * Math.PI)
        '    'dxG.Draw2D(tex1, 100, 300, 40, 50)

        ''■３D描画テスト
        'dxG.Draw3D(d3_1)




        'dxG.drawEnd()


        gMst.Draw()

        'm_grpc.Clear(Color.Blue)
        'gMst.DrawFrame() 'クリーチャーフレーム描画

   
     
            '■アプリケーション終了処理
            If m_endFlg = 1 Then
                Unload()
            End If



            MES_End()
    End Sub



    Private Function GetLoopTimeString() As String
        Dim tick As Long = Now.Ticks
        Dim strTick As String = (tick - m_BTicks) \ 10000
        strTick = "ループ時間:" & strTick
        m_BTicks = tick
        Return strTick
    End Function

    Public Sub Unload()
        '■終了処理
        dxG = Nothing


        m_endFlg = 2
        Me.Close()

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()

        Debug.Print("アプリケーション終了")
    End Sub


End Class