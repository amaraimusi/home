package ja.co.amaraimusi.sa;

import java.util.ArrayList;

import jp.co.amaraimusi.DaoForMySQL;
import jp.co.amaraimusi.IDao;
import junit.framework.TestCase;

public class GetCategoryDataTest extends TestCase {

	public void testGetCategoryData() {
		IDao dao = getDao();
		GetCategoryData obj=new GetCategoryData(dao);
		ArrayList<CategoryEntity> ary=obj.getCategoryData();
		for(CategoryEntity ent:ary){
			System.out.println(ent.getCategory1Name());
		}
		
	}

	private IDao getDao() {
		IDao dao = new DaoForMySQL("sample_a","root","neko");
		return dao;
	}

}
