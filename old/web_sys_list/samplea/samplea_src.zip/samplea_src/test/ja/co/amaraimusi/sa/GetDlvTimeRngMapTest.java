package ja.co.amaraimusi.sa;

import java.util.LinkedHashMap;
import java.util.Set;

import jp.co.amaraimusi.DaoForMySQL;
import jp.co.amaraimusi.IDao;
import junit.framework.TestCase;

public class GetDlvTimeRngMapTest extends TestCase {

	public void testGetMap() {
		IDao dao = new DaoForMySQL("sample_a","root","neko");
		GetDlvTimeRngMap obj=new GetDlvTimeRngMap(dao);
		LinkedHashMap<String,String> map=obj.getMap();
		Set<String> keys=map.keySet();
		for(String key:keys){
			System.out.println(key + ":" + map.get(key));
		}
	}

}
