package ja.co.amaraimusi.sa;

import jp.co.amaraimusi.DaoForMySQL;
import jp.co.amaraimusi.IDao;
import junit.framework.TestCase;

public class CreateOderIdTest extends TestCase {

	public void testGetSerializeNo() {
		IDao dao = getDao();
		CreateOderId obj = new CreateOderId(dao);
		showSerialNo(obj);
		showSerialNo(obj);
		showSerialNo(obj);
		showSerialNo(obj);
		showSerialNo(obj);
		showSerialNo(obj);
	}

	private void showSerialNo(CreateOderId obj) {
		int id = obj.getSerializeNo();
		System.out.println(id);
	}

	private IDao getDao() {
		IDao dao = new DaoForMySQL("sample_a", "root", "neko");
		return dao;
	}

}
