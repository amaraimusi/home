package action;

import ja.co.amaraimusi.sa.BuySellEntity;
import ja.co.amaraimusi.sa.Cart;
import ja.co.amaraimusi.sa.Const;
import ja.co.amaraimusi.sa.ItemEntity;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import form.HomeForm;



/**
* HelloAction.java
*/
public class InCartForHomeAction extends Action {

    Log log = LogFactory.getLog(InCartForHomeAction.class);

    public ActionForward execute(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
    throws Exception {
   
    	//�V���i���X�g���擾���܂��B
    	HomeForm fm =(HomeForm) form;
    	ArrayList<BuySellEntity> ls =fm.getNewItemList();
    	
    	//�Z�b�V��������J�[�g���擾���A�J�[�g��null�Ȃ琶�����āA�Z�b�g���܂��B
    	HttpSession ses=request.getSession();
    	Cart cr=(Cart) ses.getAttribute(Const.CART);
    	if (cr==null){
    		cr=new Cart();
    		ses.setAttribute(Const.CART, cr);
    	}
    	
    	//�J�[�g���������w�����ɉ����܂��B
    	for(BuySellEntity ent:ls){
    		int inItemCount=ent.getInItemCount();
    		if (inItemCount!=0){	
    			ItemEntity itemEnt =ent;
    			cr.inCart(itemEnt, ent.inItemCount);
        		ent.setInItemCount(0);
    		}
    	}
    	
 	
        return mapping.findForward("success");
    }
}