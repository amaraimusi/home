package action;

import ja.co.amaraimusi.sa.AppContainer;
import ja.co.amaraimusi.sa.Const;
import ja.co.amaraimusi.sa.GetDlvTimeRngMap;
import ja.co.amaraimusi.sa.GetPayTypeMap;
import ja.co.amaraimusi.sa.GetSendTypeMap;

import java.util.LinkedHashMap;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.amaraimusi.DaoForDataSource;
import jp.co.amaraimusi.IDao;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.InpAddressForm;

/**
 * InpAddressAction.java
 */
public class InpAddressAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		System.out.println("������InpAddressAction");

		HttpSession ses = request.getSession();

		// �Z�b�V������DAO�����݂��Ȃ���΁ADAO�𐶐����āA�v���p�e�B�ƃZ�b�V�����ɃZ�b�g����B
		IDao dao = getDao(ses);

		InpAddressForm fm = (InpAddressForm) form;

		AppContainer app = AppContainer.getInstance();

		// �x�������@���X�g���擾���ăt�H�[���ɃZ�b�g����B
		LinkedHashMap<String, String> payTypeMap = app.getPayTypeMap();
		if (payTypeMap == null) {
			GetPayTypeMap getPayTypeMap = new GetPayTypeMap(dao);
			payTypeMap = getPayTypeMap.getMap();
			app.setPayTypeMap(payTypeMap);
		}
		fm.setPayTypeMap(payTypeMap);

		// �������@���X�g���擾���ăt�H�[���ɃZ�b�g����B
		LinkedHashMap<String, String> sendTypeMap = app.getSendTypeMap();
		if (sendTypeMap == null) {
			GetSendTypeMap getSendTypeMap = new GetSendTypeMap(dao);
			sendTypeMap = getSendTypeMap.getMap();
			app.setSendTypeMap(sendTypeMap);
		}
		fm.setSendTypeMap(sendTypeMap);

		// �x�������@���X�g���擾���ăt�H�[���ɃZ�b�g����B
		LinkedHashMap<String, String> dlvTimeRngMap = app.getDlvTimeRng();
		if (dlvTimeRngMap == null) {
			GetDlvTimeRngMap getDlvTimeRngMap = new GetDlvTimeRngMap(dao);
			dlvTimeRngMap = getDlvTimeRngMap.getMap();
			app.setDlvTimeRng(dlvTimeRngMap);
		}
		fm.setDlvTimeRngMap(dlvTimeRngMap);

		testMapView(fm.getPayTypeMap());
		testMapView(fm.getSendTypeMap());
		testMapView(fm.getDlvTimeRngMap());

		return mapping.findForward("success");
	}

	private void testMapView(LinkedHashMap<String, String> map) {
		if (map.size() == 0) {
			System.out.println("��ł��B");
		}
		Set<String> keys = map.keySet();
		for (String key : keys) {
			System.out.println(key + ":" + map.get(key));
		}
	}

	private IDao getDao(HttpSession ses) {
		IDao dao = (IDao) ses.getAttribute(Const.DAO);
		if (dao == null) {
			dao = new DaoForDataSource("jdbc/forODBC");
			ses.setAttribute(Const.DAO, dao);
		}
		return dao;
	}

}