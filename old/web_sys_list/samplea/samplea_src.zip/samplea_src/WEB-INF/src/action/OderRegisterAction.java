package action;

import ja.co.amaraimusi.sa.AppContainer;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.amaraimusi.DaoForDataSource;
import jp.co.amaraimusi.IDao;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.InpAddressForm;

/**
 * CheckInpDataAction.java
 */
public class OderRegisterAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		System.out.println("������OderRegisterAction");

		InpAddressForm fm = (InpAddressForm) form;

		int oderId = AppContainer.getInstance().getCrtOderId().getSerializeNo();
		
		IDao dao =new DaoForDataSource("jdbc/forODBC");

		java.sql.Connection con = dao.getConnection();
		String query = "INSERT INTO OderTbl(" + "Id," + "CusId," + "Name,"
				+ "Furigana," + "Yubin," + "Address," + "Tell," + "MailAddress,"
				+ "PayType," + "SendType," + "DeliveryWishDay,"
				+ "DeliveryTimeRange," + "Comment," + "PayFlg," + "SendFlg,"
				+ "OderDateTime," + "ItemsValue" + ")"
				+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		System.out.println(query);
		java.sql.PreparedStatement pstmt = con.prepareStatement(query);
		int index = 1;
		pstmt.setInt(index, oderId); 
		index++;
		pstmt.setInt(index, -1);
		index++;
		pstmt.setString(index, fm.getNamae());
		index++;
		pstmt.setString(index, fm.getFurigana());
		index++;
		pstmt.setString(index, fm.getYubin());
		index++;
		pstmt.setString(index, fm.getAddress());
		index++;
		pstmt.setString(index, fm.getTell());
		index++;
		pstmt.setString(index, fm.getMailAddress());
		index++;
		pstmt.setInt(index, fm.getPayType());
		index++;
		pstmt.setInt(index, fm.getSendType());
		index++;
		pstmt.setString(index, fm.getDeliveryWishDay());
		index++;
		pstmt.setInt(index, fm.getDeliveryTimeRange());
		index++;
		pstmt.setString(index, fm.getComment());
		index++;
		pstmt.setBoolean(index, false);
		index++;
		pstmt.setBoolean(index, false);
		index++;
		pstmt.setDate(index, getToday());
		index++;
		pstmt.setBigDecimal(index, fm.getItemsValue());

		con.setAutoCommit(false);

		try {

			pstmt.executeUpdate();// �N�G���[�����s����
			con.commit();// �R�~�b�g����

		} catch (SQLException e) {
			con.rollback();
			throw e;
		} finally {
			con.setAutoCommit(true);// �����R�~�b�g��ON�ɂ���B
			pstmt.close();
			con.close();
		}

		request.getSession(true).invalidate();//��������폜����B
		HttpSession ses = request.getSession(true);//�V�����Z�b�V�����𐶐��i�Z�b�V����ID�͈قȂ���̂ɂȂ�B�j
		ses.setAttribute("oderId", oderId);
		
		return mapping.findForward("success");
	}

	/**
	 * �{���̓��t�������擾����
	 * 
	 * @return �{���̓��t����
	 */
	private java.sql.Date getToday() {
		Calendar cl = Calendar.getInstance();
		Date d = cl.getTime();
		java.sql.Date d2 = new java.sql.Date(d.getTime());
		System.out.println(d.toString());
		System.out.println(d2.toString());
		return d2;
	}
/*	private IDao getDao(HttpSession ses) {
		IDao dao = (IDao) ses.getAttribute(Const.DAO);
		if (dao == null) {
			dao = new DaoForDataSource("jdbc/forODBC");
			ses.setAttribute(Const.DAO, dao);
		}
		return dao;
	}*/


}