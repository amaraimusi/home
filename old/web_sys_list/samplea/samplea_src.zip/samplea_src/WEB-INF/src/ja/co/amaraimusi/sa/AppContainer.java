package ja.co.amaraimusi.sa;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import jp.co.amaraimusi.DaoForDataSource;
import jp.co.amaraimusi.IDao;

public class AppContainer {
	private static AppContainer myself = new AppContainer();

	private AppContainer() {

		// �J�e�S�������擾����
		IDao dao = new DaoForDataSource("jdbc/forODBC");
		GetCategoryData gcd = new GetCategoryData(dao);
		categoryData = gcd.getCategoryData();
	}
	/**
	 * DAO�𐶐�����
	 * @return
	 */
	public IDao createDao(){
		return new DaoForDataSource("jdbc/forODBC");
	}

	public static AppContainer getInstance() {
		return myself;
	}

	/**
	 * �J�e�S�����
	 */
	private ArrayList<CategoryEntity> categoryData;
	private LinkedHashMap<String, String> payTypeMap;// �x�������@���X�g
	private LinkedHashMap<String, String> sendTypeMap;// �������@���X�g
	private LinkedHashMap<String, String> dlvTimeRng;// �z�B���ԑу��X�g
	private CreateOderId crtOderId;// �����ԍ��擾

	/**
	 * @return the crtOderId
	 */
	public CreateOderId getCrtOderId() {
		if (crtOderId==null){
			crtOderId=new CreateOderId(createDao());
		}
		return crtOderId;
	}

	/**
	 * @param crtOderId
	 *            the crtOderId to set
	 */
	public void setCrtOderId(CreateOderId crtOderId) {
		this.crtOderId = crtOderId;
	}

	/**
	 * @return the categoryData
	 */
	public ArrayList<CategoryEntity> getCategoryData() {
		return categoryData;
	}

	/**
	 * @param categoryData
	 *            the categoryData to set
	 */
	public void setCategoryData(ArrayList<CategoryEntity> categoryData) {
		this.categoryData = categoryData;
	}

	/**
	 * @return the payTypeMap
	 */
	public LinkedHashMap<String, String> getPayTypeMap() {
		return payTypeMap;
	}

	/**
	 * @param payTypeMap
	 *            the payTypeMap to set
	 */
	public void setPayTypeMap(LinkedHashMap<String, String> payTypeMap) {
		this.payTypeMap = payTypeMap;
	}

	/**
	 * @return the sendTypeMap
	 */
	public LinkedHashMap<String, String> getSendTypeMap() {
		return sendTypeMap;
	}

	/**
	 * @param sendTypeMap
	 *            the sendTypeMap to set
	 */
	public void setSendTypeMap(LinkedHashMap<String, String> sendTypeMap) {
		this.sendTypeMap = sendTypeMap;
	}

	/**
	 * @return the dlvTimeRng
	 */
	public LinkedHashMap<String, String> getDlvTimeRng() {
		return dlvTimeRng;
	}

	/**
	 * @param dlvTimeRng
	 *            the dlvTimeRng to set
	 */
	public void setDlvTimeRng(LinkedHashMap<String, String> dlvTimeRng) {
		this.dlvTimeRng = dlvTimeRng;
	}
	


}
