package ja.co.amaraimusi.sa;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jp.co.amaraimusi.IDao;

/**
 * @author K_UEHARA
 * �J�e�S�������擾����
 *
 */
public class GetCategoryData {
	/**
	 * �f�[�^�x�[�X�A�N�Z�X�I�u�W�F�N�g
	 */
	private IDao dao;
	/**
	 * @param dao
	 * DAO���v���p�e�B�ɃZ�b�g����B
	 */
	public GetCategoryData(IDao dao){
		this.dao=dao;
	}
	/**
	 * �J�e�S������DB����擾����B
	 * @return the sideMenuData
	 */
	public ArrayList<CategoryEntity> getCategoryData() {
		ArrayList<CategoryEntity> categoryData=new ArrayList<CategoryEntity>();
		dao.open();
		
		String query="SELECT category1tbl.Id AS c1Id, category1tbl.Name AS c1Name, "+
			" category2tbl.Id AS c2Id, category2tbl.Name AS c2Name" +
			" FROM category1tbl INNER JOIN category2tbl ON category1tbl.Id = category2tbl.Category1Id" +
			" ORDER BY category1tbl.Id,category2tbl.Id";
		ResultSet rs=dao.executeQuery(query);
		
		try {
			int id1=-1;

			CategoryEntity ent=null;
			ArrayList<Category2Entity> c2List=null;
			while(rs.next()){
				int id= rs.getInt("c1Id");
				if (id1 != id){
					ent = new CategoryEntity();
					id1=id;
					ent.setCategory1Id(id1);
					ent.setCategory1Name(rs.getString("c1Name"));
					c2List = new ArrayList<Category2Entity>();
					ent.setCategory2List(c2List);
					categoryData.add(ent);
				}
				c2List=ent.getCategory2List();
				Category2Entity ent2=new Category2Entity();
				ent2.setId(rs.getInt("c2Id"));
				ent2.setName(rs.getString("c2Name"));
				c2List.add(ent2);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.close();
		
		return categoryData;
	}

}
