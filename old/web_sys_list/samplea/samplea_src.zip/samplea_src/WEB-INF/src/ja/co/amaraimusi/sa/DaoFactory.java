package ja.co.amaraimusi.sa;

import jp.co.amaraimusi.DaoForMySQL;
import jp.co.amaraimusi.IDao;

public class DaoFactory {
	public static IDao getDao(){
		IDao dao = new DaoForMySQL("sample_a","root","neko");
		return dao;
	}
}
