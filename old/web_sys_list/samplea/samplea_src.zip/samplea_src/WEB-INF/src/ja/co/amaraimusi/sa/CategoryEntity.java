package ja.co.amaraimusi.sa;

import java.util.ArrayList;

public class CategoryEntity {
	
	/**
	 * @return the category1Id
	 */
	public int getCategory1Id() {
		return category1Id;
	}
	/**
	 * @param category1Id the category1Id to set
	 */
	public void setCategory1Id(int category1Id) {
		this.category1Id = category1Id;
	}
	/**
	 * @return the category1Name
	 */
	public String getCategory1Name() {
		return category1Name;
	}
	/**
	 * @param category1Name the category1Name to set
	 */
	public void setCategory1Name(String category1Name) {
		this.category1Name = category1Name;
	}
	/**
	 * @return the category2List
	 */
	public ArrayList<Category2Entity> getCategory2List() {
		return category2List;
	}
	/**
	 * @param category2List the category2List to set
	 */
	public void setCategory2List(ArrayList<Category2Entity> category2List) {
		this.category2List = category2List;
	}
	/**
	 * �J�e�S���PID
	 */
	private int category1Id;
	/**
	 * �J�e�S���P����
	 */
	private String category1Name;
	/**
	 * �J�e�S���Q���X�g
	 */
	private ArrayList<Category2Entity> category2List;
	
}
