package ja.co.amaraimusi.sa;

import java.math.BigDecimal;

/**
 * @author K_UEHARA
 *�J�[�g�����i�G���e�B�e�B
 */
public class CartItemEntity { 
	private int itemId;
	private String itemName;
	private BigDecimal kakaku;
	private BigDecimal totalValue;
	private int buyCount;
	private boolean delFlg;
	

	/**
	 * @return the delFlg
	 */
	public boolean getDelFlg() {
		return delFlg;
	}
	/**
	 * @param delFlg the delFlg to set
	 */
	public void setDelFlg(boolean delFlg) {
		this.delFlg = delFlg;
	}
	/**
	 * @return the itemId
	 */
	public int getItemId() {
		return itemId;
	}
	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}
	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	/**
	 * @return the kakaku
	 */
	public BigDecimal getKakaku() {
		return kakaku;
	}
	/**
	 * @param kakaku the kakaku to set
	 */
	public void setKakaku(BigDecimal kakaku) {
		this.kakaku = kakaku;
	}
	/**
	 * @return the totalValue
	 */
	public BigDecimal getTotalValue() {
		return totalValue;
	}
	/**
	 * @param totalValue the totalValue to set
	 */
	public void setTotalValue(BigDecimal totalValue) {
		this.totalValue = totalValue;
	}
	/**
	 * @return the buyCount
	 */
	public int getBuyCount() {
		return buyCount;
	}
	/**
	 * @param buyCount the buyCount to set
	 */
	public void setBuyCount(int buyCount) {
		this.buyCount = buyCount;
	}


}
