package ja.co.amaraimusi.sa;

import java.math.BigDecimal;

public class ItemEntity {
	public int Id;    //�h�c
	public String Category1;    //�J�e�S���P
	public String Category2;    //�J�e�S���Q
	public String ItemName;    //���i��
	public BigDecimal Kakaku;    //���i
	public String Image;    //�摜�t�@�C����
	public String Comment;    //�����
	
	/**
	 * @return the id
	 */
	public int getId() {
		return Id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		Id = id;
	}
	/**
	 * @return the category1
	 */
	public String getCategory1() {
		return Category1;
	}
	/**
	 * @param category1 the category1 to set
	 */
	public void setCategory1(String category1) {
		Category1 = category1;
	}
	/**
	 * @return the category2
	 */
	public String getCategory2() {
		return Category2;
	}
	/**
	 * @param category2 the category2 to set
	 */
	public void setCategory2(String category2) {
		Category2 = category2;
	}
	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return ItemName;
	}
	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		ItemName = itemName;
	}
	/**
	 * @return the kakaku
	 */
	public BigDecimal getKakaku() {
		return Kakaku;
	}
	/**
	 * @param kakaku the kakaku to set
	 */
	public void setKakaku(BigDecimal kakaku) {
		Kakaku = kakaku;
	}
	/**
	 * @return the image
	 */
	public String getImage() {
		return Image;
	}
	/**
	 * @param image the image to set
	 */
	public void setImage(String image) {
		Image = image;
	}
	/**
	 * @return the comment
	 */
	public String getComment() {
		return Comment;
	}
	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		Comment = comment;
	}

}
