
package form;
import ja.co.amaraimusi.sa.CategoryEntity;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

/**
* HelloForm.java
*/
public class OpenPublicForm extends ActionForm {


    /**
	 * 
	 */
	private static final long serialVersionUID =3;
	
	/**
	 * �J�e�S�����
	 */
	public ArrayList<CategoryEntity> categoryData;
	
	/**
	 * @return the categoryData
	 */
	public ArrayList<CategoryEntity> getCategoryData() {
		return categoryData;
	}


	/**
	 * @param categoryData the categoryData to set
	 */
	public void setCategoryData(ArrayList<CategoryEntity> categoryData) {
		this.categoryData = categoryData;
	}



	

	









}
