package form;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 * InpAddressForm.java
 */
public class InpAddressForm extends ActionForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4610683053059785196L;

	private String namae;// ���O
	private String furigana;// �t���K�i
	private String yubin;// �X�֔ԍ�
	private String address;// �Z��
	private String tell;// �d�b�ԍ�
	private String mailAddress;// ���[���A�h���X
	private int payType;// �x�������@
	private int sendType;// �������@
	private String deliveryWishDay;// �z�B��]��
	private int deliveryTimeRange;// �z�B���ԑ�
	private String comment;// �R�����g
	private String payTypeStr;// �x�������@�E������
	private String sendTypeStr;// �������@�E������
	private String dlvTimeRngStr;// �z�B���ԑсE������
	private BigDecimal itemsValue;// ���i��
	private int oderId;// ����ID

	private LinkedHashMap<String, String> payTypeMap; // �x�������@�Z���N�g�{�b�N�X���
	private LinkedHashMap<String, String> sendTypeMap; // �������@�Z���N�g�{�b�N�X���
	private LinkedHashMap<String, String> dlvTimeRngMap;// �z�B���ԑуZ���N�g�{�b�N�X���

	/**
	 * @return the namae
	 */
	public String getNamae() {
		return namae;
	}

	/**
	 * @param namae
	 *            the namae to set
	 */
	public void setNamae(String namae) {
		this.namae = namae;
	}

	/**
	 * @return the furigana
	 */
	public String getFurigana() {
		return furigana;
	}

	/**
	 * @param furigana
	 *            the furigana to set
	 */
	public void setFurigana(String furigana) {
		this.furigana = furigana;
	}

	/**
	 * @return the yubinNo
	 */
	public String getYubin() {
		return yubin;
	}

	/**
	 * @param yubinNo
	 *            the yubinNo to set
	 */
	public void setYubin(String yubin) {
		this.yubin = yubin;
	}

	/**
	 * @return the todohuken
	 */

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the tell
	 */
	public String getTell() {
		return tell;
	}

	/**
	 * @param tell
	 *            the tell to set
	 */
	public void setTell(String tell) {
		this.tell = tell;
	}

	/**
	 * @return the mailAddress
	 */
	public String getMailAddress() {
		return mailAddress;
	}

	/**
	 * @param mailAddress
	 *            the mailAddress to set
	 */
	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

	/**
	 * @return the payType
	 */
	public int getPayType() {
		return payType;
	}

	/**
	 * @param payType
	 *            the payType to set
	 */
	public void setPayType(int payType) {
		this.payType = payType;
	}

	/**
	 * @return the sendType
	 */
	public int getSendType() {
		return sendType;
	}

	/**
	 * @param sendType
	 *            the sendType to set
	 */
	public void setSendType(int sendType) {
		this.sendType = sendType;
	}

	/**
	 * @return the deliveryWishDay
	 */
	public String getDeliveryWishDay() {
		return deliveryWishDay;
	}

	/**
	 * @param deliveryWishDay
	 *            the deliveryWishDay to set
	 */
	public void setDeliveryWishDay(String deliveryWishDay) {
		this.deliveryWishDay = deliveryWishDay;
	}

	/**
	 * @return the deliveryTimeRange
	 */
	public int getDeliveryTimeRange() {
		return deliveryTimeRange;
	}

	/**
	 * @param deliveryTimeRange
	 *            the deliveryTimeRange to set
	 */
	public void setDeliveryTimeRange(int deliveryTimeRange) {
		this.deliveryTimeRange = deliveryTimeRange;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment
	 *            the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the payTypeMap
	 */
	public LinkedHashMap<String, String> getPayTypeMap() {
		return payTypeMap;
	}

	/**
	 * @param payTypeMap
	 *            the payTypeMap to set
	 */
	public void setPayTypeMap(LinkedHashMap<String, String> payTypeMap) {
		this.payTypeMap = payTypeMap;
	}

	/**
	 * @return the sendTypeMap
	 */
	public LinkedHashMap<String, String> getSendTypeMap() {
		return sendTypeMap;
	}

	/**
	 * @param sendTypeMap
	 *            the sendTypeMap to set
	 */
	public void setSendTypeMap(LinkedHashMap<String, String> sendTypeMap) {
		this.sendTypeMap = sendTypeMap;
	}

	/**
	 * @return the dlvTimeRngMap
	 */
	public LinkedHashMap<String, String> getDlvTimeRngMap() {
		return dlvTimeRngMap;
	}

	/**
	 * @param dlvTimeRngMap
	 *            the dlvTimeRngMap to set
	 */
	public void setDlvTimeRngMap(LinkedHashMap<String, String> dlvTimeRngMap) {
		this.dlvTimeRngMap = dlvTimeRngMap;
	}

	/**
	 * @return the payTypeStr
	 */
	public String getPayTypeStr() {
		return payTypeStr;
	}

	/**
	 * @param payTypeStr
	 *            the payTypeStr to set
	 */
	public void setPayTypeStr(String payTypeStr) {
		this.payTypeStr = payTypeStr;
	}

	/**
	 * @return the sendTypeStr
	 */
	public String getSendTypeStr() {
		return sendTypeStr;
	}

	/**
	 * @param sendTypeStr
	 *            the sendTypeStr to set
	 */
	public void setSendTypeStr(String sendTypeStr) {
		this.sendTypeStr = sendTypeStr;
	}

	/**
	 * @return the dlvTimeRngStr
	 */
	public String getDlvTimeRngStr() {
		return dlvTimeRngStr;
	}

	/**
	 * @param dlvTimeRngStr
	 *            the dlvTimeRngStr to set
	 */
	public void setDlvTimeRngStr(String dlvTimeRngStr) {
		this.dlvTimeRngStr = dlvTimeRngStr;
	}

	/**
	 * @return the itemsValue
	 */
	public BigDecimal getItemsValue() {
		return itemsValue;
	}

	/**
	 * @param itemsValue
	 *            the itemsValue to set
	 */
	public void setItemsValue(BigDecimal itemsValue) {
		this.itemsValue = itemsValue;
	}

	/**
	 * @return the oderId
	 */
	public int getOderId() {
		return oderId;
	}

	/**
	 * @param oderId
	 *            the oderId to set
	 */
	public void setOderId(int oderId) {
		this.oderId = oderId;
	}

	@Override
	public ActionErrors validate(ActionMapping map, HttpServletRequest req) {

		// �G���[���X�g
		ActionErrors errs = new ActionErrors();

		System.out.println("������InpAddressForm�G���[�`�F�b�N");

		// �����O�̓��̓`�F�b�N�B�������`�F�b�N�E�K�{���̓`�F�b�N
		namae = namae.trim();
		if (namae.length() > 50) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "�����O",
					"50");
			errs.add("namae", errr);
		}
		if (namae.length() == 0) {
			ActionMessage errr = new ActionMessage("errors.required", "�����O");
			errs.add("namae", errr);
		}

		// �ӂ肪�ȓ��̓`�F�b�N�B�������`�F�b�N
		furigana = furigana.trim();
		if (furigana.length() > 50) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "�ӂ肪��",
					"50");
			errs.add("furigana", errr);
		}

		// �X�֔ԍ��̓��̓`�F�b�N�B�������`�F�b�N�E�K�{���̓`�F�b�N
		yubin = yubin.trim();
		if (yubin.length() > 8) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "�X�֔ԍ�",
					"8");
			errs.add("yubin", errr);
		}
		if (yubin.length() == 0) {
			ActionMessage errr = new ActionMessage("errors.required", "�X�֔ԍ�");
			errs.add("yubin", errr);
		}

		// �Z���̓��̓`�F�b�N�B�������`�F�b�N�E�K�{���̓`�F�b�N
		address = address.trim();
		if (address.length() > 100) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "�Z��",
					"100");
			errs.add("address", errr);
		}
		if (address.length() == 0) {
			ActionMessage errr = new ActionMessage("errors.required", "�Z��");
			errs.add("address", errr);
		}

		// �d�b�ԍ��̓��̓`�F�b�N�B�������`�F�b�N�E�K�{���̓`�F�b�N
		tell = tell.trim();
		if (tell.length() > 32) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "�d�b�ԍ�",
					"32");
			errs.add("tell", errr);
		}
		if (tell.length() == 0) {
			ActionMessage errr = new ActionMessage("errors.required", "�d�b�ԍ�");
			errs.add("tell", errr);
		}

		// ���[���A�h���X�̓��̓`�F�b�N�B�������`�F�b�N�E�K�{���̓`�F�b�N
		mailAddress = mailAddress.trim();
		if (mailAddress.length() > 50) {
			ActionMessage errr = new ActionMessage("errors.maxlength",
					"���[���A�h���X", "50");
			errs.add("mailAddress", errr);
		}
		if (mailAddress.length() == 0) {
			ActionMessage errr = new ActionMessage("errors.required", "���[���A�h���X");
			errs.add("mailAddress", errr);
		}

		// �z�B��]���̓��̓`�F�b�N�B�������`�F�b�N
		deliveryWishDay = deliveryWishDay.trim();
		if (deliveryWishDay.length() > 16) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "�z�B��]��",
					"16");
			errs.add("deliveryWishDay", errr);
		}

		// ���l���̓��̓`�F�b�N�B�������`�F�b�N�E�K�{���̓`�F�b�N
		comment = comment.trim();
		if (comment.length() > 200) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "���l��",
					"200");
			errs.add("comment", errr);
		}

		return errs;

	}

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}
