
package form;
import org.apache.struts.action.ActionForm;

/**
* HelloForm.java
*/
public class InpTypeForm extends ActionForm {


	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7726225581793587413L;

	/**
	 * ���͕��@
	 */
	private String inpType;

	/**
	 * @return the inpType
	 */
	public String getInpType() {
		return inpType;
	}

	/**
	 * @param inpType the inpType to set
	 */
	public void setInpType(String inpType) {
		this.inpType = inpType;
	}
	





}
