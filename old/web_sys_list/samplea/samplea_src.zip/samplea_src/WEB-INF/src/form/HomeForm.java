
package form;
import ja.co.amaraimusi.sa.BuySellEntity;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
* HelloForm.java
*/
public class HomeForm extends OpenPublicForm {


	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5576380739286218916L;
	/**
	 * �V���i���X�g
	 */
	private ArrayList<BuySellEntity> newItemList;



	
	/**
	 * @return the newItemList
	 */
	public ArrayList<BuySellEntity> getNewItemList() {
		return newItemList;
	}

	/**
	 * @param newItemList the newItemList to set
	 */
	public void setNewItemList(ArrayList<BuySellEntity> newItemList) {
		this.newItemList = newItemList;
	}





	@Override
	public ActionErrors validate(
			ActionMapping map,
			HttpServletRequest req){

		//�G���[���X�g
		ActionErrors errs=new ActionErrors();
		if (newItemList != null){
			for(BuySellEntity ent :newItemList){
				//�J�[�g�������͈̔͒l�`�F�b�N
				if(ent.inItemCount < 0 | ent.inItemCount > 999){
					ActionMessage errr=new ActionMessage("errors.range","��","0","999");
					errs.add("buyCountErr",errr);
				}
			}
		}
		


		
		return errs;
		
	}
	

	









}
