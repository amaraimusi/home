
package form;
import ja.co.amaraimusi.sa.CartItemEntity;
import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

/**
* HelloForm.java
*/
public class LookCartForm extends ActionForm {


	private static final long serialVersionUID = 5L;
	
	/**
	 * ���v
	 */
	private int smallTotal;
	
	/**
	 * �X�V�{�^���l
	 */
	private String updateBtn;

	/**
	 * �J�[�g�����i���X�g
	 */
	private ArrayList<CartItemEntity> cartItemList;
	
	/**
	 * �y�[�W�J�E���^�y�u���E�U�X�V�A2�d�����΍�z
	 */
	private int pageCounter=0;
	
	


	/**
	 * @return the pageCounter
	 */
	public int getPageCounter() {
		return pageCounter;
	}

	/**
	 * @param pageCounter the pageCounter to set
	 */
	public void setPageCounter(int pageCounter) {
		this.pageCounter = pageCounter;
	}

	/**
	 * @return the cartItemList
	 */
	public ArrayList<CartItemEntity> getCartItemList() {
		return cartItemList;
	}

	/**
	 * @param cartItemList the cartItemList to set
	 */
	public void setCartItemList(ArrayList<CartItemEntity> cartItemList) {
		this.cartItemList = cartItemList;
	}

	/**
	 * @return the updateBtn
	 */
	public String getUpdateBtn() {
		return updateBtn;
	}
	/**
	 * @param updateBtn the updateBtn to set
	 */
	public void setUpdateBtn(String updateBtn) {
		this.updateBtn = updateBtn;
	}
	/**
	 * @return the smallTotal
	 */
	public int getSmallTotal() {
		return smallTotal;
	}
	/**
	 * @param smallTotal the smallTotal to set
	 */
	public void setSmallTotal(int smallTotal) {
		this.smallTotal = smallTotal;
	}






}
