
package form;
import ja.co.amaraimusi.sa.BuySellEntity;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
* HelloForm.java
*/
public class ItemListForm extends OpenPublicForm {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * �V���i���X�g
	 */
	private ArrayList<BuySellEntity> itemList;





	/**
	 * �J�e�S���P
	 */
	private int category1;
	
	/**
	 * �J�e�S���Q
	 */
	private int category2;
	
	/**
	 * @return the itemList
	 */
	public ArrayList<BuySellEntity> getItemList() {
		return itemList;
	}

	/**
	 * @param itemList the itemList to set
	 */
	public void setItemList(ArrayList<BuySellEntity> itemList) {
		this.itemList = itemList;
	}


	/**
	 * @return the category1
	 */
	public int getCategory1() {
		return category1;
	}

	/**
	 * @param category1 the category1 to set
	 */
	public void setCategory1(int category1) {
		this.category1 = category1;
	}

	/**
	 * @return the category2
	 */
	public int getCategory2() {
		return category2;
	}

	/**
	 * @param category2 the category2 to set
	 */
	public void setCategory2(int category2) {
		this.category2 = category2;
	}


	@Override
	public ActionErrors validate(
			ActionMapping map,
			HttpServletRequest req){

		//�G���[���X�g
		ActionErrors errs=new ActionErrors();
		if (itemList != null){
			for(BuySellEntity ent :itemList){
				//�J�[�g�������͈̔͒l�`�F�b�N
				if(ent.inItemCount < 0 | ent.inItemCount > 999){
					ActionMessage errr=new ActionMessage("errors.range","��","0","999");
					errs.add("buyCountErr",errr);
				}
			}
		}
		


		
		return errs;
		
	}



}
