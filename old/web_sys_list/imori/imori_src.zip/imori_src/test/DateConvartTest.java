import java.text.SimpleDateFormat;
import java.util.Date;


public class DateConvartTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Date now =new Date();
		System.out.println(now);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String newInputDateStr=sdf.format(now);
		System.out.println(newInputDateStr);

	}

}
