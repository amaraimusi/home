package jp.co.amaraimusi.imori;

import junit.framework.TestCase;

public class GetStaffEntityTest extends TestCase {

	public void testGetEnt() {
		GetStaffEntity test =new GetStaffEntity();
		StaffEntity ent = test.getEnt(1000);
		System.out.println(ent.getName());
	}

}
