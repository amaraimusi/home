package jp.co.amaraimusi.imori;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.TestCase;

public class GetReportEntityTest extends TestCase {

	public void testGetList() {
		int id=1000;
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd");
		Date reportDate=null;
		try {
			reportDate = sdf.parse("2009/08/02 09:18:38");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		GetReportEntity test =new GetReportEntity();
		ReportEntity ent=test.getEnt(id, reportDate);
		System.out.println(ent.getReport());
	}

}
