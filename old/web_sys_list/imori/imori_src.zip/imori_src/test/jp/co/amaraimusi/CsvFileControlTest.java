package jp.co.amaraimusi;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import junit.framework.TestCase;

public class CsvFileControlTest extends TestCase {
	public void testMain(){
		CsvFileControl test=new CsvFileControl();
		ArrayList<HashMap<String,String>> ls=test.readCsvFileData("C:\\web\\Java\\workspace\\Kaeru\\����\\DB�T���v���f�[�^.csv");
		
		System.out.println("�e�X�g����");
		for (HashMap<String,String >  map:ls){
			Set<String> keys=map.keySet();
			StringBuffer sb=new StringBuffer();
			for(String key:keys){
				sb.append("��");
				sb.append( map.get(key).toString());
				
			}
			System.out.println(sb.toString());
		}
	}
}
