package jp.co.amaraimusi;

import java.util.ArrayList;

import junit.framework.TestCase;

public class InputCheckTest extends TestCase {
	
	public void testIsNumeric() {
		InputCheck test=getTestObj();
		ArrayList<String> ls=getTestStrList();
		for (String testStr:ls){
			isNumericExc(test, testStr);
		}
		
	}

	private void isNumericExc(InputCheck test, String str) {
		String testName ="���l�`�F�b�N�F";
		if(test.isNumeric(str)){
			System.out.println(testName+str + ":OK");
		}else{
			System.out.println(testName+str + ":FALSE");
			
		}
	}
	public void testIsHankakuAlfNum1() {
		InputCheck test=getTestObj();
		ArrayList<String> ls=getTestStrList();
		for (String testStr:ls){
			isHankakuAlfNum1Exc(test, testStr);
		}
	}

	private void isHankakuAlfNum1Exc(InputCheck test, String testStr) {
		
		String testName ="���p�p�����P�`�F�b�N�F";
		if(test.isHankakuAlfNum1(testStr)){
			System.out.println(testName+testStr + ":OK");
		}else{
			System.out.println(testName+testStr + ":FALSE");
			
		}
	}


	public void testIsHankakuAlfNum2() {
		InputCheck test=getTestObj();
		ArrayList<String> ls=getTestStrList();
		for (String testStr:ls){
			isHankakuAlfNum2Exc(test, testStr);
		}
	}

	private void isHankakuAlfNum2Exc(InputCheck test, String testStr) {
		
		String testName ="���p�p����2�`�F�b�N�F";
		if(test.isHankakuAlfNum2(testStr)){
			System.out.println(testName+testStr + ":OK");
		}else{
			System.out.println(testName+testStr + ":FALSE");
			
		}
	}


	public void testIsHankakuAlfNum3() {
		InputCheck test=getTestObj();
		ArrayList<String> ls=getTestStrList();
		for (String testStr:ls){
			isHankakuAlfNum3Exc(test, testStr);
		}
	}

	private void isHankakuAlfNum3Exc(InputCheck test, String testStr) {
	
		String testName ="���p�p����3�`�F�b�N�F";
		if(test.isHankakuAlfNum3(testStr)){
			System.out.println(testName+testStr + ":OK");
		}else{
			System.out.println(testName+testStr + ":FALSE");
			
		}
	}


	public void testIsZenkakuKatakana() {
		InputCheck test=getTestObj();
		ArrayList<String> ls=getTestStrList();
		for (String testStr:ls){
			isZenkakuKatakanaExc(test, testStr);
		}
	}

	private void isZenkakuKatakanaExc(InputCheck test, String testStr) {
	
		String testName ="�S�p�J�^�J�i�`�F�b�N�F";
		if(test.isZenkakuKatakana(testStr)){
			System.out.println(testName+testStr + ":OK");
		}else{
			System.out.println(testName+testStr + ":FALSE");
			
		}
	}


	public void testIsZenkakuKatakana2() {
		InputCheck test=getTestObj();
		ArrayList<String> ls=getTestStrList();
		for (String testStr:ls){
			isZenkakuKatakana2(test, testStr);
		}
	}


	private void isZenkakuKatakana2(InputCheck test, String testStr) {
		
		String testName ="�S�p�J�^�J�i2�`�F�b�N�F";
		if(test.isZenkakuKatakana2(testStr)){
			System.out.println(testName+testStr + ":OK");
		}else{
			System.out.println(testName+testStr + ":FALSE");
			
		}
	}


	public void testIsMailaddress() {
		InputCheck test=getTestObj();
		ArrayList<String> ls=getTestStrList();
		for (String testStr:ls){
			isMailAddressExc(test, testStr);
		}
	}


	private void isMailAddressExc(InputCheck test, String testStr) {
		
		String testName ="���[���A�h���X�`�F�b�N�F";
		if(test.isMailaddress(testStr)){
			System.out.println(testName+testStr + ":OK");
		}else{
			System.out.println(testName+testStr + ":FALSE");
			
		}
	}
	
	private InputCheck getTestObj(){
		return new InputCheck();
	}
	
	private ArrayList<String> getTestStrList(){
		ArrayList<String> ls=new ArrayList<String>();
		ls.add("0123456789");
		ls.add("�O�P�Q�R�S�T�U�V�W�X");
		ls.add("abcdefghijklmnopqrstuvwxyz");
		ls.add("ABCDEFGHIJKLMNOPQRSTUVWXYG");
		ls.add("ABCDEFGHIJKID");
		ls.add("ab123");
		ls.add("ad 123a ");
		ls.add("����123");
		ls.add("-_asd");
		ls.add("�I�[�l�R");
		ls.add("���[�˂�");
		ls.add("mail@neko.co.jp");
		ls.add("@a");
		ls.add(" @ ");
		ls.add("a@");
		return ls;
 	}
}
