package jp.co.amaraimusi.imori;

import java.util.LinkedHashMap;
import java.util.Set;

import junit.framework.TestCase;

public class GetTodohukenMapTest extends TestCase {

	public void testGetMap() {
		GetTodohukenMap test =new GetTodohukenMap();
		LinkedHashMap<String, String> map=test.getMap();
		Set<String> keys =map.keySet();
		for(String key:keys){
			System.out.println(key + "," + map.get(key));
		}
	}

}
