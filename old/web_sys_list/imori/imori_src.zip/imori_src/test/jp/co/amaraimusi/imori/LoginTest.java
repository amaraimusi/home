package jp.co.amaraimusi.imori;

import junit.framework.TestCase;

public class LoginTest extends TestCase {

	public void testLogin() {
		Login test=new Login();
		int result=test.login("1000", "ryukyuyamagame");
		System.out.println(result);
		result=test.login("1000", "dummy");
		System.out.println(result);
		result=test.login("1000", "dummy");
		System.out.println(result);
		result=test.login("1000", "dummy");
		System.out.println(result);
		result=test.login("1000", "dummy");
		System.out.println(result);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		result=test.login("1000", "ryukyuyamagame");
		System.out.println(result);
		
	}

}
