package jp.co.amaraimusi.imori;

import java.util.Date;

import junit.framework.TestCase;

public class InsertReportEntityTest extends TestCase {

	public void testInsertEnt()  {

		Date inpDate=new Date();
		ReportEntity ent =new ReportEntity();
		ent.setStaffId(1000);
		ent.setReportDate(inpDate);
		ent.setReport("�T���v�����|�[�g");
		ent.setBossCheck(0);
		ent.setNewInputDateTime(inpDate);
		ent.setLastInputDateTime(inpDate);
		
		InsertReportEntity test =new InsertReportEntity();
		try {
			test.insertEnt(ent);
		} catch (Exception e) {
			fail("�X�V���s");
			e.printStackTrace();
		}
		
	}

}
