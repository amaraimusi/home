package jp.co.amaraimusi.imori;

import java.util.Date;

import junit.framework.TestCase;

public class UpdateReportEntityTest extends TestCase {

	public void testUpdateEnt() {
		Date inpDate=new Date();
		ReportEntity ent =new ReportEntity();
		ent.setStaffId(1000);
		ent.setReportDate(inpDate);
		ent.setReport("�T���v�����|�[�g6");
		ent.setBossCheck(0);
		ent.setNewInputDateTime(inpDate);
		ent.setLastInputDateTime(inpDate);
		
		UpdateReportEntity test =new UpdateReportEntity();
		try {
			test.updateEnt(ent);
		} catch (Exception e) {
			fail("�X�V���s");
			e.printStackTrace();
		}
	}

}
