package jp.co.amaraimusi.imori;

import java.util.ArrayList;

import junit.framework.TestCase;

public class GetReportEntityListTest extends TestCase {

	public void testGetList() {
		int id=1000;
		GetReportEntityList test =new GetReportEntityList();
		ArrayList<ReportEntity> ls=test.getList(id);
		for(ReportEntity ent:ls){
			System.out.println(ent.getReportDate()+ " " + ent.getMidasi());
		}
	}

}
