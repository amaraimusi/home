package jp.co.amaraimusi.imori;

import java.util.ArrayList;

import junit.framework.TestCase;

public class GetStaffEntityListTest extends TestCase {

	public void testGetList() {
		GetStaffEntityList test =new GetStaffEntityList();
		ArrayList<StaffEntity> ls=test.getList();
		for(StaffEntity ent:ls){
			System.out.println(ent.getName());
		}
	}

}
