
public class CurrentTimeMillisTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		long tm = System.currentTimeMillis();
		System.out.println(tm);
	}

}
