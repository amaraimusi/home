import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;


public class HidukeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		Date now =new Date();
//		System.out.println(now);
//		System.out.println(now.toString());
//		
//		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
//		System.out.println(sdf.format(now));
		
		
		String str="2009/08/26" ;
		//SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		DateFormat df = DateFormat.getDateInstance();
		Date d;
		try {
			d = df.parse(str);
			System.out.println(d);
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
	}

}
