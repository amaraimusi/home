package form;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import jp.co.amaraimusi.InputCheck;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class ReportInpForm extends ActionForm {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private String inpDateStr;//���͓��t������
	private String report;//���|�[�g
	private String bossReport;//��i���|�[�g



	/**
	 * @return the inpDateStr
	 */
	public String getInpDateStr() {
		return inpDateStr;
	}

	/**
	 * @param inpDateStr the inpDateStr to set
	 */
	public void setInpDateStr(String inpDateStr) {
		this.inpDateStr = inpDateStr;
	}

	/**
	 * @return the report
	 */
	public String getReport() {
		return report;
	}

	/**
	 * @param report the report to set
	 */
	public void setReport(String report) {
		this.report = report;
	}

	/**
	 * @return the bossReport
	 */
	public String getBossReport() {
		return bossReport;
	}

	/**
	 * @param bossReport the bossReport to set
	 */
	public void setBossReport(String bossReport) {
		this.bossReport = bossReport;
	}
	
	
	/* (non-Javadoc)
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public ActionErrors validate(ActionMapping map, HttpServletRequest req){
		// �G���[���X�g
		ActionErrors errs = new ActionErrors();
		InputCheck ic =new InputCheck();
		checkInpDateStr(errs, ic);//���͓��t�̃`�F�b�N
		checkReport(errs, ic);//�����̓��̓`�F�b�N
		checkBossReport(errs, ic);//��i�R�����g�̓��̓`�F�b�N
		return errs;
	}
	
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {

		// ���{����͂ɑΉ�������
		try {

			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
	private void checkInpDateStr(ActionErrors errs, InputCheck ic) {
		
		
		int len=inpDateStr.length();
		inpDateStr = inpDateStr.replaceAll("[ �@]", "");//���p�X�y�[�X�ƑS�p�X�y�[�X����菜���B

		
		
		//�K�{���̓`�F�b�N
		if (len==0){
			ActionMessage errr = new ActionMessage("errors.required", "���͓��t");
			errs.add("inpDateStr_required", errr);
		}
		
		//���t�`�F�b�N
		if(ic.isDate(inpDateStr)==false){
			ActionMessage errr = new ActionMessage("errors.date", "���͓��t");
			errs.add("inpDateStr_date", errr);
			
		}
	}
	private void checkReport(ActionErrors errs, InputCheck ic) {
		
		int len=report.length();
		if(len>7500){
			ActionMessage errr = new ActionMessage("errors.maxlength", "����","7500");
			errs.add("report_maxlenght", errr);
			
		}
	}
	private void checkBossReport(ActionErrors errs, InputCheck ic) {
		
		int len=bossReport.length();
		if(len>7500){
			ActionMessage errr = new ActionMessage("errors.maxlength", "��i�R�����g","7500");
			errs.add("bossReport_maxlenght", errr);
			
		}
	}
	
}
