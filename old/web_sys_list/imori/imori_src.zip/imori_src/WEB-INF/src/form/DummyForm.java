package form;

import org.apache.struts.action.ActionForm;

/**
 * 
 * @author K_UEHARA
 *
 */
public class DummyForm extends ActionForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	
}
