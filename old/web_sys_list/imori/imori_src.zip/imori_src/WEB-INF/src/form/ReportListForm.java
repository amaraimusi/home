package form;

import java.util.ArrayList;

import jp.co.amaraimusi.imori.ReportEntity;

import org.apache.struts.action.ActionForm;

/**
 * 
 * @author K_UEHARA
 *
 */
public class ReportListForm extends ActionForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int staffId;//�Ј�ID
	private String staffName;//�Ј���
	private ArrayList<ReportEntity> rpLs;//���񃊃X�g
	/**
	 * @return the staffId
	 */
	public int getStaffId() {
		return staffId;
	}
	/**
	 * @param staffId the staffId to set
	 */
	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}
	/**
	 * @return the staffName
	 */
	public String getStaffName() {
		return staffName;
	}
	/**
	 * @param staffName the staffName to set
	 */
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	/**
	 * @return the rpLs
	 */
	public ArrayList<ReportEntity> getRpLs() {
		return rpLs;
	}
	/**
	 * @param rpLs the rpLs to set
	 */
	public void setRpLs(ArrayList<ReportEntity> rpLs) {
		this.rpLs = rpLs;
	}

	
	
}
