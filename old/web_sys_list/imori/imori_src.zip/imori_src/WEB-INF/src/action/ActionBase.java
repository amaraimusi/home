package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.amaraimusi.imori.Cst;
import jp.co.amaraimusi.imori.StaffEntity;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * HelloAction.java
 */
public class ActionBase extends Action {

	
	Log log = LogFactory.getLog(ActionBase.class);

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		
		return null;
	}
	/**
	 * URL���͂Ȃǂɂ�钼�ڃA�N�Z�X���ꂽ�Ƃ��̑Ή��B
	 * ���ڃA�N�Z�X���ꂽ�ꍇ�A��O�𓊂���B
	 * @param request
	 * @throws Exception
	 */
	protected void checkDirectAccess(HttpServletRequest request) throws Exception {
		try {
			@SuppressWarnings("unused")
			StaffEntity ent=(StaffEntity) request.getAttribute(Cst.MYSELF);
		} catch (Exception e) {
			throw e;
		}
	}
	
	
}