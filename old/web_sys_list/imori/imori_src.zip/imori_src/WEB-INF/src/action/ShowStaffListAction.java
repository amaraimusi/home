package action;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.amaraimusi.imori.Cst;
import jp.co.amaraimusi.imori.GetStaffEntityList;
import jp.co.amaraimusi.imori.StaffEntity;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * 	�Ј��ꗗ��\��
 * 
 * @author K_UEHARA
 * 
 */
public class ShowStaffListAction extends ActionBase {

	

	Log log = LogFactory.getLog(ShowStaffListAction.class);


	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		log.fatal("�Ј��ꗗ��\������B" + request.getSession().getId());
		this.checkDirectAccess(request);//URL���͂Ȃǂɂ�钼�ڃA�N�Z�X���ꂽ�Ƃ��̑Ή�
		
		//�Ј����X�g�A�Ј��}�b�v���擾���A���N�G�X�g�ɃZ�b�g����B
		GetStaffEntityList gsfList=new GetStaffEntityList();
		ArrayList<StaffEntity> sfList = gsfList.getList();
		request.setAttribute(Cst.STAFF_LIST, sfList);
		HashMap<String,StaffEntity> map=gsfList.getStaffEntMap();
		request.setAttribute(Cst.STAFF_MAP, map);
		
	
		
		return mapping.findForward("success");
	}
	

}