package action;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.LoginForm;

/**
 * HelloAction.java
 */
public class StartAction extends Action {

	Log log = LogFactory.getLog(StartAction.class);
	
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		

		log.fatal("�X�^�[�g�����B���O�C����ʂɃA�N�Z�X���܂��B" + request.getSession().getId());
		
		//������������������������
		LoginForm fm=(LoginForm)form;
		fm.setId("1000");
		fm.setPass("ryukyuyamagame");
		return mapping.findForward("success");
	}



}