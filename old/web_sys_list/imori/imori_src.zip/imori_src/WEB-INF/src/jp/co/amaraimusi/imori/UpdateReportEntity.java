package jp.co.amaraimusi.imori;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class UpdateReportEntity {

	

	/**
	 * �����G���e�B�e�B��DB�̓����e�[�u���ɐV����B
	 * @param ent�@�����G���e�B�e�B
	 * @throws Exception 
	 * @throws SQLException 
	 */
	public void updateEnt(ReportEntity ent ) throws Exception {
		
		
		IDao dao = DaoFactory.getDao();
		
		dao.open();

		String query = getQuery(ent);
		
		try {
			dao.transactionStart();
			dao.executeUpdate(query);
			dao.commit();
		}catch(Exception e){
			dao.rollBack();
			throw e;
		} finally {
			dao.close();

		}
		
		
	}
	


	private String getQuery(ReportEntity ent ) {
		
		//��������yyyy-MM-dd HH:mm:ss�^�̕�����ɕϊ�����B
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM-dd");
		
		String id=String.valueOf(ent.getStaffId());
		String reportDateStr="'" + sdf2.format(ent.getReportDate()) + "'";
		String report=prcess1( ent.getReport() );
		String bossCheck =String.valueOf(ent.getBossCheck());
		String bossReport=prcess1( ent.getBossReport() );
		String lastInputDateStr="'" + sdf.format(ent.getLastInputDateTime())+ "'";
		String bossLastInputDateTimeStr="NULL";
		if (ent.getBossLastInputDateTime()!=null){
			bossLastInputDateTimeStr="'" + sdf.format(ent.getBossLastInputDateTime()) + "'";
		}
		
		String query =    
			   " UPDATE ReportTbl SET"+
			   "      report = " + report + ","+
			   "      BossCheck = " + bossCheck + ","+
			   "      BossReport = " + bossReport + ","+
			   "      LastInputDateTime = " + lastInputDateStr + ","+
			   "      BossLastInputDateTime = " + bossLastInputDateTimeStr + 
			   " WHERE"+
			   "     StaffId = " + id + 
			   "     AND"+
			   "     ReportDate = " + reportDateStr ;
			   
			
				System.out.println(query);
		return query;
	}

	private String prcess1(String s){
		String rtn="''";
		if (s!=null){
			rtn="'" + s + "'";
		}
		return rtn;
	}
	

}
