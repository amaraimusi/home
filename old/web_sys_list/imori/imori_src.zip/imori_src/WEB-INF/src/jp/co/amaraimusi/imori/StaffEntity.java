package jp.co.amaraimusi.imori;

import java.util.Date;

public class StaffEntity {
	private static final long serialVersionUID = 1L;
	private int id;    //�Ј�ID
	private String mngPos;    //��E
	private String name;    //���O
	private String kana;    //�t���K�i
	private String pass;    //�p�X���[�h
	private String postNo;    //�X�֔ԍ�
	private int todohuken;    //�s���{��
	private String address;    //�Z��
	private String address2;    //�Z���y�A�p�[�g�Ȃǁz
	private String mailAddress;    //���[���A�h���X
	private String tell;    //�d�b�ԍ�
	private int admin;    //�Ǘ��Ҍ���
	private Date newRegDateTime;    //�V�K�o�^����
	private Date lastRegDateTime;    //�ŏI�X�V����
	private int newRegStaffId;    //�V�K�o�^��ID
	private int lastRegStaffId;    //�ŏI�X�V�o�^��ID
	private int bossCheck;    //��i�m�F
	private String todohukenName;//�s���{����
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the mngPos
	 */
	public String getMngPos() {
		return mngPos;
	}
	/**
	 * @param mngPos the mngPos to set
	 */
	public void setMngPos(String mngPos) {
		this.mngPos = mngPos;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the kana
	 */
	public String getKana() {
		return kana;
	}
	/**
	 * @param kana the kana to set
	 */
	public void setKana(String kana) {
		this.kana = kana;
	}
	/**
	 * @return the pass
	 */
	public String getPass() {
		return pass;
	}
	/**
	 * @param pass the pass to set
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}
	/**
	 * @return the postNo
	 */
	public String getPostNo() {
		return postNo;
	}
	/**
	 * @param postNo the postNo to set
	 */
	public void setPostNo(String postNo) {
		this.postNo = postNo;
	}
	/**
	 * @return the todohuken
	 */
	public int getTodohuken() {
		return todohuken;
	}
	/**
	 * @param todohuken the todohuken to set
	 */
	public void setTodohuken(int todohuken) {
		this.todohuken = todohuken;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}
	/**
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	/**
	 * @return the mailAddress
	 */
	public String getMailAddress() {
		return mailAddress;
	}
	/**
	 * @param mailAddress the mailAddress to set
	 */
	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}
	/**
	 * @return the tell
	 */
	public String getTell() {
		return tell;
	}
	/**
	 * @param tell the tell to set
	 */
	public void setTell(String tell) {
		this.tell = tell;
	}
	/**
	 * @return the admin
	 */
	public int getAdmin() {
		return admin;
	}
	/**
	 * @param admin the admin to set
	 */
	public void setAdmin(int admin) {
		this.admin = admin;
	}
	/**
	 * @return the newRegDateTime
	 */
	public Date getNewRegDateTime() {
		return newRegDateTime;
	}
	/**
	 * @param newRegDateTime the newRegDateTime to set
	 */
	public void setNewRegDateTime(Date newRegDateTime) {
		this.newRegDateTime = newRegDateTime;
	}
	/**
	 * @return the lastRegDateTime
	 */
	public Date getLastRegDateTime() {
		return lastRegDateTime;
	}
	/**
	 * @param lastRegDateTime the lastRegDateTime to set
	 */
	public void setLastRegDateTime(Date lastRegDateTime) {
		this.lastRegDateTime = lastRegDateTime;
	}
	/**
	 * @return the newRegStaffId
	 */
	public int getNewRegStaffId() {
		return newRegStaffId;
	}
	/**
	 * @param newRegStaffId the newRegStaffId to set
	 */
	public void setNewRegStaffId(int newRegStaffId) {
		this.newRegStaffId = newRegStaffId;
	}
	/**
	 * @return the lastRegStaffId
	 */
	public int getLastRegStaffId() {
		return lastRegStaffId;
	}
	/**
	 * @param lastRegStaffId the lastRegStaffId to set
	 */
	public void setLastRegStaffId(int lastRegStaffId) {
		this.lastRegStaffId = lastRegStaffId;
	}
	/**
	 * @return the bossCheck
	 */
	public int getBossCheck() {
		return bossCheck;
	}
	/**
	 * @param bossCheck the bossCheck to set
	 */
	public void setBossCheck(int bossCheck) {
		this.bossCheck = bossCheck;
	}
	/**
	 * @return the todohukenName
	 */
	public String getTodohukenName() {
		return todohukenName;
	}
	/**
	 * @param todohukenName the todohukenName to set
	 */
	public void setTodohukenName(String todohukenName) {
		this.todohukenName = todohukenName;
	}

	
}
