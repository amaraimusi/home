package jp.co.amaraimusi;

import javax.servlet.http.HttpSession;

public class LoginNumTimesRestriction {
	

	public boolean trial(HttpSession ses){
		boolean flg=true;
		Integer trialCnt = (Integer) ses.getAttribute("trial_cnt");
		if (trialCnt==null){
			trialCnt=new Integer(0);
		}
		trialCnt=trialCnt+1;
		
		ses.setAttribute("trial_cnt", trialCnt);
		return flg;
	}
	public void success(){
		
	}
}
