package jp.co.amaraimusi.imori;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class InsertReportEntity {

	

	/**
	 * �����G���e�B�e�B��DB�̓����e�[�u���ɒǉ�����B
	 * @param ent�@�����G���e�B�e�B
	 * @throws Exception 
	 * @throws SQLException 
	 */
	public void insertEnt(ReportEntity ent ) throws Exception {
		
		
		IDao dao = DaoFactory.getDao();
		
		dao.open();

		String query = getQuery(ent);
		
		try {
			dao.transactionStart();
			dao.executeUpdate(query);
			dao.commit();
		}catch(Exception e){
			dao.rollBack();
			throw e;
		} finally {
			dao.close();

		}
		
		
	}
	


	private String getQuery(ReportEntity ent ) {
		
		//��������yyyy-MM-dd HH:mm:ss�^�̕�����ɕϊ�����B
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String reportDateStr=sdf.format(ent.getReportDate());
		String newInputDateStr=sdf.format(ent.getNewInputDateTime());
		String lastInputDateStr=sdf.format(ent.getLastInputDateTime());
		
		String query =    
			   " INSERT INTO ReportTbl ("+
			   "     StaffId,"+
			   "     ReportDate,"+
			   "     Report,"+
			   "     BossCheck,"+
			   "     NewInputDateTime,"+
			   "     LastInputDateTime"+
			   " )"+
			   " VALUES("+
				   ent.getStaffId() + "," +
				   "'" + reportDateStr + "'" + "," +
				   "'" + ent.getReport() + "'" + "," +
				   ent.getBossCheck() + "," +
				   "'" + newInputDateStr + "'" + "," +
				   "'" + lastInputDateStr  + "'" + 
			   " )";
			
				System.out.println(query);
		return query;
	}


	

}
