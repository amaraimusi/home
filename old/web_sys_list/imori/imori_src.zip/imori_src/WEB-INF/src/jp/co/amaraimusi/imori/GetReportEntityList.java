package jp.co.amaraimusi.imori;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class GetReportEntityList {

	

	private static final int MDASI_LEN = 20;//���o���̕�����
	private static final int LIMIT_CNT = 50;//�ő�\������



	public ArrayList<ReportEntity> getList(int staffId ) {
		
		ArrayList<ReportEntity> ls =new ArrayList<ReportEntity>();
		
		IDao dao = DaoFactory.getDao();
		
		dao.open();

		String query = getQuery(staffId);

		ResultSet rs = dao.executeQuery(query);
		
		
		try {
			while (rs.next()) {// ResultSet�̓R�l�N�V���������O�Ƀf�[�^�����o���K�v������B
				ReportEntity ent=new ReportEntity();
				// �G���e�B�e�B�ɂc�a����擾�����f�[�^��ǉ����܂��B
				ent.setStaffId(rs.getInt("StaffId"));
				ent.setReportDate(rs.getDate("ReportDate"));
				ent.setMidasi(rs.getString("Midasi"));
				ent.setReport(rs.getString("Report"));
				ent.setBossReport(rs.getString("BossReport"));
				ent.setBossCheck(rs.getInt("BossCheck"));
				ent.setNewInputDateTime(rs.getDate("NewInputDateTime"));
				ent.setLastInputDateTime(rs.getDate("LastInputDateTime"));
				ent.setBossNewInputDateTime(rs.getDate("BossNewInputDateTime"));
				ent.setBossLastInputDateTime(rs.getDate("BossLastInputDateTime"));
				
				ls.add(ent);
					
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dao.close();

		}
		
		//�����|�[�g����w�蕶�����؂�o���āA���o���ɃZ�b�g����B
		for (ReportEntity ent:ls){
			String report=ent.getReport();
			String midasi;
			if (ent.getReport().length()>MDASI_LEN){
				midasi= report.substring(0,MDASI_LEN);
			}else{
				midasi=report;
			}
			
			ent.setMidasi(midasi);
		}
		
		
		return ls;

	}
	
	

	private String getQuery(int staffId) {
		
		String query =    
			   " SELECT"+
			   "     StaffId,"+
			   "     ReportDate,"+
			   "     Midasi,"+
			   "     Report,"+
			   "     BossReport,"+
			   "     BossCheck,"+
			   "     NewInputDateTime,"+
			   "     LastInputDateTime,"+
			   "     BossNewInputDateTime,"+
			   "     BossLastInputDateTime"+
			   " FROM"+
			   "     ReportTbl"+
			   " WHERE"+
			   "     StaffId="+ staffId +
			   " LIMIT " + LIMIT_CNT;
				
		return query;
	}


	

}
