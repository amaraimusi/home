package jp.co.amaraimusi.imori;

import java.util.Date;

public class ReportEntity {
	private int staffId;    //�Ј�ID
	private Date reportDate;    //���|�[�g���t
	private String midasi;    //���o��
	private String report;    //���|�[�g
	private String bossReport;    //��i���|�[�g
	private int bossCheck;    //��i�m�F
	private Date newInputDateTime;    //�V�K���͓���
	private Date lastInputDateTime;    //�ŏI���͓���
	private Date bossNewInputDateTime;    //��i�V�K���͓���
	private Date bossLastInputDateTime;    //��i�ŏI���͓���
	/**
	 * @return the staffId
	 */
	public int getStaffId() {
		return staffId;
	}
	/**
	 * @param staffId the staffId to set
	 */
	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}
	/**
	 * @return the reportDate
	 */
	public Date getReportDate() {
		return reportDate;
	}
	/**
	 * @param reportDate the reportDate to set
	 */
	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}
	/**
	 * @return the midasi
	 */
	public String getMidasi() {
		return midasi;
	}
	/**
	 * @param midasi the midasi to set
	 */
	public void setMidasi(String midasi) {
		this.midasi = midasi;
	}
	/**
	 * @return the report
	 */
	public String getReport() {
		return report;
	}
	/**
	 * @param report the report to set
	 */
	public void setReport(String report) {
		this.report = report;
	}
	/**
	 * @return the bossReport
	 */
	public String getBossReport() {
		return bossReport;
	}
	/**
	 * @param bossReport the bossReport to set
	 */
	public void setBossReport(String bossReport) {
		this.bossReport = bossReport;
	}
	/**
	 * @return the bossCheck
	 */
	public int getBossCheck() {
		return bossCheck;
	}
	/**
	 * @param bossCheck the bossCheck to set
	 */
	public void setBossCheck(int bossCheck) {
		this.bossCheck = bossCheck;
	}
	/**
	 * @return the newInputDateTime
	 */
	public Date getNewInputDateTime() {
		return newInputDateTime;
	}
	/**
	 * @param newInputDateTime the newInputDateTime to set
	 */
	public void setNewInputDateTime(Date newInputDateTime) {
		this.newInputDateTime = newInputDateTime;
	}
	/**
	 * @return the lastInputDateTime
	 */
	public Date getLastInputDateTime() {
		return lastInputDateTime;
	}
	/**
	 * @param lastInputDateTime the lastInputDateTime to set
	 */
	public void setLastInputDateTime(Date lastInputDateTime) {
		this.lastInputDateTime = lastInputDateTime;
	}
	/**
	 * @return the bossNewInputDateTime
	 */
	public Date getBossNewInputDateTime() {
		return bossNewInputDateTime;
	}
	/**
	 * @param bossNewInputDateTime the bossNewInputDateTime to set
	 */
	public void setBossNewInputDateTime(Date bossNewInputDateTime) {
		this.bossNewInputDateTime = bossNewInputDateTime;
	}
	/**
	 * @return the bossLastInputDateTime
	 */
	public Date getBossLastInputDateTime() {
		return bossLastInputDateTime;
	}
	/**
	 * @param bossLastInputDateTime the bossLastInputDateTime to set
	 */
	public void setBossLastInputDateTime(Date bossLastInputDateTime) {
		this.bossLastInputDateTime = bossLastInputDateTime;
	}
	
	
}
