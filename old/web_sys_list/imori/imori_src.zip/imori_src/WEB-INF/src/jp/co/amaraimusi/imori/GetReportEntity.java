package jp.co.amaraimusi.imori;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class GetReportEntity {

	

	public ReportEntity getEnt(int staffId,Date reportDate ) {
		
		
		IDao dao = DaoFactory.getDao();
		
		dao.open();

		String query = getQuery(staffId,reportDate);

		ResultSet rs = dao.executeQuery(query);
		
		ReportEntity ent=null;
		try {
			while (rs.next()) {// ResultSet�̓R�l�N�V���������O�Ƀf�[�^�����o���K�v������B
				ent=new ReportEntity();
				// �G���e�B�e�B�ɂc�a����擾�����f�[�^��ǉ����܂��B
				ent.setStaffId(rs.getInt("StaffId"));
				ent.setReportDate(rs.getDate("ReportDate"));
				ent.setMidasi(rs.getString("Midasi"));
				ent.setReport(rs.getString("Report"));
				ent.setBossReport(rs.getString("BossReport"));
				ent.setBossCheck(rs.getInt("BossCheck"));
				ent.setNewInputDateTime(rs.getDate("NewInputDateTime"));
				ent.setLastInputDateTime(rs.getDate("LastInputDateTime"));
				ent.setBossNewInputDateTime(rs.getDate("BossNewInputDateTime"));
				ent.setBossLastInputDateTime(rs.getDate("BossLastInputDateTime"));
				


			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dao.close();

		}
		
		return ent;

	}
	


	private String getQuery(int staffId,Date reportDate) {
		
		//���������t��yy-MM-dd�^�̕�����ɕϊ�����B
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String dateStr=sdf.format(reportDate);
		
		String query =    
			   " SELECT"+
			   "     StaffId,"+
			   "     ReportDate,"+
			   "     Midasi,"+
			   "     Report,"+
			   "     BossReport,"+
			   "     BossCheck,"+
			   "     NewInputDateTime,"+
			   "     LastInputDateTime,"+
			   "     BossNewInputDateTime,"+
			   "     BossLastInputDateTime"+
			   " FROM"+
			   "     ReportTbl"+
			   " WHERE"+
			   "     StaffId=" + String.valueOf(staffId) + " AND " +
			   "     ReportDate='" + dateStr + "'";
				
		return query;
	}


	

}
