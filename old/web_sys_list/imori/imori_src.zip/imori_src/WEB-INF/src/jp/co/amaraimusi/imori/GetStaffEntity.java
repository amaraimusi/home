package jp.co.amaraimusi.imori;

import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class GetStaffEntity {
	
	

	/**
	 * �Ј����e�B�e�B���擾����B
	 * @return�@�Ј����X�g
	 */
	public StaffEntity getEnt(int id) {
		
		StaffEntity ent=null;
		IDao dao = DaoFactory.getDao();
		
		dao.open();

		String query = getQuery(String.valueOf(id));

		ResultSet rs = dao.executeQuery(query);
		
		// if (rs!=null){
		// �������ꂽ�s�������[�v
		try {
			while (rs.next()) {// ResultSet�̓R�l�N�V���������O�Ƀf�[�^�����o���K�v������B

				// �G���e�B�e�B�ɂc�a����擾�����f�[�^��ǉ����܂��B
				ent=new StaffEntity();
				ent.setId(rs.getInt("Id"));
				ent.setMngPos(rs.getString("MngPos"));
				ent.setName(rs.getString("Name"));
				ent.setKana(rs.getString("Kana"));
				ent.setPass(rs.getString("Pass"));
				ent.setPostNo(rs.getString("PostNo"));
				ent.setTodohuken(rs.getInt("Todohuken"));
				ent.setAddress(rs.getString("Address"));
				ent.setAddress2(rs.getString("Address2"));
				ent.setMailAddress(rs.getString("MailAddress"));
				ent.setTell(rs.getString("Tell"));
				ent.setAdmin(rs.getInt("Admin"));
				ent.setNewRegDateTime(rs.getDate("NewRegDateTime"));
				ent.setLastRegDateTime(rs.getDate("LastRegDateTime"));
				ent.setNewRegStaffId(rs.getInt("NewRegStaffId"));
				ent.setLastRegStaffId(rs.getInt("LastRegStaffId"));
				ent.setBossCheck(rs.getInt("BossCheck"));
				ent.setTodohukenName(rs.getString("TodohukenId"));
				


			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dao.close();

		}
		
		return ent;

	}
	

	private String getQuery(String idStr) {

		String query =    
		   " SELECT"+
		   "     stafftbl.Id AS Id,"+
		   "     stafftbl.MngPos AS MngPos,"+
		   "     stafftbl.Name AS Name,"+
		   "     stafftbl.Kana AS Kana,"+
		   "     stafftbl.Pass AS Pass,"+
		   "     stafftbl.PostNo AS PostNo,"+
		   "     stafftbl.Todohuken AS Todohuken,"+
		   "     stafftbl.Address AS Address,"+
		   "     stafftbl.Address2 AS Address2,"+
		   "     stafftbl.MailAddress AS MailAddress,"+
		   "     stafftbl.Tell AS Tell,"+
		   "     stafftbl.Admin AS Admin,"+
		   "     stafftbl.NewRegDateTime AS NewRegDateTime,"+
		   "     stafftbl.LastRegDateTime AS LastRegDateTime,"+
		   "     stafftbl.NewRegStaffId AS NewRegStaffId,"+
		   "     stafftbl.LastRegStaffId AS LastRegStaffId,"+
		   "     stafftbl.BossCheck AS BossCheck,"+
		   "     todohukentbl.Id AS TodohukenId,"+
		   "     todohukentbl.Name AS TodohukenName"+
		   " FROM"+
		   "     stafftbl INNER JOIN todohukentbl ON stafftbl.Todohuken = todohukentbl.Id" +
		   " WHERE"+
		   "     stafftbl.Id = "+ idStr +";";
		return query;
	}



	

}
