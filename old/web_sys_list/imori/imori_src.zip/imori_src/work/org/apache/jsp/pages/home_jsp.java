package org.apache.jsp.pages;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class home_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fhtml;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fhtml_005fhtml = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fhtml_005fhtml.release();
    _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=utf-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      if (_jspx_meth_html_005fhtml_005f0(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_html_005fhtml_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:html
    org.apache.struts.taglib.html.HtmlTag _jspx_th_html_005fhtml_005f0 = (org.apache.struts.taglib.html.HtmlTag) _005fjspx_005ftagPool_005fhtml_005fhtml.get(org.apache.struts.taglib.html.HtmlTag.class);
    _jspx_th_html_005fhtml_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fhtml_005f0.setParent(null);
    int _jspx_eval_html_005fhtml_005f0 = _jspx_th_html_005fhtml_005f0.doStartTag();
    if (_jspx_eval_html_005fhtml_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n");
        out.write("<head>\r\n");
        out.write("\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n");
        out.write("\t<title>トレカ通販ネコ</title>\r\n");
        out.write("\t<link href=\"home.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
        out.write("\t<script type=\"text/javascript\" src=\"js/category.js\"/>\r\n");
        out.write("\r\n");
        out.write("</head>\r\n");
        out.write("\r\n");
        out.write("<body>\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("<div id=\"container\">\r\n");
        out.write("\r\n");
        out.write("\t");
        out.write("\t\r\n");
        out.write("\t");
        if (_jspx_meth_tiles_005finsert_005f0(_jspx_th_html_005fhtml_005f0, _jspx_page_context))
          return true;
        out.write("\r\n");
        out.write("\t\r\n");
        out.write("\t");
        out.write("\t\r\n");
        out.write("\t");
        if (_jspx_meth_tiles_005finsert_005f1(_jspx_th_html_005fhtml_005f0, _jspx_page_context))
          return true;
        out.write("\r\n");
        out.write("\r\n");
        out.write("<!-- メインコンテンツ-->\r\n");
        out.write("\t<br>\r\n");
        out.write("    <div id = \"main_content\">\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("<div id=\"pankuzu\"><a href=\"pages/home.do\">ホーム</a>\r\n");
        out.write("</div>\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("<div id=\"window2\">\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("<h3>■このサイトについての紹介</h3>\r\n");
        out.write("<div class=\"neko\">このサイトはトレーディングカード通販サイトを模したデモ用です。実際に売買は行われません。</div>\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("<h3>■機能について</h3>\r\n");
        out.write("<ul>◆ログイン機能\r\n");
        out.write("\t<li>一般的なサイトのログインと同じ形式です。</li>\r\n");
        out.write("\t<li>5回入力失敗した場合、5分空ける必要があります。</li>\r\n");
        out.write("\t<li>セッションIDに関するセキュリティを施しています。</li>\r\n");
        out.write("</ul>\r\n");
        out.write("<ul>◆ログイン情報登録機能\r\n");
        out.write("\t<li>ログインのためのアカウント発行機能です。</li>\r\n");
        out.write("\t<li>ログイン画面から遷移できます。</li>\r\n");
        out.write("\t<li>発行後は自動的にログインされます。</li>\r\n");
        out.write("</ul>\r\n");
        out.write("<ul>◆商品ページ\r\n");
        out.write("<li>商品表示方法は2種類あり、商品画像のあるウィンドウ型、商品画像を省略したリスト型があります。</li>\r\n");
        out.write("\t<li>商品名、価格で並べ替えが可能です。</li>\r\n");
        out.write("\t<li>商品の名前で検索機能も備えています。</li>\r\n");
        out.write("</ul>\r\n");
        out.write("<ul>◆注文機能\r\n");
        out.write("\t<li>基本的な流れは他の一般的通販サイトと同様、入力画面、入力確認画面、登録の流れになります。</li>\r\n");
        out.write("\t<li>ただしログインしてから注文情報を登録する場合は、入力の手間が一部省けるようにしています。</li>\r\n");
        out.write("</ul>\r\n");
        out.write("<h3>■開発環境</h3>\r\n");
        out.write("<center>\r\n");
        out.write("<table border=\"1\">\r\n");
        out.write("\r\n");
        out.write("<tr><td>OS</td><td>WindowsXP</td></tr>\r\n");
        out.write("<tr><td>開発言語等：</td><td>Java（jdk6 ）   JavaScript,スタイルシート,Excel VBA（開発補助ツール用）</td></tr>\r\n");
        out.write("<tr><td>フリームワーク</td><td>Struts1.38</td></tr>\r\n");
        out.write("<tr><td>統合開発ツール</td><td>Eclipse3.4</td></tr>\r\n");
        out.write("<tr><td>DB </td><td>MySQL 5.0</td></tr>\r\n");
        out.write("</table>\r\n");
        out.write("</center>\r\n");
        out.write("<h3>■セキュリティについて</h3>\r\n");
        out.write("<ul>◆SQLインジェクション対策\r\n");
        out.write("\t<li>DBに関わる入力値のうちいくつかの特殊記号は削除もしくは置き換え。</li>\r\n");
        out.write("\t<li>SQLにかかわる特殊記号を排除するフィルタプログラムを実装。（一部未実装）</li>\r\n");
        out.write("</ul>\r\n");
        out.write("<ul>◆クロスサイトスクリプティング\r\n");
        out.write("\t<li>Strustを正しく用いることで対処。</li>\r\n");
        out.write("</ul>\r\n");
        out.write("<ul>◆セッションID管理\r\n");
        out.write("\t<li>ログイン後、住所入力後ごとに、セッションIDを再取得する。</li>\r\n");
        out.write("</ul>\r\n");
        out.write("<h3>■未開発部分</h3>\r\n");
        out.write("<ul>\r\n");
        out.write("<li>メール送信機能が未実装</li>\r\n");
        out.write("<li>本格的な結合テストはまだ行っていない。</li>\r\n");
        out.write("<li>SQLインジェクション対策が不完全なため、必要なすべての箇所に施す。</li>\r\n");
        out.write("<li>管理者用部分。VBにて開発する予定。</li>\r\n");
        out.write("</ul>\r\n");
        out.write("\r\n");
        out.write("<h3>■開発者</h3>\r\n");
        out.write("\t<div class=\"neko\">上原健二</div>\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("</div>\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("<a href=\"showdisplayitem.do?categoryId1=1&categoryId2=-1&displayStyle=0&sortType=0&searchStr=null\">商品ページへ</a>\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\r\n");
        out.write("\t</div>");
        out.write("\r\n");
        out.write("\t<div id=\"footer\">\r\n");
        out.write("\t  <h6>COPYRIGHT 2008 UEHARA</h6>\r\n");
        out.write("\t</div>\r\n");
        out.write("\r\n");
        out.write("</div>");
        out.write("\r\n");
        out.write("</body>\r\n");
        int evalDoAfterBody = _jspx_th_html_005fhtml_005f0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_html_005fhtml_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fhtml.reuse(_jspx_th_html_005fhtml_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fhtml.reuse(_jspx_th_html_005fhtml_005f0);
    return false;
  }

  private boolean _jspx_meth_tiles_005finsert_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fhtml_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  tiles:insert
    org.apache.struts.tiles.taglib.InsertTag _jspx_th_tiles_005finsert_005f0 = (org.apache.struts.tiles.taglib.InsertTag) _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody.get(org.apache.struts.tiles.taglib.InsertTag.class);
    _jspx_th_tiles_005finsert_005f0.setPageContext(_jspx_page_context);
    _jspx_th_tiles_005finsert_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fhtml_005f0);
    // /pages/home.jsp(26,1) name = component type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_tiles_005finsert_005f0.setComponent("/pages/cmn-topmenu.jsp");
    int _jspx_eval_tiles_005finsert_005f0 = _jspx_th_tiles_005finsert_005f0.doStartTag();
    if (_jspx_th_tiles_005finsert_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody.reuse(_jspx_th_tiles_005finsert_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody.reuse(_jspx_th_tiles_005finsert_005f0);
    return false;
  }

  private boolean _jspx_meth_tiles_005finsert_005f1(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fhtml_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  tiles:insert
    org.apache.struts.tiles.taglib.InsertTag _jspx_th_tiles_005finsert_005f1 = (org.apache.struts.tiles.taglib.InsertTag) _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody.get(org.apache.struts.tiles.taglib.InsertTag.class);
    _jspx_th_tiles_005finsert_005f1.setPageContext(_jspx_page_context);
    _jspx_th_tiles_005finsert_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fhtml_005f0);
    // /pages/home.jsp(29,1) name = component type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_tiles_005finsert_005f1.setComponent("/pages/cmn-sidemenu.jsp");
    int _jspx_eval_tiles_005finsert_005f1 = _jspx_th_tiles_005finsert_005f1.doStartTag();
    if (_jspx_th_tiles_005finsert_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody.reuse(_jspx_th_tiles_005finsert_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005ftiles_005finsert_0026_005fcomponent_005fnobody.reuse(_jspx_th_tiles_005finsert_005f1);
    return false;
  }
}
