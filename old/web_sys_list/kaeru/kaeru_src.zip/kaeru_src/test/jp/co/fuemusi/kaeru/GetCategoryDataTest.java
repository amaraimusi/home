package jp.co.fuemusi.kaeru;

import java.util.ArrayList;

import junit.framework.TestCase;

public class GetCategoryDataTest extends TestCase {

	public void testGetData() {
		GetCategoryData test =new GetCategoryData();
		ArrayList<Category1Entity> ls = test.getData();
		for (Category1Entity ent:ls){
			if (ent !=null){
				System.out.println("������"+ent.getCategoryId1()+":"+ent.getCategoryName1());
				ArrayList<Category2Entity> ls2 = ent.getCate2List();
				for (Category2Entity ent2:ls2){
					System.out.println(ent2.getCategoryId2());
				}
			}
		}
	}

}
