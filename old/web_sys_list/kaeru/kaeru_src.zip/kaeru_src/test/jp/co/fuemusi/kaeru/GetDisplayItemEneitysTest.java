package jp.co.fuemusi.kaeru;

import java.sql.SQLException;
import java.util.ArrayList;

import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;
import jp.co.fuemusi.kaeru.displayitem.GetDisplayItemEneitys;
import junit.framework.TestCase;

public class GetDisplayItemEneitysTest extends TestCase {

	public void testGetDisplayItemEneitys() {
		
	}

	public void testGetList() {
		System.out.println("������Test�J�n");
		GetDisplayItemEneitys test=new GetDisplayItemEneitys();
		ArrayList<DisplayItemEntity> ls=null;
		try {
			ls = test.getList();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.toString());
		}
		
		for(DisplayItemEntity ent:ls){
			printMsg(ent);
		}

		System.out.println("������������x�A�񏤕i�����擾���Ă݂܂��B");
		try {
			ls=test.getList();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		for(DisplayItemEntity ent:ls){
			printMsg(ent);
		}
		

		System.out.println("�������J�e�S�����w�肵�Ē񏤕i�����擾���܂��B�B");
		ls=test.getDisplayItemList(1,2);
		if (ls !=null){
			for(DisplayItemEntity ent:ls){
				printMsg(ent);
			}
		}
	}

	private void printMsg(DisplayItemEntity ent) {
		System.out.println(ent.getItemName() + ":" +
					ent.getCategory1() + ":" +
					ent.getCategory2()+ ":" +
					ent.getStatus() );
	}
	
	

}
