package jp.co.fuemusi.kaeru.displayitem;

import java.sql.SQLException;
import java.util.ArrayList;

import junit.framework.TestCase;

public class DieItemAndStatusTest extends TestCase {

	public void testMakkingMappingData() {
		GetDisplayItemEneitys gdi=new GetDisplayItemEneitys();
		ArrayList<DisplayItemEntity> ls=null;
		try {
			ls=gdi.getList();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DieItemAndStatus test =new DieItemAndStatus();
		DisplayItemEntity[][] mapDt=test.makkingMappingData(ls);
		
		for (int i=0;i<mapDt.length;i++){
			for (int k=0;k<mapDt[i].length;k++){
				DisplayItemEntity ent=mapDt[i][k];
				if (ent!=null){
					System.out.println(ent.getItemName() + "," + ent.getStatus());
				}
			}
		}
		
	}

}
