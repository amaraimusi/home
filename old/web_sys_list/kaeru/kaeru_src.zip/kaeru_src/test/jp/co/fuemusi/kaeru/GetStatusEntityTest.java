package jp.co.fuemusi.kaeru;

import junit.framework.TestCase;

public class GetStatusEntityTest extends TestCase {

	public void testGetEnts() {
		GetStatusEntitys test =new GetStatusEntitys();
		StatusEntity ents[]=test.getEnts();
		for (StatusEntity ent:ents){
			if (ent!=null){
				System.out.println(ent.getName());
				
			}
			
		}
	
	}

}
