package jp.co.fuemusi.kaeru.user;

import junit.framework.TestCase;

public class GetAutoUserIdTest extends TestCase {

	public void testCreateUserId() {
		GetAutoUserId test =new GetAutoUserId();
		try {
			System.out.println(test.createUserId());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
