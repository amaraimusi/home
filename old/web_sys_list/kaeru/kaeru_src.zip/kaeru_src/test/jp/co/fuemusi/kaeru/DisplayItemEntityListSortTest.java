package jp.co.fuemusi.kaeru;

import java.sql.SQLException;
import java.util.ArrayList;

import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;
import jp.co.fuemusi.kaeru.displayitem.GetDisplayItemEneitys;
import junit.framework.TestCase;

public class DisplayItemEntityListSortTest extends TestCase {
	public void testExcute(){
		System.out.println ("���e�X�g�J�n");
		GetDisplayItemEneitys gdie =new GetDisplayItemEneitys();
		try {
			gdie.getList();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		int categoryId1=2;
		
		ArrayList<DisplayItemEntity> ls = gdie.getDisItemEntityList(categoryId1);
		
		System.out.println ("���\�[�g�O");
		for(DisplayItemEntity ent:ls){
			System.out.println (ent.getItemName());
		}
		
		DisplayItemEntityListSort diSort=new DisplayItemEntityListSort();
		System.out.println ("�����i���ŏ����\�[�g");
		ArrayList<DisplayItemEntity> ls2 =diSort.ascSortForName(ls);
		for(DisplayItemEntity ent:ls2){
			System.out.println (ent.getItemName());
		}

		System.out.println ("�����i���ō~���\�[�g");
		ArrayList<DisplayItemEntity> ls�R =diSort.descSortForName(ls);
		for(DisplayItemEntity ent:ls�R){
			System.out.println (ent.getItemName());
		}
		
		System.out.println ("�����i�ŏ����\�[�g");
		ArrayList<DisplayItemEntity> ls4 =diSort.ascSortForValue(ls);
		for(DisplayItemEntity ent:ls4){
			System.out.println (ent.getValue() + ":" + ent.getItemName()  );
		}
		System.out.println ("�����i�ō~���\�[�g");
		ArrayList<DisplayItemEntity> ls5 =diSort.descSortForValue(ls);
		for(DisplayItemEntity ent:ls5){
			System.out.println (ent.getValue() + ":" + ent.getItemName()  );
		}
	}
	
}
