package jp.co.fuemusi.kaeru;

import java.sql.SQLException;
import java.util.ArrayList;

import jp.co.fuemusi.kaeru.StockCounter;
import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;
import jp.co.fuemusi.kaeru.displayitem.GetDisplayItemEneitys;
import junit.framework.TestCase;

public class StockCounterTest extends TestCase {

	public void testMakingStockCntDt1() {
		GetDisplayItemEneitys gdi=new GetDisplayItemEneitys();
		try {
			gdi.getList();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ArrayList<DisplayItemEntity> diEntLsts[]=gdi.getMappingData1();
		StockCounter test = new StockCounter();
		int stCnt[]=test.makingStockCntDt1(diEntLsts);
		System.out.println("������testMakingStockCntDt1");
		for (int it:stCnt){
			System.out.println(it);
		}
	}

	public void testMakingStockCntDt2() {
		GetDisplayItemEneitys gdi=new GetDisplayItemEneitys();
		try {
			gdi.getList();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ArrayList<DisplayItemEntity> diEntLsts[][]=gdi.getMappingData2();
		StockCounter test = new StockCounter();
		int stCnt[][]=test.makingStockCntDt2(diEntLsts);
		System.out.println("������testMakingStockCntDt2");
		for (int i=0;i<stCnt.length;i++){
			for (int k=0;k<stCnt[0].length;k++){
				System.out.println(stCnt[i][k]);
			}
		}
	}

}
