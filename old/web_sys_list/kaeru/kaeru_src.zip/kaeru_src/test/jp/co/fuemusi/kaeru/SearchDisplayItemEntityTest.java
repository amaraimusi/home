package jp.co.fuemusi.kaeru;

import java.util.ArrayList;

import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;
import junit.framework.TestCase;

public class SearchDisplayItemEntityTest extends TestCase {

	public void testSearch() {
		System.out.println("��SearchDisplayItemEntityTest�����s���܂��B");
		SearchDisplayItemEntity test =new SearchDisplayItemEntity();
		ArrayList<DisplayItemEntity> ls=test.search("�J�c����");
		for(DisplayItemEntity ent:ls){
			System.out.println(ent.getItemName());
		}
		
	}

}
