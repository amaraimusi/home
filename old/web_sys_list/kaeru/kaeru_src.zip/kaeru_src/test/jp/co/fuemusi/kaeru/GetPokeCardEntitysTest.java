package jp.co.fuemusi.kaeru;

import junit.framework.TestCase;

public class GetPokeCardEntitysTest extends TestCase {

	public void testGetList() {
		GetPokeCardEntitys test = new GetPokeCardEntitys();
		test.getList();
		PokeCardEntity ents[]=test.getMappingPcEnts();
		for (PokeCardEntity ent:ents){
			if (ent !=null){
				System.out.println(ent.getId() + ":" + ent.getName());
				
			}
		}
	}

}
