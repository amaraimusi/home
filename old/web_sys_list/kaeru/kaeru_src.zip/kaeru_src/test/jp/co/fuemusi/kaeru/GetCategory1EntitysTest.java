package jp.co.fuemusi.kaeru;

import junit.framework.TestCase;

public class GetCategory1EntitysTest extends TestCase {

	public void testGetEnts() {
		GetCategory1Entitys test =new GetCategory1Entitys();
		Category1EntityB ents[]=test.getEnts();
		for (Category1EntityB ent:ents){
			if (ent!=null){
				System.out.println(ent.getName());
				
			}
			
		}
	}

}
