package jp.co.fuemusi.kaeru.oder;

import java.sql.SQLException;
import java.util.ArrayList;
import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;
import jp.co.fuemusi.kaeru.displayitem.GetDisplayItemEneitys;
import junit.framework.TestCase;

public class InsertItemHistoryTest extends TestCase {

	public void testInsert() {
		
		GetDisplayItemEneitys gid=new GetDisplayItemEneitys();
		try {
			gid.getList();
		} catch (SQLException e1) {
			fail();
			e1.printStackTrace();
		}
		ArrayList<DisplayItemEntity> itemList =gid.getDisItemEntityList(1);
		ArrayList<ItemHistoryEntity> ihList =new ArrayList<ItemHistoryEntity>();
		for(DisplayItemEntity diEnt :itemList){
			System.out.println(diEnt.getItemName());
			ItemHistoryEntity ent =new ItemHistoryEntity();
			ent.setOderId(16);
			ent.setOderCnt(5);
			ent.setItemId(diEnt.getItemId());
			ent.setStatusId(diEnt.getItemStatusId());
			ent.setPrice(diEnt.getValue().intValue());
			ihList.add(ent);
		}
		
		
		InsertItemHistoryList test = new InsertItemHistoryList();
		try {
			test.insert(ihList);
		} catch (Exception e) {
			fail();
		}
		
	}

}
