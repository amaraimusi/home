package jp.co.fuemusi.kaeru.oder;

import java.util.LinkedHashMap;
import java.util.Set;

import junit.framework.TestCase;

public class GetSendMapTest extends TestCase {

	public void testGetMap() {
		GetSendMap test =new GetSendMap();
		LinkedHashMap<String, String> map=test.getMap();
		Set<String> keys =map.keySet();
		for(String key:keys){
			System.out.println(key + "," + map.get(key));
		}
	}

}
