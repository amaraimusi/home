package jp.co.fuemusi.kaeru.oder;

import junit.framework.TestCase;

public class GetAutoOderIdTest extends TestCase {

	public void testCreateOderId() {
		GetAutoOderId test = new GetAutoOderId();
		int oderId =test.createOderId();
		System.out.print(oderId);
	}

}
