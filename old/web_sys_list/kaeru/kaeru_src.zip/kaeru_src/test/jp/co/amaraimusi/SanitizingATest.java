package jp.co.amaraimusi;

import junit.framework.TestCase;

public class SanitizingATest extends TestCase {

	public void testSanitizing() {
		String str=";DELETE from user WHERE 'A'='A";
		System.out.println(str);
		
		SanitizingA test = new SanitizingA();
		str=test.sanitizing(str);
		System.out.println(str);
	}

}
