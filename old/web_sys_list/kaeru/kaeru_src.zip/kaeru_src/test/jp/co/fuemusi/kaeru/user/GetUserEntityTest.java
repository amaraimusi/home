package jp.co.fuemusi.kaeru.user;

import junit.framework.TestCase;

public class GetUserEntityTest extends TestCase {

	public void testGetEnt() {
		GetUserEntity test =new GetUserEntity();
		String userId ="kani";
		UserEntity ent =test.getEnt(userId);
		
		System.out.println(ent.getUserId());
		System.out.println(ent.getPostNoStr());
		System.out.println(ent.getTodohukenId());
		System.out.println(ent.getAddress());
		System.out.println(ent.getName());
		System.out.println(ent.getKana());
		System.out.println(ent.getTell());
		System.out.println(ent.getMail());
		System.out.println(ent.getPass());
	
	}

}
