package jp.co.fuemusi.kaeru;

import java.util.ArrayList;

import jp.co.amaraimusi.DaoForODBC;
import jp.co.amaraimusi.IDao;
import junit.framework.TestCase;

public class GetItemDataTest extends TestCase {
	public void test1(){

		//IDao dao =new DaoForDataSource("jdbc/forODBC");
		IDao dao =new DaoForODBC("kaeru","root","neko");
		GetItemData getDt=new GetItemData(dao);
		ArrayList<?> ls=getDt.getList();
		System.out.println(ls.size());
		//GetItemData test =new GetItemData();
	}
	
}
