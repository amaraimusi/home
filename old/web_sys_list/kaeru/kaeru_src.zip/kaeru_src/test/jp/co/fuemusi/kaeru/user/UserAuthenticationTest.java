package jp.co.fuemusi.kaeru.user;

import junit.framework.TestCase;

public class UserAuthenticationTest extends TestCase {

	public void testUthentication() {
		UserAuthentication test =new UserAuthentication();
	
		neko(test, "neko", "aaaa");
		neko(test, "kani", "kanipass");
		neko(test, "kani", "kanibuta");
		neko(test, "kaniniku", "kani");
		neko(test, "ahonaga", "ahonaga");
	}

	private void neko(UserAuthentication test, String userId, String password) {
		if(test.authentication(userId,password)){
			System.out.println(userId + ":" + password + ":�F�؂n�j");
			
		}else{
			System.out.println(userId + ":" + password + ":�F�؎��s");
		}
	}

}
