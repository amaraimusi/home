package jp.co.fuemusi.kaeru.oder;

import junit.framework.TestCase;

public class InsertOderDataTest extends TestCase {

	public void testInsert() {
		OderEntity ent =new OderEntity();
		ent.setAllTotal(1000);
		ent.setNote("���l");
		ent.setOderId(19);
		ent.setPayName("�e�X�g�@�^���E");
		ent.setPayTypeId(1);
		ent.setSendValue(200);
		ent.setSmallTotal(800);
		ent.setUserId("test02");
		InsertOderData test =new InsertOderData();
		try {
			test.insert(ent);
		} catch (Exception e) {
			
			fail();
		}
		
	}

}
