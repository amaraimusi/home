package jp.co.fuemusi.kaeru;

import junit.framework.TestCase;

public class GetCategory2EntitysTest extends TestCase {

	public void testGetEnts() {
		GetCategory2Entitys test =new GetCategory2Entitys();
		Category2EntityB ents[]=test.getEnts();
		for (Category2EntityB ent:ents){
			if (ent!=null){
				System.out.println(ent.getName());
				
			}
			
		}
	}

}
