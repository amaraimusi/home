import java.text.SimpleDateFormat;
import java.util.Date;


public class HidukeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Date now =new Date();
		System.out.println(now);
		System.out.println(now.toString());
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		System.out.println(sdf.format(now));
		
		
		
			
	}

}
