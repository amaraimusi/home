package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.amaraimusi.RenewSession;
import jp.co.fuemusi.kaeru.Cst;
import jp.co.fuemusi.kaeru.user.UserAuthentication;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.LoginForm;

/**
 * 	���O�C������
 * 
 * @author K_UEHARA
 * 
 */
public class LoginAction extends ActionBase {

	
	private static final int LOGIN_SUCCESS = 1;
	private static final int LOGIN_FALSE = 2;
	Log log = LogFactory.getLog(LoginAction.class);


	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		super.execute(mapping, form, request, response);

		System.out.println("������LoginAction");
		
		//�����[�U�[�F�؂��s���B
		LoginForm fm=(LoginForm)form;
		String userId=fm.getUserId();
		String password=fm.getPass();
		
		String rtnStr="err";
		
		UserAuthentication ua =new UserAuthentication();
		
		if(ua.authentication(userId, password)){
			rtnStr="success";
			
			//���Z�b�V�������Đ�������B
			RenewSession renewSes = new RenewSession();
			renewSes.renew(request);
			
			//�Z�b�V�����Ƀ��[�U�[�h�c���Z�b�g����B
			request.getSession().setAttribute(Cst.USER_ID, userId);
			fm.setLoginFlg(LOGIN_SUCCESS);
			System.out.println(userId +" �F�؂��܂����B");
		}else{
			this.saveToken(request.getSession());
			fm.setLoginFlg(LOGIN_FALSE);
			System.out.println(userId +" ���O�C�����s");
		}
		

		
		
		return mapping.findForward(rtnStr);
	}

}