package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * 	���O�C����ʂ�\������B
 * 
 * @author K_UEHARA
 * 
 */
public class LoginShowAction extends ActionBase {

	Log log = LogFactory.getLog(LoginShowAction.class);

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		super.execute(mapping, form, request, response);

		System.out.println("������LoginShowAction");
	
	
		
		
		return mapping.findForward("success");
	}

}