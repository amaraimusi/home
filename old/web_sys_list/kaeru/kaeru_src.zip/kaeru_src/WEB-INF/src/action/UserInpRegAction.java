package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.amaraimusi.RenewSession;
import jp.co.fuemusi.kaeru.Cst;
import jp.co.fuemusi.kaeru.user.InsertUserData;
import jp.co.fuemusi.kaeru.user.UserEntity;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.UserForm;

/**
 * 	���[�U�[�����͓o�^�A�N�V����
 * 
 * @author K_UEHARA
 * 
 */
public class UserInpRegAction extends ActionBase {

	Log log = LogFactory.getLog(UserInpRegAction.class);

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		super.execute(mapping, form, request, response);

		System.out.println("������UserInpRegAction");

		
		try {
			if (this.isToken(request.getSession())){
				
				//�����[�U�[�����c�a�ɒǉ�����B
				UserForm fm = (UserForm)form;
				UserEntity userEnt=fm.getUserEnt();
				InsertUserData insert =new InsertUserData();
				insert.insert(userEnt);
				
				
				//���Z�b�V�������Đ�������B
				RenewSession renewSes = new RenewSession();
				renewSes.renew(request);
				
				//�Z�b�V�����Ƀ��[�U�[�h�c���Z�b�g����B
				request.getSession().setAttribute(Cst.USER_ID, fm.getUserEnt().getUserId());
			
				request.setAttribute("is_success", "true");
			}else{
				return mapping.findForward("err");
			}
		} catch (Exception e) {
			request.setAttribute("is_success", "false");
		}
		

		return mapping.findForward("success");
	}



}