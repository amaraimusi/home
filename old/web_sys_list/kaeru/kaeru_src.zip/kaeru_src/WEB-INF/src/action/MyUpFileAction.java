package action;

import java.io.InputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import form.MyUpFileActionForm;



/**
* HelloAction.java
*/
public class MyUpFileAction extends Action {

    Log log = LogFactory.getLog(MyUpFileAction.class);

    @Override
	public ActionForward execute(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
    throws Exception {
    		
    	System.out.println("�t�@�C���A�b�v���[�h�̃e�X�g���J�n���܂��B");
 
    	MyUpFileActionForm fm=(MyUpFileActionForm)form;
    	FormFile file = fm.getFile();
    	System.out.println(file.getFileName());
    	
    	InputStream is=file.getInputStream();
    	
    	byte[] buf = new byte[256];//�s�̕�������ʁH
    	String str = "";
    	// �t�@�C����ǂݍ���
    	while (is.read(buf) != -1){
    		str = new String(buf);
    		System.out.println(str);
			// �J���}��؂�̕���
	    	//String[] strAry = str.split(",");//(2)�������split���\�b�h�ŕ���
		
    	
    	}
        return mapping.findForward("success");
    }
}