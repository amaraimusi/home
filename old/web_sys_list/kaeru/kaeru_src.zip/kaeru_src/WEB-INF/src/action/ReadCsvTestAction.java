package action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;




import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.amaraimusi.CsvFileControl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.CsvTestForm;



/**
* HelloAction.java
*/
public class ReadCsvTestAction extends Action {

    Log log = LogFactory.getLog(ReadCsvTestAction.class);

    @Override
	public ActionForward execute(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
    throws Exception {
    		
    	System.out.println("�e�X�g�J�n�ł���");
    	//���ʏ���
    	super.execute(mapping, form, request, response);
    	
    	CsvTestForm fm=(CsvTestForm)form;
    	
    	String csvFileName = fm.getCsvFileName();
    	
    	if (csvFileName != ""){

        	CsvFileControl cfc = new CsvFileControl();
        	
        	ArrayList<HashMap<String,String>> ls =cfc.readCsvFileData(csvFileName);
        	
        	
        	//�o�̓e�X�g
    		System.out.println("�e�X�g����");
    		for (HashMap<String,String >  map:ls){
    			Set<String> keys=map.keySet();
    			StringBuffer sb=new StringBuffer();
    			for(String key:keys){
    				sb.append("��");
    				sb.append( map.get(key).toString());
    				
    			}
    			System.out.println(sb.toString());
    		}
    	}else{
    		System.out.println("�t�@�C������null�ł������܂���B");
    	}
    	
    	
        return mapping.findForward("success");
    }
}