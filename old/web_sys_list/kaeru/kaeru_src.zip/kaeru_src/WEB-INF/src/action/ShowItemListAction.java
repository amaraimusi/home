package action;

import java.util.ArrayList;




import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.amaraimusi.DaoForODBC;
import jp.co.amaraimusi.IDao;
import jp.co.fuemusi.kaeru.GetItemData;
import jp.co.fuemusi.kaeru.ItemEntity;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.ItemForm;



/**
* HelloAction.java
*/
public class ShowItemListAction extends Action {

    Log log = LogFactory.getLog(ShowItemListAction.class);

    @Override
	public ActionForward execute(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
    throws Exception {
    	//���ʏ���
    	super.execute(mapping, form, request, response);
    	
    	//�A�N�V�����t�H�[����V�K�쐬�B�J�ڌ��̃t�H�[�������擾���Ă͂Ȃ�Ȃ����߁j
    	ItemForm fm = (ItemForm) form;
    	
    	ArrayList<ItemEntity> itemList=fm.getItemList();
    	
    	if(itemList==null){
        	//���i���擾�I�u�W�F�N�g�𐶐�
    		//IDao dao =new DaoForDataSource("jdbc/forODBC");
    		IDao dao =new DaoForODBC("kaeru","root","neko");
        	GetItemData getDt=new GetItemData(dao);
        	
        	//���i�����c�a����A�擾���ăA�N�V�����t�H�[���ɃZ�b�g
        	ArrayList<ItemEntity> ls=getDt.getList();
        	fm.setItemList(ls);

    	}
    	

    	
    	ArrayList<ItemEntity> ls =fm.getItemList();
    	for (int i=0;i<ls.size();i++){
    		ItemEntity ent =ls.get(i);
    		System.out.println(ent.getName());
    	}
    	
    	HttpSession ss=request.getSession(false);
    	if (ss.isNew()==true){
    		System.out.println("�Z�b�V����New");
    	}else{
    		System.out.println("�Z�b�V����Old");
    		
    	}
    	
    	
        return mapping.findForward("success");
    }
}