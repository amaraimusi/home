package rab;

import java.util.ArrayList;

public class SynObject {
	ArrayList<String> ls;
	public void message(String exeName){
		for (int i=0;i<100;i++){
			System.out.println(exeName + i);
		}
	}
	public synchronized void message2(String exeName){
		ls=new ArrayList<String>();
		for (int i=0;i<1000;i++){
			//System.out.println(exeName + i);
			ls.add(exeName+i);
			
		}
	}
}
