package rab;

public class MyThread extends Thread {
	MyThread mySelf;
	String name;
	SynObject synObj;
	//�R���X�g���N�^
	MyThread( String name,SynObject sb ) {
		this.name = name ;
		this.synObj=sb;
		mySelf=this;
	}
	
	public void run() {
		synObj.message2(this.name);
		//System.out.println(this.name + Runtime.getRuntime().freeMemory());
		//mySelf=null;
		//System.gc();
		System.out.println(this.name + Runtime.getRuntime().freeMemory());
	}

	public void finalize(){
		System.out.println(this.name + "�̏����I��");
	}
}
