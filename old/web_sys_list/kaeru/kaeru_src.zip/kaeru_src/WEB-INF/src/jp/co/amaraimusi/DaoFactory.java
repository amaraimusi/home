package jp.co.amaraimusi;

import jp.co.amaraimusi.DaoForMySQL;
import jp.co.amaraimusi.IDao;

public class DaoFactory {
	//static IDao dao;
	public static IDao getDao(){
		IDao dao = new DaoForMySQL("kaeru","root","neko");
		
		return dao;
	}
}
