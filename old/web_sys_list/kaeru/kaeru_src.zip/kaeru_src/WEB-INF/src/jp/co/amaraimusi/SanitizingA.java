package jp.co.amaraimusi;

import java.util.ArrayList;

public class SanitizingA {
	private ArrayList<String> checkList;
	
	public SanitizingA(){
		checkList =new ArrayList<String>();

		checkList.add(" ");
		checkList.add("(");
		checkList.add(")");
		checkList.add("[");
		checkList.add("]");
		checkList.add("\""); 
		checkList.add("\\");
		checkList.add("'"); 
		checkList.add(",");
		checkList.add("-");
		checkList.add(".");
		checkList.add("&"); 
		checkList.add("+");
		checkList.add("/");
		checkList.add("|");
		checkList.add(":");
		checkList.add(";");
		checkList.add("<");
		checkList.add("=");
		checkList.add(">");
		checkList.add("%"); 
		checkList.add("*"); 
		checkList.add("?");
		checkList.add("_");
		checkList.add("@");
		checkList.add("^");
		checkList.add("#");
		checkList.add("$");
	}
	
	/**
	 * �T�j�^�C�W���O���s���BSQL�C���W�F�N�V�����ɑΉ�
	 * �����̕����񂩂璍�ӕ��������菜���B
	 * @param str 
	 * @return
	 */
	public String sanitizing(String str){
		for (String chkStr:checkList){
			str=str.replace(chkStr, "");
		}
		return str;
		
	}
	
}
