package jp.co.fuemusi.kaeru.oder;

public class GetSendValue {
	
	public int getValue(){
		return 80;
	}
}
