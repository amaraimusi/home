package jp.co.fuemusi.kaeru.user;

import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class InsertUserData {

	/**
	 * ���[�U�[�����c�a�ɍX�V����B
	 * @param userEnt�@���[�U�[���
	 * @throws Exception
	 */
	public void insert(UserEntity userEnt) throws Exception {

		IDao dao = DaoFactory.getDao();

		dao.open();

		String query = getQuery(userEnt);
		dao.transactionStart();
		try {
			dao.executeUpdate(query);
			dao.commit();
		} catch (Exception e) {
			
			throw e;
		}finally{
			dao.close();
		}
		

	}

	private String getQuery(UserEntity userEnt) {

		String query =     
		   " INSERT INTO usertbl ("+
		   " UserId,"+
		   " PostNoStr,"+
		   " TodohukenId,"+
		   " Address,"+
		   " Name,"+
		   " Kana,"+
		   " Tell,"+
		   " Mail,"+
		   " Pass,"+
		   " AutoIdFlg"+
		   " )"+
		   " VALUES"+
		   " ("+
		   " '" + userEnt.getUserId() + "',"+
		   " '" + userEnt.getPostNoStr() + "',"+
		   " " + userEnt.getTodohukenId() + ","+
		   " '" + userEnt.getAddress() + "',"+
		   " '" + userEnt.getName() + "',"+
		   " '" + userEnt.getKana() + "',"+
		   " '" + userEnt.getTell() + "',"+
		   " '" + userEnt.getMail() + "',"+
		   " '" + userEnt.getPass()+ "',"+
		   " " + userEnt.getAutoIdFlg()+ 
		   " )";
		System.out.println(query);
		return query;
	}

	

}
