package jp.co.fuemusi.kaeru.oder;

import java.util.ArrayList;
import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class InsertItemHistoryList {

	/**
	 * ���i�������X�g���c�a�ɍX�V����B
	 * @param oderEnt�@���i�������X�g
	 * @throws Exception
	 */
	public void insert(ArrayList<ItemHistoryEntity> ihList ) throws Exception {

		IDao dao = DaoFactory.getDao();

		dao.open();


		try {
			dao.transactionStart();
			for(ItemHistoryEntity ent :ihList){
				String query = getQuery(ent);
				dao.executeUpdate(query);
			}
			dao.commit();
		} catch (Exception e) {
			dao.rollBack();
			throw e;
		}finally{
			dao.close();
		}
		

	}

	private String getQuery(ItemHistoryEntity ent) {
	
		String query =     
		   " INSERT INTO ItemHistoryTbl ("+
		   " OderId,"+
		   " ItemId,"+
		   " StatusId,"+
		   " OderCnt,"+
		   " Price"+
		   " )"+
		   " VALUES"+
		   " ("+
		   " " + ent.getOderId() + ","+
		   " " + ent.getItemId() + ","+
		   " " + ent.getStatusId() + ","+
		   " " + ent.getOderCnt() + ","+
		   " " + ent.getPrice() + 
		   " )";
		System.out.println(query);
		return query;
	}

	

}
