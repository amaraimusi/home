package jp.co.fuemusi.kaeru;

import java.math.BigDecimal;
import java.util.ArrayList;

public class Category1Entity {

	private int categoryId1 ;//�J�e�S���h�c1
	private int categoryId2 ;//�J�e�S���h�c�Q
	private int disKindCnt;//�񏤕i��ސ�
	private int zukanKindCnt;//�}�ӎ�ސ�
	private int disStockCnt;//�񏤕i����
	private BigDecimal sellValue;//�̔����i
	private BigDecimal costValue;//�������i
	private ArrayList<Category2Entity> cate2List;//�J�e�S���Q�G���e�B�e�B���X�g
	private int status;//��Ԑ�
	private String categoryName1;//�J�e�S���P����
	



	/**
	 * @return the zukanKindCnt
	 */
	public int getZukanKindCnt() {
		return zukanKindCnt;
	}
	/**
	 * @param zukanKindCnt the zukanKindCnt to set
	 */
	public void setZukanKindCnt(int zukanKindCnt) {
		this.zukanKindCnt = zukanKindCnt;
	}
	/**
	 * @return the disStockCnt
	 */
	public int getDisStockCnt() {
		return disStockCnt;
	}
	/**
	 * @param disStockCnt the disStockCnt to set
	 */
	public void setDisStockCnt(int disStockCnt) {
		this.disStockCnt = disStockCnt;
	}
	/**
	 * @return the sellValue
	 */
	public BigDecimal getSellValue() {
		return sellValue;
	}
	/**
	 * @param sellValue the sellValue to set
	 */
	public void setSellValue(BigDecimal sellValue) {
		this.sellValue = sellValue;
	}
	/**
	 * @return the costValue
	 */
	public BigDecimal getCostValue() {
		return costValue;
	}
	/**
	 * @param costValue the costValue to set
	 */
	public void setCostValue(BigDecimal costValue) {
		this.costValue = costValue;
	}

	/**
	 * @param cate2List the cate2List to set
	 */
	public void setCate2List(ArrayList<Category2Entity> cate2List) {
		this.cate2List = cate2List;
	}
	/**
	 * @return the cate2List
	 */
	public ArrayList<Category2Entity> getCate2List() {
		return cate2List;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}
	/**
	 * @param categoryName1 the categoryName1 to set
	 */
	public void setCategoryName1(String categoryName1) {
		this.categoryName1 = categoryName1;
	}
	/**
	 * @return the categoryName1
	 */
	public String getCategoryName1() {
		return categoryName1;
	}
	/**
	 * @param categoryId1 the categoryId1 to set
	 */
	public void setCategoryId1(int categoryId1) {
		this.categoryId1 = categoryId1;
	}
	/**
	 * @return the categoryId1
	 */
	public int getCategoryId1() {
		return categoryId1;
	}
	/**
	 * @param disKindCnt the disKindCnt to set
	 */
	public void setDisKindCnt(int disKindCnt) {
		this.disKindCnt = disKindCnt;
	}
	/**
	 * @return the disKindCnt
	 */
	public int getDisKindCnt() {
		return disKindCnt;
	}
	/**
	 * @param categoryId2 the categoryId2 to set
	 */
	public void setCategoryId2(int categoryId2) {
		this.categoryId2 = categoryId2;
	}
	/**
	 * @return the categoryId2
	 */
	public int getCategoryId2() {
		return categoryId2;
	}
	
	
}
