package jp.co.fuemusi.kaeru;

import java.util.ArrayList;

import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;

/**
 * @author K_UEHARA �p���������X�g
 */
public class Breadcrumbs {

	private String categoryName1;// �J�e�S�����P
	private String categoryName2;// �J�e�S�����Q
	private DipEntity dipEnt;//�񏤕i�y�[�W�ݒ�G���e�B�e�B

	/**
	 * �p���������X�g���쐬
	 * 
	 * @param diEntList
	 *            �񏤕i���
	 */
	public void makingBreadcrumbs(ArrayList<DisplayItemEntity> diEntList,
			DipEntity dipEnt) {
		
		//���񏤕i�y�[�W�ݒ�l���擾����B
		int categoryId1=dipEnt.getCategoryId1();
		int categoryId2=dipEnt.getCategoryId2();
	
		
		if (diEntList != null && diEntList.size() != 0) {
			DisplayItemEntity ent = diEntList.get(0);
			if (categoryId1 != Cst.CATEGORY_NOTHING) {
				categoryName1 = ent.getCategory1();
			} else {
				categoryName1 = "null";
			}

			if (categoryId2 != Cst.CATEGORY_NOTHING) {
				categoryName2 = ent.getCategory2();
			} else {
				categoryName2 = "null";
			}
		} else {
			categoryName1 = "null";
			categoryName2 = "null";

		}

		// ���v���p�e�B�ɃZ�b�g����B
		setDipEnt(dipEnt);

	}

	/**
	 * @return the categoryName1
	 */
	public String getCategoryName1() {
		return categoryName1;
	}

	/**
	 * @param categoryName1
	 *            the categoryName1 to set
	 */
	public void setCategoryName1(String categoryName1) {
		this.categoryName1 = categoryName1;
	}

	/**
	 * @return the categoryName2
	 */
	public String getCategoryName2() {
		return categoryName2;
	}

	/**
	 * @param categoryName2
	 *            the categoryName2 to set
	 */
	public void setCategoryName2(String categoryName2) {
		this.categoryName2 = categoryName2;
	}

	/**
	 * @param dipEnt the dipEnt to set
	 */
	public void setDipEnt(DipEntity dipEnt) {
		this.dipEnt = dipEnt;
	}

	/**
	 * @return the dipEnt
	 */
	public DipEntity getDipEnt() {
		return dipEnt;
	}

	

}
