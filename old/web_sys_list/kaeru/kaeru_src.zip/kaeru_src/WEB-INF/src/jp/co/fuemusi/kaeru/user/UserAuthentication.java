package jp.co.fuemusi.kaeru.user;

import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class UserAuthentication {
	/**
	 * ���[�U�[�F��
	 * 
	 * @return�@���[�U�[�F�؉�
	 */
	public boolean authentication(String userId,String password) {

		IDao dao = DaoFactory.getDao();

		dao.open();

		String query = getQuery(userId,password);

		ResultSet rs = dao.executeQuery(query);
		
		boolean flg=false;
		try {
			while (rs.next()) {

				flg=true;

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dao.close();

		}

		return flg;

	}

	private String getQuery(String userId,String password) {

		String query =    
		   " SELECT"+
		   "     UserId,"+
		   "     Pass"+
		   " FROM"+
		   "     UserTbl"+
		   " WHERE"+
		   "     UserId='"+userId+"' AND"+
		   "     Pass='"+password+"'";
		return query;
	}

	

}
