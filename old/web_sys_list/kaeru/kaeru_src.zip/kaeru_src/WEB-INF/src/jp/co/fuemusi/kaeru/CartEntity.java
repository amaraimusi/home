package jp.co.fuemusi.kaeru;

/**
 * �J�[�g�G���e�B�e�B
 * 
 * @author K_UEHARA
 * 
 */
public class CartEntity {
	private int itemId;// ���iID
	private String itemName;// ���i��
	private int statusId;// ���i���ID
	private String status;// ���i���
	private int value;//�P��
	private int categoryId1;// �J�e�S��Id�P
	private int categoryId2;// �J�e�S��Id�Q
	private String categoryName1;// �J�e�S�����P
	private String categoryName2;// �J�e�S����2
	private int buyCnt;// �w����
	private int updateBuyCnt;// �ύX�w����
	private boolean delFlg;// �폜�t���O
	private boolean stockOverFlg;//�݌ɃI�[�o�[�t���O

	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}

	/**
	 * @param itemName
	 *            the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**
	 * @return the statusId
	 */
	public int getStatusId() {
		return statusId;
	}

	/**
	 * @param statusId
	 *            the statusId to set
	 */
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	/**
	 * @return the categoryId1
	 */
	public int getCategoryId1() {
		return categoryId1;
	}

	/**
	 * @param categoryId1
	 *            the categoryId1 to set
	 */
	public void setCategoryId1(int categoryId1) {
		this.categoryId1 = categoryId1;
	}

	/**
	 * @return the categoryId2
	 */
	public int getCategoryId2() {
		return categoryId2;
	}

	/**
	 * @param categoryId2
	 *            the categoryId2 to set
	 */
	public void setCategoryId2(int categoryId2) {
		this.categoryId2 = categoryId2;
	}

	/**
	 * @return the buyCnt
	 */
	public int getBuyCnt() {
		return buyCnt;
	}

	/**
	 * @param buyCnt
	 *            the buyCnt to set
	 */
	public void setBuyCnt(int buyCnt) {
		this.buyCnt = buyCnt;
	}

	/**
	 * @return the updateBuyCnt
	 */
	public int getUpdateBuyCnt() {
		return updateBuyCnt;
	}

	/**
	 * @param updateBuyCnt
	 *            the updateBuyCnt to set
	 */
	public void setUpdateBuyCnt(int updateBuyCnt) {
		this.updateBuyCnt = updateBuyCnt;
	}



	/**
	 * @param itemId
	 *            the itemId to set
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	/**
	 * @return the itemId
	 */
	public int getItemId() {
		return itemId;
	}

	/**
	 * @param categoryName1
	 *            the categoryName1 to set
	 */
	public void setCategoryName1(String categoryName1) {
		this.categoryName1 = categoryName1;
	}

	/**
	 * @return the categoryName1
	 */
	public String getCategoryName1() {
		return categoryName1;
	}

	/**
	 * @param categoryName2
	 *            the categoryName2 to set
	 */
	public void setCategoryName2(String categoryName2) {
		this.categoryName2 = categoryName2;
	}

	/**
	 * @return the categoryName2
	 */
	public String getCategoryName2() {
		return categoryName2;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param stockOverFlg the stockOverFlg to set
	 */
	public void setStockOverFlg(boolean stockOverFlg) {
		this.stockOverFlg = stockOverFlg;
	}

	/**
	 * @return the stockOverFlg
	 */
	public boolean isStockOverFlg() {
		return stockOverFlg;
	}

	/**
	 * @param delFlg the delFlg to set
	 */
	public void setDelFlg(boolean delFlg) {
		this.delFlg = delFlg;
	}

	/**
	 * @return the delFlg
	 */
	public boolean getDelFlg() {
		return delFlg;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}
}
