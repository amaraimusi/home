package jp.co.fuemusi.kaeru;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * �񏤕i�y�[�W�ݒ�G���e�B�e�B Display Item Page Entity
 * @author K_UEHARA
 *
 */
public class DipEntity {
	
	private int categoryId1;//�J�e�S��ID1
	private int categoryId2;//�J�e�S��ID�Q
	private int displayStyle;//��X�^�C��
	private int sortType;//���я��^�C�v
	private String searchStr;// ����������
	
	/**
	 * @return the categoryId1
	 */
	public int getCategoryId1() {
		return categoryId1;
	}
	/**
	 * @param categoryId1 the categoryId1 to set
	 */
	public void setCategoryId1(int categoryId1) {
		this.categoryId1 = categoryId1;
	}
	/**
	 * @return the categoryId2
	 */
	public int getCategoryId2() {
		return categoryId2;
	}
	/**
	 * @param categoryId2 the categoryId2 to set
	 */
	public void setCategoryId2(int categoryId2) {
		this.categoryId2 = categoryId2;
	}
	/**
	 * @return the displayStyle
	 */
	public int getDisplayStyle() {
		return displayStyle;
	}
	/**
	 * @param displayStyle the displayStyle to set
	 */
	public void setDisplayStyle(int displayStyle) {
		this.displayStyle = displayStyle;
	}
	/**
	 * @return the sortType
	 */
	public int getSortType() {
		return sortType;
	}
	/**
	 * @param sortType the sortType to set
	 */
	public void setSortType(int sortType) {
		this.sortType = sortType;
	}
	/**
	 * @return the searchStr
	 */
	public String getSearchStr() {
		return searchStr;
	}
	/**
	 * @param searchStr
	 *            the searchStr to set
	 */
	public void setSearchStr(String searchStr) {
		
		try {
			searchStr = URLDecoder.decode(searchStr, "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		System.out.println(searchStr);
		this.searchStr = searchStr;
	}
}
