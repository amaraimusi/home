package jp.co.fuemusi.kaeru.user;

/**
 * ���[�U�[���G���e�B�e�B
 * @author K_UEHARA
 *
 */
public class UserEntity {
	private String userId;    //���[�U�[ID
	private String postNoStr;    //�X�֔ԍ�
	private int todohukenId;    //�s���{��ID
	private String address;    //�Z��
	private String name;    //����
	private String kana;    //�����i�ǂ݉����j
	private String tell;    //�d�b�ԍ�
	private String mail;    //���[���A�h���X
	private String pass;    //�p�X���[�h
	private boolean AutoIdFlg;//�������[�U�[ID�����t���O
	
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the postNoStr
	 */
	public String getPostNoStr() {
		return postNoStr;
	}
	/**
	 * @param postNoStr the postNoStr to set
	 */
	public void setPostNoStr(String postNoStr) {
		this.postNoStr = postNoStr;
	}
	/**
	 * @return the todohukenId
	 */
	public int getTodohukenId() {
		return todohukenId;
	}
	/**
	 * @param todohukenId the todohukenId to set
	 */
	public void setTodohukenId(int todohukenId) {
		this.todohukenId = todohukenId;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the kana
	 */
	public String getKana() {
		return kana;
	}
	/**
	 * @param kana the kana to set
	 */
	public void setKana(String kana) {
		this.kana = kana;
	}
	/**
	 * @return the tell
	 */
	public String getTell() {
		return tell;
	}
	/**
	 * @param tell the tell to set
	 */
	public void setTell(String tell) {
		this.tell = tell;
	}
	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}
	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}
	/**
	 * @return the pass
	 */
	public String getPass() {
		return pass;
	}
	/**
	 * @param pass the pass to set
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}
	/**
	 * @return the autoIdFlg
	 */
	public boolean getAutoIdFlg() {
		return AutoIdFlg;
	}
	/**
	 * @param autoIdFlg the autoIdFlg to set
	 */
	public void setAutoIdFlg(boolean autoIdFlg) {
		AutoIdFlg = autoIdFlg;
	}

	
}
