package jp.co.fuemusi.kaeru;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;

/**
 * @author K_UEHARA �񏤕i���𖼑O�܂��͉��i���ŕ��בւ���B
 */
public class DisplayItemEntityListSort {
	/**
	 * ���O�ŏ����\�[�g
	 * 
	 * @param ls
	 *            �\�[�g�O�񏤕i���
	 * @return �\�[�g��񏤕i���
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<DisplayItemEntity> ascSortForName(
			ArrayList<DisplayItemEntity> ls) {
		ArrayList<DisplayItemEntity> ls2 = (ArrayList<DisplayItemEntity>) ls
				.clone();
		// name�̏����Ń\�[�g
		Collections.sort(ls2, new Comparator<DisplayItemEntity>() {
			public int compare(DisplayItemEntity diEnt1,
					DisplayItemEntity diEnt2) {
				String itemName1 = diEnt1.getItemNameForSort();
				String itemName2 = diEnt2.getItemNameForSort();
				if (itemName1.compareTo(itemName2) < 0) {
					return -1;
				} else if (itemName1.compareTo(itemName2) > 0) {
					return 1;
				}
				return 0;
			}
		});
		return ls2;
	}

	/**
	 * ���O�ō~���\�[�g
	 * 
	 * @param ls
	 *            �\�[�g�O�񏤕i���
	 * @return �\�[�g��񏤕i���
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<DisplayItemEntity> descSortForName(
			ArrayList<DisplayItemEntity> ls) {
		ArrayList<DisplayItemEntity> ls2 = (ArrayList<DisplayItemEntity>) ls
				.clone();
		// name�̍~���Ń\�[�g
		Collections.sort(ls2, new Comparator<DisplayItemEntity>() {
			public int compare(DisplayItemEntity diEnt1,
					DisplayItemEntity diEnt2) {
				String itemName1 = diEnt1.getItemNameForSort();
				String itemName2 = diEnt2.getItemNameForSort();
				if (itemName1.compareTo(itemName2) < 0) {
					return 1;
				} else if (itemName1.compareTo(itemName2) > 0) {
					return -1;
				}
				return 0;
			}
		});
		return ls2;
	}

	/**
	 * ���i�ŏ����\�[�g
	 * 
	 * @param ls
	 *            �\�[�g�O�񏤕i���
	 * @return �\�[�g��񏤕i���
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<DisplayItemEntity> ascSortForValue(
			ArrayList<DisplayItemEntity> ls) {
		ArrayList<DisplayItemEntity> ls2 = (ArrayList<DisplayItemEntity>) ls
				.clone();
		
		Collections.sort(ls2, new Comparator<DisplayItemEntity>() {
			public int compare(DisplayItemEntity diEnt1,
					DisplayItemEntity diEnt2) {
				BigDecimal value1 = diEnt1.getValue();
				BigDecimal value2 = diEnt2.getValue();
				if (value1.compareTo(value2) < 0) {
					return -1;
				} else if (value1.compareTo(value2) > 0) {
					return 1;
				}
				return 0;
			}
		});
		return ls2;
	}

	/**
	 * ���i�ō~���\�[�g
	 * 
	 * @param ls
	 *            �\�[�g�O�񏤕i���
	 * @return �\�[�g��񏤕i���
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<DisplayItemEntity> descSortForValue(
			ArrayList<DisplayItemEntity> ls) {
		ArrayList<DisplayItemEntity> ls2 = (ArrayList<DisplayItemEntity>) ls
				.clone();
		
		Collections.sort(ls2, new Comparator<DisplayItemEntity>() {
			public int compare(DisplayItemEntity diEnt1,
					DisplayItemEntity diEnt2) {
				BigDecimal value1 = diEnt1.getValue();
				BigDecimal value2 = diEnt2.getValue();
				if (value1.compareTo(value2) < 0) {
					return 1;
				} else if (value1.compareTo(value2) > 0) {
					return -1;
				}
				return 0;
			}
		});
		return ls2;
	}
}
