package jp.co.fuemusi.kaeru.custag;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class CtTestName extends TagSupport
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String m_strName = "";

    public void setName(String str)
    {
        m_strName = str;
    }

    public String getName()
    {
        return m_strName;
    }


    public int doStartTag() throws JspException
    {
        try
        {
            // �����ŏ������s��
            pageContext.getOut().print( m_strName );
        }
        catch (Exception e)
        {
            throw new JspException(e.getMessage());
        }
        return SKIP_BODY;
    }

    public int doEndTag()
    {
        return EVAL_PAGE;
    }
}