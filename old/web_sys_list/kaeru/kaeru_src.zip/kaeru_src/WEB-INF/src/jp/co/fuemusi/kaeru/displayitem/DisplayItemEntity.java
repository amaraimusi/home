package jp.co.fuemusi.kaeru.displayitem;

import java.math.BigDecimal;

/**
 * @author K_UEHARA
 *�񏤕i�G���e�B�e�B
 */
public class DisplayItemEntity {
	private int itemId;    //���iID
	private int itemStatusId;    //���i���ID
	private int stockCnt;    //�݌�
	private BigDecimal value;    //���i
	private BigDecimal cost;    //����
	private String itemName;    //���i��
	private int categoryId1;    //�J�e�S���PID
	private int categoryId2;    //�J�e�S���QID
	private String picFileName;    //�摜�t�@�C����
	private String note;    //���l
	private String category1;    //�J�e�S���P
	private String category2;    //�J�e�S���Q
	private String status;    //���i���
	private int buyCnt;	//�w����
	private String itemNameForSort;//�\�[�g�p���i���i�Ђ炪�ȁA���p�p�����j
	private String txtBoxName;//�e�L�X�g�{�b�N�X���iJavaScript�p�j


	/**
	 * @return the itemNameForSort
	 */
	public String getItemNameForSort() {
		return itemNameForSort;
	}
	/**
	 * @param itemNameForSort the itemNameForSort to set
	 */
	public void setItemNameForSort(String itemNameForSort) {
		this.itemNameForSort = itemNameForSort;
	}
	/**
	 * @return the itemId
	 */
	public int getItemId() {
		return itemId;
	}
	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	/**
	 * @return the itemStatusId
	 */
	public int getItemStatusId() {
		return itemStatusId;
	}
	/**
	 * @param itemStatusId the itemStatusId to set
	 */
	public void setItemStatusId(int itemStatusId) {
		this.itemStatusId = itemStatusId;
	}
	/**
	 * @return the stockCnt
	 */
	public int getStockCnt() {
		return stockCnt;
	}
	/**
	 * @param stockCnt the stockCnt to set
	 */
	public void setStockCnt(int stockCnt) {
		this.stockCnt = stockCnt;
	}
	/**
	 * @return the value
	 */
	public BigDecimal getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(BigDecimal value) {
		this.value = value;
	}
	/**
	 * @return the cost
	 */
	public BigDecimal getCost() {
		return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}
	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}
	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	/**
	 * @return the categoryId1
	 */
	public int getCategoryId1() {
		return categoryId1;
	}
	/**
	 * @param categoryId1 the categoryId1 to set
	 */
	public void setCategoryId1(int categoryId1) {
		this.categoryId1 = categoryId1;
	}
	/**
	 * @return the categoryId2
	 */
	public int getCategoryId2() {
		return categoryId2;
	}
	/**
	 * @param categoryId2 the categoryId2 to set
	 */
	public void setCategoryId2(int categoryId2) {
		this.categoryId2 = categoryId2;
	}
	/**
	 * @return the picFileName
	 */
	public String getPicFileName() {
		return picFileName;
	}
	/**
	 * @param picFileName the picFileName to set
	 */
	public void setPicFileName(String picFileName) {
		this.picFileName = picFileName;
	}
	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}
	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}
	/**
	 * @return the category1
	 */
	public String getCategory1() {
		return category1;
	}
	/**
	 * @param category1 the category1 to set
	 */
	public void setCategory1(String category1) {
		this.category1 = category1;
	}
	/**
	 * @return the category2
	 */
	public String getCategory2() {
		return category2;
	}
	/**
	 * @param category2 the category2 to set
	 */
	public void setCategory2(String category2) {
		this.category2 = category2;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @param buyCnt the buyCnt to set
	 */
	public void setBuyCnt(int buyCnt) {
		this.buyCnt = buyCnt;
	}
	/**
	 * @return the buyCnt
	 */
	public int getBuyCnt() {
		return buyCnt;
	}
	/**
	 * @param txtBoxName the txtBoxName to set
	 */
	public void setTxtBoxName(String txtBoxName) {
		this.txtBoxName = txtBoxName;
	}
	/**
	 * @return the txtBoxName
	 */
	public String getTxtBoxName() {
		return txtBoxName;
	}






}
