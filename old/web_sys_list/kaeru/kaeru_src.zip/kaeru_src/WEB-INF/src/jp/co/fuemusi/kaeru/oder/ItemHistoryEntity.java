package jp.co.fuemusi.kaeru.oder;

public class ItemHistoryEntity {
	private int oderId;    //����ID
	private int itemId;    //���iID
	private int statusId;    //���i���ID
	//private Date oderDatetime;    //��������
	private int oderCnt;    //������
	private int price;    //���i
	/**
	 * @return the oderId
	 */
	public int getOderId() {
		return oderId;
	}
	/**
	 * @param oderId the oderId to set
	 */
	public void setOderId(int oderId) {
		this.oderId = oderId;
	}
	/**
	 * @return the itemId
	 */
	public int getItemId() {
		return itemId;
	}
	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	/**
	 * @return the statusId
	 */
	public int getStatusId() {
		return statusId;
	}
	/**
	 * @param statusId the statusId to set
	 */
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	/**
	 * @return the oderCnt
	 */
	public int getOderCnt() {
		return oderCnt;
	}
	/**
	 * @param oderCnt the oderCnt to set
	 */
	public void setOderCnt(int oderCnt) {
		this.oderCnt = oderCnt;
	}
	/**
	 * @return the price
	 */
	public int getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(int price) {
		this.price = price;
	}

}
