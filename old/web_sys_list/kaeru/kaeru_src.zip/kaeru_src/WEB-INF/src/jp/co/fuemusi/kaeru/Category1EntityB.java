package jp.co.fuemusi.kaeru;

public class Category1EntityB {
	private int id;    //�J�e�S���h�c�P
	private String name;    //�J�e�S����
	private int sortNo;    //���я��ԍ�
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @param sortNo the sortNo to set
	 */
	public void setSortNo(int sortNo) {
		this.sortNo = sortNo;
	}
	/**
	 * @return the sortNo
	 */
	public int getSortNo() {
		return sortNo;
	}


}
