package jp.co.fuemusi.kaeru.custag;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class Ct_test extends TagSupport
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//�X�^�[�g�^�O�̓��e
	public int doStartTag() throws JspException
    {
        try
        {
            // �����ŏ������s��
            pageContext.getOut().print("Test!");
        }
        catch (Exception e)
        {
            throw new JspException(e.getMessage());
        }
        return SKIP_BODY;
    }
	
	//�I���^�O�̓��e
    public int doEndTag()
    {
        return EVAL_PAGE;
    }
}