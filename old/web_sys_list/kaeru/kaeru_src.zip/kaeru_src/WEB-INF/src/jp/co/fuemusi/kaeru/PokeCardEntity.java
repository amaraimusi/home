package jp.co.fuemusi.kaeru;

public class PokeCardEntity {
	private int id;    //�h�c
	private String nos;    //�|�P�����E�R���N�V�����m�n
	private String name;    //�J�[�h��
	private int seriesId;    //�V���[�Y��
	private int packageId;    //�p�b�P�[�W��
	private String typ;    //�^�C�v
	private String rarity;    //���A���e�B
	private String hp;    //�g�o
	private String lv;    //���x��
	private String dates;    //���t
	private String note;    //���l
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the nos
	 */
	public String getNos() {
		return nos;
	}
	/**
	 * @param nos the nos to set
	 */
	public void setNos(String nos) {
		this.nos = nos;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the seriesId
	 */
	public int getSeriesId() {
		return seriesId;
	}
	/**
	 * @param seriesId the seriesId to set
	 */
	public void setSeriesId(int seriesId) {
		this.seriesId = seriesId;
	}
	/**
	 * @return the packageId
	 */
	public int getPackageId() {
		return packageId;
	}
	/**
	 * @param packageId the packageId to set
	 */
	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}
	/**
	 * @return the typ
	 */
	public String getTyp() {
		return typ;
	}
	/**
	 * @param typ the typ to set
	 */
	public void setTyp(String typ) {
		this.typ = typ;
	}
	/**
	 * @return the rarity
	 */
	public String getRarity() {
		return rarity;
	}
	/**
	 * @param rarity the rarity to set
	 */
	public void setRarity(String rarity) {
		this.rarity = rarity;
	}
	/**
	 * @return the hp
	 */
	public String getHp() {
		return hp;
	}
	/**
	 * @param hp the hp to set
	 */
	public void setHp(String hp) {
		this.hp = hp;
	}
	/**
	 * @return the lv
	 */
	public String getLv() {
		return lv;
	}
	/**
	 * @param lv the lv to set
	 */
	public void setLv(String lv) {
		this.lv = lv;
	}
	/**
	 * @return the dates
	 */
	public String getDates() {
		return dates;
	}
	/**
	 * @param dates the dates to set
	 */
	public void setDates(String dates) {
		this.dates = dates;
	}
	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}
	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}


}
