package jp.co.fuemusi.kaeru;

/**
 * @author K_UEHARA
 *���i�G���e�B�e�B
 */
public class ItemEntity {
	private String name;
	private String categoryId1;
	private String categoryId2;
	private int id;
	private String note;
	private String picFileName;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the categoryId1
	 */
	public String getCategoryId1() {
		return categoryId1;
	}
	/**
	 * @param categoryId1 the categoryId1 to set
	 */
	public void setCategoryId1(String categoryId1) {
		this.categoryId1 = categoryId1;
	}
	/**
	 * @return the categoryId2
	 */
	public String getCategoryId2() {
		return categoryId2;
	}
	/**
	 * @param categoryId2 the categoryId2 to set
	 */
	public void setCategoryId2(String categoryId2) {
		this.categoryId2 = categoryId2;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}
	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}
	/**
	 * @return the picFileName
	 */
	public String getPicFileName() {
		return picFileName;
	}
	/**
	 * @param picFileName the picFileName to set
	 */
	public void setPicFileName(String picFileName) {
		this.picFileName = picFileName;
	}

	
	
	
}
