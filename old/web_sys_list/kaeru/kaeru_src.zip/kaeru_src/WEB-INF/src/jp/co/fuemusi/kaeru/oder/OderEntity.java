package jp.co.fuemusi.kaeru.oder;

public class OderEntity {
	private int oderId;    //����ID
	private String userId;    //���[�U�[ID
	private int sendTypeId;    //�������@ID
	private int payTypeId;    //���x�������@ID
	private String payName;    //�U���Җ��`
	private String note;    //���l
	private int smallTotal;    //���v
	private int sendValue;    //����
	private int allTotal;    //���v
	/**
	 * @return the oderId
	 */
	public int getOderId() {
		return oderId;
	}
	/**
	 * @param oderId the oderId to set
	 */
	public void setOderId(int oderId) {
		this.oderId = oderId;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the sendTypeId
	 */
	public int getSendTypeId() {
		return sendTypeId;
	}
	/**
	 * @param sendTypeId the sendTypeId to set
	 */
	public void setSendTypeId(int sendTypeId) {
		this.sendTypeId = sendTypeId;
	}
	/**
	 * @return the payTypeId
	 */
	public int getPayTypeId() {
		return payTypeId;
	}
	/**
	 * @param payTypeId the payTypeId to set
	 */
	public void setPayTypeId(int payTypeId) {
		this.payTypeId = payTypeId;
	}
	/**
	 * @return the payName
	 */
	public String getPayName() {
		return payName;
	}
	/**
	 * @param payName the payName to set
	 */
	public void setPayName(String payName) {
		this.payName = payName;
	}
	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}
	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}
	/**
	 * @return the smallTotal
	 */
	public int getSmallTotal() {
		return smallTotal;
	}
	/**
	 * @param smallTotal the smallTotal to set
	 */
	public void setSmallTotal(int smallTotal) {
		this.smallTotal = smallTotal;
	}
	/**
	 * @return the sendValue
	 */
	public int getSendValue() {
		return sendValue;
	}
	/**
	 * @param sendValue the sendValue to set
	 */
	public void setSendValue(int sendValue) {
		this.sendValue = sendValue;
	}
	/**
	 * @return the allTotal
	 */
	public int getAllTotal() {
		return allTotal;
	}
	/**
	 * @param allTotal the allTotal to set
	 */
	public void setAllTotal(int allTotal) {
		this.allTotal = allTotal;
	}


	
	
}
