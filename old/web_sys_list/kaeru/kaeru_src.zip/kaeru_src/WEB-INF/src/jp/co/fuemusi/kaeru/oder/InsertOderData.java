package jp.co.fuemusi.kaeru.oder;

import jp.co.amaraimusi.DaoFactory;
import jp.co.amaraimusi.IDao;

public class InsertOderData {

	/**
	 * ���������c�a�ɍX�V����B
	 * @param oderEnt�@�������
	 * @throws Exception
	 */
	public void insert(OderEntity oderEnt) throws Exception {

		IDao dao = DaoFactory.getDao();

		dao.open();

		String query = getQuery(oderEnt);
		dao.transactionStart();
		try {
			dao.executeUpdate(query);
			dao.commit();
		} catch (Exception e) {
			
			throw e;
		}finally{
			dao.close();
		}
		

	}

	private String getQuery(OderEntity oderEnt) {
	
		
		String query =     
		   " INSERT INTO OderTbl ("+
		   " OderId,"+
		   " UserId,"+
		   " SendTypeId,"+
		   " PayTypeId,"+
		   " PayName,"+
		   " Note,"+
		   " SmallTotal,"+
		   " SendValue,"+
		   " AllTotal,"+
		   " OderDateTime"+
		   " )"+
		   " VALUES"+
		   " ("+
		   " " + oderEnt.getOderId() + ","+
		   " '" + oderEnt.getUserId() + "',"+
		   " " + oderEnt.getSendTypeId() + ","+
		   " " + oderEnt.getPayTypeId() + ","+
		   " '" + oderEnt.getPayName() + "',"+
		   " '" + oderEnt.getNote() + "',"+
		   " " + oderEnt.getSmallTotal() + ","+
		   " " + oderEnt.getSendValue() + ","+
		   " " + oderEnt.getAllTotal() + ","+
		   " NOW()"+
		   " )";
		System.out.println(query);
		return query;
	}

	

}
