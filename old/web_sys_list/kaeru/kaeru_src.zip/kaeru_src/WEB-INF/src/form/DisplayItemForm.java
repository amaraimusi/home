package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import jp.co.fuemusi.kaeru.displayitem.DisplayItemEntity;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 * HelloForm.java
 */
public class DisplayItemForm extends ActionForm {

	private static final long serialVersionUID = 5576380739286218916L;
	private int categoryId1;//�J�e�S��ID1
	private int categoryId2;//�J�e�S��ID�Q
	private int displayStyle;//��X�^�C��
	private int sortType;//���я��^�C�v
	private String searchStr;// ����������
	private int ticketNo;//�`�P�b�g�ԍ��i�y�[�W�J�ڐ���p�j

	/**
	 * �񏤕i���
	 */
	private ArrayList<DisplayItemEntity> displayItemList;
	/**
	 * @return the categoryId1
	 */
	public int getCategoryId1() {
		return categoryId1;
	}

	/**
	 * @param categoryId1 the categoryId1 to set
	 */
	public void setCategoryId1(int categoryId1) {
		this.categoryId1 = categoryId1;
	}

	/**
	 * @return the categoryId2
	 */
	public int getCategoryId2() {
		return categoryId2;
	}

	/**
	 * @param categoryId2 the categoryId2 to set
	 */
	public void setCategoryId2(int categoryId2) {
		this.categoryId2 = categoryId2;
	}

	/**
	 * @return the displayStyle
	 */
	public int getDisplayStyle() {
		return displayStyle;
	}

	/**
	 * @param displayStyle the displayStyle to set
	 */
	public void setDisplayStyle(int displayStyle) {
		this.displayStyle = displayStyle;
	}

	/**
	 * @return the sortType
	 */
	public int getSortType() {
		return sortType;
	}

	/**
	 * @param sortType the sortType to set
	 */
	public void setSortType(int sortType) {
		this.sortType = sortType;
	}

	/**
	 * @return the searchStr
	 */
	public String getSearchStr() {
		return searchStr;
	}

	/**
	 * @param searchStr the searchStr to set
	 */
	public void setSearchStr(String searchStr) {
		this.searchStr = searchStr;
	}


	/**
	 * @return the displayItemList
	 */
	public ArrayList<DisplayItemEntity> getDisplayItemList() {
		return displayItemList;
	}

	/**
	 * @param displayItemList
	 *            the displayItemList to set
	 */
	public void setDisplayItemList(ArrayList<DisplayItemEntity> displayItemList) {
		this.displayItemList = displayItemList;
	}

	
	/* (non-Javadoc)
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public ActionErrors validate(ActionMapping map, HttpServletRequest req){
		// �G���[���X�g
		ActionErrors errs = new ActionErrors();
		
		
		//�������������̓`�F�b�N
		if (searchStr.length() > 32) {
			ActionMessage errr = new ActionMessage("errors.maxlength", "��������",
					"32");
			errs.add("searchStr", errr);
		}
		
		
		
		return errs;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @seeorg.apache.struts.action.ActionForm#reset(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {

		// ���{����͂ɑΉ�������
		try {

			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param ticketNo the ticketNo to set
	 */
	public void setTicketNo(int ticketNo) {
		this.ticketNo = ticketNo;
	}

	/**
	 * @return the ticketNo
	 */
	public int getTicketNo() {
		return ticketNo;
	}

}
