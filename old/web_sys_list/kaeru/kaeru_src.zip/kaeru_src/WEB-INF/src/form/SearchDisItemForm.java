
package form;
import org.apache.struts.action.ActionForm;

/**
* �񏤕i�����t�H�[��
*/
public class SearchDisItemForm extends ActionForm {


	private static final long serialVersionUID = 1L;
	
	
	private String searchStr;//����������

	/**
	 * @return the searchStr
	 */
	public String getSearchStr() {
		return searchStr;
	}

	/**
	 * @param searchStr the searchStr to set
	 */
	public void setSearchStr(String searchStr) {
		this.searchStr = searchStr;
	}
	

}
