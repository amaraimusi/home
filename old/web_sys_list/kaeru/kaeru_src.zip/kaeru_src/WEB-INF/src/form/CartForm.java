package form;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import jp.co.fuemusi.kaeru.CartEntity;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 * HelloForm.java
 */
public class CartForm extends ActionForm {
	
	private int itemId;//���iID
	private int statusId;//���i���ID
	private int buyCnt;//�w����
	private int displayStyle;// �f�B�X�v���C�X�^�C��
	private int sortType;// ���ו��@
	private int smallTotal;//���v
	
	private ArrayList<CartEntity> cartList;// �J�[�g���X�g

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @return the displayStyle
	 */
	public int getDisplayStyle() {
		return displayStyle;
	}

	/**
	 * @param displayStyle
	 *            the displayStyle to set
	 */
	public void setDisplayStyle(int displayStyle) {
		this.displayStyle = displayStyle;
	}



	/**
	 * @return the cartList
	 */
	public ArrayList<CartEntity> getCartList() {
		return cartList;
	}

	/**
	 * @param cartList
	 *            the cartList to set
	 */
	public void setCartList(ArrayList<CartEntity> cartList) {
		this.cartList = cartList;
	}

	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(int itemId) {

		this.itemId = itemId;
	}

	/**
	 * @return the itemId
	 */
	public int getItemId() {
		return itemId;
	}

	/**
	 * @param statusId the statusId to set
	 */
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	/**
	 * @return the statusId
	 */
	public int getStatusId() {
		return statusId;
	}

	/**
	 * @param buyCnt the buyCnt to set
	 */
	public void setBuyCnt(int buyCnt) {
	
		this.buyCnt = buyCnt;
	}

	/**
	 * @return the buyCnt
	 */
	public int getBuyCnt() {
		return buyCnt;
	}

	
	@Override
	public ActionErrors validate(ActionMapping map, HttpServletRequest req){
		// �G���[���X�g
		ActionErrors errs = new ActionErrors();
		
		

		
		//���w�����`�F�b�N
		if(buyCnt < 0 | buyCnt > 999){
			ActionMessage errr=new ActionMessage("errors.range","��","0","999");
			errs.add("buyCountErr",errr);
		}
		return errs;
	}


	/**
	 * @param sortType the sortType to set
	 */
	public void setSortType(int sortType) {
		this.sortType = sortType;
	}

	/**
	 * @return the sortType
	 */
	public int getSortType() {
		return sortType;
	}

	/**
	 * @param smallTotal the smallTotal to set
	 */
	public void setSmallTotal(int smallTotal) {
		this.smallTotal = smallTotal;
	}

	/**
	 * @return the smallTotal
	 */
	public int getSmallTotal() {
		return smallTotal;
	}


}
