
package form;
import org.apache.struts.action.ActionForm;

/**
* HelloForm.java
*/
public class CsvTestForm extends ActionForm {


	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * CSV�t�@�C����
	 */
	private String csvFileName ;

	/**
	 * @return the csvFileName
	 */
	public String getCsvFileName() {
		return csvFileName;
	}

	/**
	 * @param csvFileName the csvFileName to set
	 */
	public void setCsvFileName(String csvFileName) {
		this.csvFileName = csvFileName;
	}




	

	









}
