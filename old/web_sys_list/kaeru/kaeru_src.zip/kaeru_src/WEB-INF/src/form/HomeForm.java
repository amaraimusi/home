package form;

import org.apache.struts.action.ActionForm;

public class HomeForm extends ActionForm {

	private static final long serialVersionUID = 1L;

	
	
}
