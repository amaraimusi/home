
package form;
import java.util.ArrayList;

import jp.co.fuemusi.kaeru.ItemEntity;

import org.apache.struts.action.ActionForm;

/**
* HelloForm.java
*/
public class ItemForm extends ActionForm {


	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5576380739286218916L;
	/**
	 * �V���i���X�g
	 */
	private ArrayList<ItemEntity> itemList;



	
	/**
	 * @return the newItemList
	 */
	public ArrayList<ItemEntity> getItemList() {
		return itemList;
	}

	/**
	 * @param newItemList the newItemList to set
	 */
	public void setItemList(ArrayList<ItemEntity> itemList) {
		this.itemList = itemList;
	}





	

	









}
