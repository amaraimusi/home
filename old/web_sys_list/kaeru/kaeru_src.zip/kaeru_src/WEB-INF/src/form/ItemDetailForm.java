package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * HelloForm.java
 */
public class ItemDetailForm extends ActionForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int itemId; // ���iId
	private int statusId;// ���i���Id
	private String status;//���i��Ԗ�
	private String itemName;// ���i��
	private int value;//�P��
	private int stockCnt;// �݌ɐ�
	private ArrayList<String> prmList;// �J�[�h�ڍ׃p�����[�^
	private int displayStyle;// �\���X�^�C��
	private int sortTyp;// ���ו��@

	/**
	 * @return the displayStyle
	 */
	public int getDisplayStyle() {
		return displayStyle;
	}

	/**
	 * @param displayStyle
	 *            the displayStyle to set
	 */
	public void setDisplayStyle(int displayStyle) {
		this.displayStyle = displayStyle;
	}

	/**
	 * @return the sortTyp
	 */
	public int getSortTyp() {
		return sortTyp;
	}

	/**
	 * @param sortTyp
	 *            the sortTyp to set
	 */
	public void setSortTyp(int sortTyp) {
		this.sortTyp = sortTyp;
	}

	/**
	 * @return the itemId
	 */
	public int getItemId() {
		return itemId;
	}

	/**
	 * @param itemId
	 *            the itemId to set
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	/**
	 * @param prmList
	 *            the prmList to set
	 */
	public void setPrmList(ArrayList<String> prmList) {
		this.prmList = prmList;
	}

	/**
	 * @return the prmList
	 */
	public ArrayList<String> getPrmList() {
		return prmList;
	}

	/**
	 * @param itemName
	 *            the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}

	/**
	 * @param stockCnt
	 *            the stockCnt to set
	 */
	public void setStockCnt(int stockCnt) {
		this.stockCnt = stockCnt;
	}

	/**
	 * @return the stockCnt
	 */
	public int getStockCnt() {
		return stockCnt;
	}

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		System.out.println("���������������������������{��t�B���^6");
		// ���{����͂ɑΉ�������
		try {

			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param statusId the statusId to set
	 */
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	/**
	 * @return the statusId
	 */
	public int getStatusId() {
		return statusId;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * @param value the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}


}
